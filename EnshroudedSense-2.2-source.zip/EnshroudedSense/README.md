# EnshroudedSense

DualSense support for **Enshrouded** on PC. The game's PC build still contains the
PS5 DualSense code (adaptive trigger effects, haptics sounds, touch settings); this mod
lets that reach the controller.

by MeT1oR and Tianku · Nexus Mods: https://www.nexusmods.com/enshrouded/mods/302

## Features
- adaptive triggers: the game's own trigger effects
- HD haptics: the game's own vibration sounds (footsteps/surfaces, hits, blocks, menu clicks), played on the controller's haptic actuators
- controller speaker
- lightbar: health, oxygen under water, Shroud timer, player LEDs
- gyro aiming (while aiming)
- touchpad: the game's PS5 touch controls (lists, quick item wheel, map drag / pinch zoom, menu tab swipes)

## How it works
Two proxy DLLs placed next to `enshrouded.exe`. Both forward to the real system DLLs.

| file | role |
|---|---|
| `dinput8.dll` (`src/dinput8_loader.c`) | loads early; hooks a few calls in the game's sound code so the haptic / speaker sounds and UI sound events can be read; hides the DualSense from DirectInput so it is not seen twice |
| `xinput1_4.dll` (`src/enshroudedsense.c`, `src/haptics.c`) | talks to the DualSense over HID (inputs, triggers, rumble, lightbar, touch, gyro), presents it to the game as an XInput pad, plays haptics/speaker audio on the controller's own USB audio endpoint (WASAPI), pushes touch gestures into the game's input queue |

Hooks are call-site patches (a `call rel32` redirected to a small trampoline) and two
byte patches. Every patched location is checked against the expected original bytes
first; if the game build differs, that feature stays off and the game runs unmodified.

What it does **not** do:
- no network access (imports: KERNEL32, SETUPAPI, HID, ole32 and the UCRT only; no winsock / WinINet / WinHTTP)
- no registry writes, no process injection, no code downloaded or loaded from elsewhere
- only other DLLs it loads: the real `dinput8.dll` / `xinput1_4.dll` from the Windows system folder

Files it writes, all in the game folder: `EnshroudedSense.ini` (settings, created on first start),
`EnshroudedSense.log`, `EnshroudedSense_early.log`, `EnshroudedSense_load.txt`.

## Building
Needs [zig](https://ziglang.org) **0.17.0** (cross-compiles from Windows or Linux; `pip install ziglang==0.17.0` also works).

```
build.cmd            (Windows)
./build.sh           (Linux; ZIG="python3 -m ziglang" ./build.sh with the pip package)
```
Output: `build/dinput8.dll`, `build/xinput1_4.dll`.

## Checking the released files
`release/SHA256SUMS.txt` has the hashes of the released DLLs and installer.
A self-built DLL differs from the released one only in the PE timestamp and the PDB id
(the linker derives them from the build path). `tools/compare_pe.py` ignores exactly those fields:

```
pip install pefile
python tools/compare_pe.py build/xinput1_4.dll path/to/released/xinput1_4.dll
python tools/compare_pe.py build/dinput8.dll   path/to/released/dinput8.dll
```

## Installer
`installer/EnshroudedSense.nsi` (NSIS 3, 64-bit). It finds the game (previous install, Steam's
uninstall entry, Steam libraries, common folders), copies the two DLLs, backs up same-named
DLLs from other mods and restores them on uninstall, and adds an uninstall entry.
Build: run `build.sh`, then `installer/build_installer.sh` (needs `makensis`).
Installer pictures use official Enshrouded key art.

## Manual install
Copy `dinput8.dll` and `xinput1_4.dll` into the folder with `enshrouded.exe`.
Remove them to uninstall.
