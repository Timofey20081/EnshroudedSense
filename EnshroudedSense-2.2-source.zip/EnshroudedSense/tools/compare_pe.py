# compare a self-built DLL with the released one.
# zig/lld writes a build-path dependent PDB GUID and a timestamp derived from it,
# so those two fields are ignored; every other byte has to match.
import sys, pefile

def masked(path):
    pe = pefile.PE(path)
    b = bytearray(pe.__data__)
    ts = pe.FILE_HEADER.get_file_offset() + 4          # TimeDateStamp
    b[ts:ts + 4] = b'\0' * 4
    for d in getattr(pe, 'DIRECTORY_ENTRY_DEBUG', []):
        s = d.struct
        b[s.get_file_offset() + 4:s.get_file_offset() + 8] = b'\0' * 4   # debug dir TimeDateStamp
        if s.Type == 2 and s.PointerToRawData:       # CodeView: 'RSDS' + GUID + age
            o = s.PointerToRawData + 4
            b[o:o + 20] = b'\0' * 20
    return bytes(b)

a, b = masked(sys.argv[1]), masked(sys.argv[2])
if a == b:
    print('identical (ignoring timestamp / PDB id)')
else:
    diff = sum(1 for x, y in zip(a, b) if x != y) + abs(len(a) - len(b))
    print('DIFFERENT:', diff, 'bytes'); sys.exit(1)
