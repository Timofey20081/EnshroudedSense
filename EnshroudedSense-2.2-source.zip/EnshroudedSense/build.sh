#!/bin/sh
# needs zig 0.17.0 (pip install ziglang==0.17.0 works too: ZIG="python3 -m ziglang")
set -e
ZIG=${ZIG:-zig}
mkdir -p build
cd src
$ZIG cc -target x86_64-windows-gnu -O2 -shared -o ../build/xinput1_4.dll enshroudedsense.c haptics.c xinput1_4.def xinput1_4.rc -lsetupapi -lhid -lole32
$ZIG cc -target x86_64-windows-gnu -O2 -shared -o ../build/dinput8.dll dinput8_loader.c dinput8.def dinput8.rc
echo "built: build/dinput8.dll build/xinput1_4.dll"
