@echo off
rem needs zig 0.17.0 (https://ziglang.org/download/) on PATH, or: pip install ziglang==0.17.0 and use "python -m ziglang" instead of "zig"
if not exist build mkdir build
cd src
zig cc -target x86_64-windows-gnu -O2 -shared -o ..\build\xinput1_4.dll enshroudedsense.c haptics.c xinput1_4.def xinput1_4.rc -lsetupapi -lhid -lole32 || exit /b 1
zig cc -target x86_64-windows-gnu -O2 -shared -o ..\build\dinput8.dll dinput8_loader.c dinput8.def dinput8.rc || exit /b 1
cd ..
echo built: build\dinput8.dll build\xinput1_4.dll
