﻿; EnshroudedSense installer (NSIS 3, Modern UI 2) - English / Russian by the system UI language
Unicode true
Target amd64-unicode
ManifestDPIAware true
ManifestSupportedOS all
RequestExecutionLevel admin
SetCompressor /SOLID lzma

!define APP      "EnshroudedSense"
!define VER      "2.2"
!define VERFULL  "2.2.0.0"
!define PUB      "MeT1oR and Tianku"
!define UKEY     "Software\Microsoft\Windows\CurrentVersion\Uninstall\EnshroudedSense"
!define STEAMKEY "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1203620"
!define PSAPP    "https://controller.dl.playstation.net/controller/lang/gb/2100004.html"
!define GAMESIZE 35476040
!define UNINST   "EnshroudedSense_Uninstall.exe"

Name "${APP} ${VER}"
OutFile "out\EnshroudedSense_Setup_${VER}.exe"
InstallDir ""
BrandingText "${APP} ${VER}  |  by ${PUB}"
ShowInstDetails show
ShowUninstDetails show

VIProductVersion "${VERFULL}"
VIFileVersion "${VERFULL}"
VIAddVersionKey /LANG=1033 "ProductName" "${APP}"
VIAddVersionKey /LANG=1033 "CompanyName" "${PUB}"
VIAddVersionKey /LANG=1033 "FileDescription" "${APP} ${VER} Setup"
VIAddVersionKey /LANG=1033 "FileVersion" "${VERFULL}"
VIAddVersionKey /LANG=1033 "ProductVersion" "${VER}"
VIAddVersionKey /LANG=1033 "LegalCopyright" "${PUB}"
VIAddVersionKey /LANG=1049 "ProductName" "${APP}"
VIAddVersionKey /LANG=1049 "CompanyName" "${PUB}"
VIAddVersionKey /LANG=1049 "FileDescription" "Установка ${APP} ${VER}"
VIAddVersionKey /LANG=1049 "FileVersion" "${VERFULL}"
VIAddVersionKey /LANG=1049 "ProductVersion" "${VER}"
VIAddVersionKey /LANG=1049 "LegalCopyright" "${PUB}"

!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"
!include "StrFunc.nsh"
${StrStr}
${StrRep}

!define MUI_ICON   "gfx\installer.ico"
!define MUI_UNICON "gfx\installer.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP   "gfx\side_100.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "gfx\side_100.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_RIGHT
!define MUI_HEADERIMAGE_BITMAP   "gfx\head_100.bmp"
!define MUI_HEADERIMAGE_UNBITMAP "gfx\head_100.bmp"
!define MUI_ABORTWARNING
!define MUI_CUSTOMFUNCTION_GUIINIT   MyGuiInit
!define MUI_CUSTOMFUNCTION_UNGUIINIT un.MyGuiInit

Var SideBmp
Var HeadBmp
Var ReqLink

; ---------------------------------------------------------------- pages
!define MUI_WELCOMEPAGE_TITLE "$(WelcomeTitle)"
!define MUI_WELCOMEPAGE_TEXT  "$(WelcomeText)"
!define MUI_PAGE_CUSTOMFUNCTION_SHOW WelcomeShow
!insertmacro MUI_PAGE_WELCOME
Page custom ReqPage
!define MUI_DIRECTORYPAGE_TEXT_TOP         "$(DirTop)"
!define MUI_DIRECTORYPAGE_TEXT_DESTINATION "$(DirDest)"
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE DirLeave
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_TITLE "$(FinishTitle)"
!define MUI_FINISHPAGE_TEXT  "$(FinishText)"
!define MUI_FINISHPAGE_LINK  "$(FinishLink)"
!define MUI_FINISHPAGE_LINK_LOCATION "${PSAPP}"
!define MUI_PAGE_CUSTOMFUNCTION_SHOW FinishShow
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; first language = fallback; the installer picks the one that matches the Windows display language
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "Russian"

; ---------------------------------------------------------------- texts
LangString WelcomeTitle ${LANG_ENGLISH} "EnshroudedSense ${VER} Setup"
LangString WelcomeTitle ${LANG_RUSSIAN} "Установка EnshroudedSense ${VER}"
LangString WelcomeText ${LANG_ENGLISH} "Brings the DualSense features of Enshrouded's PS5 version to PC: adaptive triggers, HD haptics (surfaces, footsteps, hits), the controller speaker, the lightbar (health, water, the Shroud), gyro aiming and the touchpad (map, wheels, lists).$\r$\n$\r$\nby MeT1oR and Tianku$\r$\n$\r$\nClick Next to continue."
LangString WelcomeText ${LANG_RUSSIAN} "Мод возвращает в Enshrouded на ПК возможности DualSense из версии для PS5: адаптивные курки, HD-вибрацию (поверхности, шаги, удары), динамик геймпада, подсветку (здоровье, вода, Пелена), гироприцеливание и сенсорную панель (карта, колёса, списки).$\r$\n$\r$\nАвторы: MeT1oR и Tianku$\r$\n$\r$\nНажмите «Далее», чтобы продолжить."

LangString ReqTitle ${LANG_ENGLISH} "Before you install"
LangString ReqTitle ${LANG_RUSSIAN} "Перед установкой"
LangString ReqSub ${LANG_ENGLISH} "What EnshroudedSense needs to work"
LangString ReqSub ${LANG_RUSSIAN} "Что нужно, чтобы мод работал"
LangString ReqText1 ${LANG_ENGLISH} "• A DualSense or DualSense Edge controller with the latest firmware. Sony's free PlayStation Accessories app updates it on a Windows PC:"
LangString ReqText1 ${LANG_RUSSIAN} "• Геймпад DualSense или DualSense Edge с последней прошивкой. Обновить её на ПК можно бесплатным приложением Sony «PlayStation Accessories» для Windows:"
LangString ReqLinkText ${LANG_ENGLISH} "Download PlayStation Accessories for Windows"
LangString ReqLinkText ${LANG_RUSSIAN} "Скачать PlayStation Accessories для Windows"
LangString ReqText2 ${LANG_ENGLISH} "• HD haptics and the controller speaker work over a USB cable.$\r$\n• Steam Input is off for Enshrouded: Steam > Enshrouded > Properties > Controller > Disable Steam Input.$\r$\n• Close DSX, DS4Windows and other programs that take over the DualSense.$\r$\n• Windows 10 or 11, 64-bit. Enshrouded for PC (Steam or another launcher)."
LangString ReqText2 ${LANG_RUSSIAN} "• HD-вибрация и динамик геймпада работают при подключении по USB-кабелю.$\r$\n• Steam Input для Enshrouded выключен: Steam > Enshrouded > Свойства > Контроллер > «Отключить Steam Input».$\r$\n• Закрыты DSX, DS4Windows и другие программы, которые управляют DualSense.$\r$\n• Windows 10 или 11, 64-бит. Enshrouded для ПК (Steam или другой лаунчер)."

LangString DirTop ${LANG_ENGLISH} "Choose the Enshrouded game folder (the one with enshrouded.exe). A Steam install is found automatically; for another launcher or a copy somewhere else, pick the folder with Browse."
LangString DirTop ${LANG_RUSSIAN} "Выберите папку с игрой Enshrouded (в ней лежит enshrouded.exe). Если игра из Steam, папка найдена автоматически. Если у вас другой лаунчер или игра лежит в другом месте, укажите папку через «Обзор...»."
LangString DirDest ${LANG_ENGLISH} "Enshrouded game folder"
LangString DirDest ${LANG_RUSSIAN} "Папка игры Enshrouded"
LangString NoExe ${LANG_ENGLISH} "There is no enshrouded.exe in this folder.$\r$\n$\r$\nInstall here anyway?"
LangString NoExe ${LANG_RUSSIAN} "В этой папке нет enshrouded.exe.$\r$\n$\r$\nВсё равно установить сюда?"
LangString OtherBuild ${LANG_ENGLISH} "This game version differs from the one EnshroudedSense ${VER} was made for. The mod checks the game when it starts: whatever does not match simply stays off and the game runs normally. Setup will continue."
LangString OtherBuild ${LANG_RUSSIAN} "Версия игры отличается от той, под которую сделан EnshroudedSense ${VER}. Мод проверяет игру при запуске: то, что не совпадёт, просто не включится, а игра будет работать как обычно. Установка продолжится."
LangString GameRunning ${LANG_ENGLISH} "Enshrouded is running. Close the game and click Retry."
LangString GameRunning ${LANG_RUSSIAN} "Enshrouded сейчас запущена. Закройте игру и нажмите «Повтор»."
LangString Backup ${LANG_ENGLISH} "Kept a copy of the existing file (restored on uninstall):"
LangString Backup ${LANG_RUSSIAN} "Сохранена копия прежнего файла (вернётся при удалении):"

LangString FinishTitle ${LANG_ENGLISH} "EnshroudedSense is installed"
LangString FinishTitle ${LANG_RUSSIAN} "EnshroudedSense установлен"
LangString FinishText ${LANG_ENGLISH} "Connect the DualSense and start Enshrouded.$\r$\n$\r$\nSettings: EnshroudedSense.ini in the game folder (it appears after the first start).$\r$\n$\r$\nTo remove the mod: Settings > Apps, or EnshroudedSense_Uninstall.exe in the game folder."
LangString FinishText ${LANG_RUSSIAN} "Подключите DualSense и запустите Enshrouded.$\r$\n$\r$\nНастройки мода: файл EnshroudedSense.ini в папке игры (появится после первого запуска).$\r$\n$\r$\nУдалить мод: «Параметры > Приложения» или EnshroudedSense_Uninstall.exe в папке игры."
LangString FinishLink ${LANG_ENGLISH} "Update the DualSense firmware (PlayStation Accessories)"
LangString FinishLink ${LANG_RUSSIAN} "Обновить прошивку DualSense (PlayStation Accessories)"

; ---------------------------------------------------------------- crisp pictures at any display scale
; the wizard pictures are swapped for the version made for the current DPI (exact control size, no stretching)
!macro PICK_DPI_BITMAPS UN
Function ${UN}PickBitmaps
  System::Call 'user32::GetDpiForWindow(p $HWNDPARENT) i .r0'
  ${If} $0 == "error"
  ${OrIf} $0 < 1
    System::Call 'user32::GetDC(p 0) p .r1'
    System::Call 'gdi32::GetDeviceCaps(p r1, i 88) i .r0'
    System::Call 'user32::ReleaseDC(p 0, p r1)'
  ${EndIf}
  IntOp $0 $0 * 100
  IntOp $0 $0 / 96
  ${If} $0 < 113
    StrCpy $0 100
  ${ElseIf} $0 < 138
    StrCpy $0 125
  ${ElseIf} $0 < 163
    StrCpy $0 150
  ${ElseIf} $0 < 188
    StrCpy $0 175
  ${ElseIf} $0 < 225
    StrCpy $0 200
  ${Else}
    StrCpy $0 250
  ${EndIf}
  StrCpy $SideBmp "$PLUGINSDIR\side_$0.bmp"
  StrCpy $HeadBmp "$PLUGINSDIR\head_$0.bmp"
FunctionEnd
Function ${UN}MyGuiInit
  Call ${UN}PickBitmaps
  SetBrandingImage /IMGID=1046 /RESIZETOFIT "$HeadBmp"
FunctionEnd
!macroend
!insertmacro PICK_DPI_BITMAPS ""
!insertmacro PICK_DPI_BITMAPS "un."

!macro EXTRACT_BITMAPS
  InitPluginsDir
  File "/oname=$PLUGINSDIR\side_100.bmp" "gfx\side_100.bmp"
  File "/oname=$PLUGINSDIR\side_125.bmp" "gfx\side_125.bmp"
  File "/oname=$PLUGINSDIR\side_150.bmp" "gfx\side_150.bmp"
  File "/oname=$PLUGINSDIR\side_175.bmp" "gfx\side_175.bmp"
  File "/oname=$PLUGINSDIR\side_200.bmp" "gfx\side_200.bmp"
  File "/oname=$PLUGINSDIR\side_250.bmp" "gfx\side_250.bmp"
  File "/oname=$PLUGINSDIR\head_100.bmp" "gfx\head_100.bmp"
  File "/oname=$PLUGINSDIR\head_125.bmp" "gfx\head_125.bmp"
  File "/oname=$PLUGINSDIR\head_150.bmp" "gfx\head_150.bmp"
  File "/oname=$PLUGINSDIR\head_175.bmp" "gfx\head_175.bmp"
  File "/oname=$PLUGINSDIR\head_200.bmp" "gfx\head_200.bmp"
  File "/oname=$PLUGINSDIR\head_250.bmp" "gfx\head_250.bmp"
!macroend

Function WelcomeShow
  ${NSD_FreeImage} $mui.WelcomePage.Image.Bitmap
  ${NSD_SetStretchedImage} $mui.WelcomePage.Image "$SideBmp" $mui.WelcomePage.Image.Bitmap
FunctionEnd
Function FinishShow
  ${NSD_FreeImage} $mui.FinishPage.Image.Bitmap
  ${NSD_SetStretchedImage} $mui.FinishPage.Image "$SideBmp" $mui.FinishPage.Image.Bitmap
FunctionEnd

; ---------------------------------------------------------------- requirements page
Function ReqPage
  !insertmacro MUI_HEADER_TEXT "$(ReqTitle)" "$(ReqSub)"
  nsDialogs::Create 1018
  Pop $0
  ${If} $0 == error
    Abort
  ${EndIf}
  ${NSD_CreateLabel} 0 0 100% 30u "$(ReqText1)"
  Pop $0
  ${NSD_CreateLink} 8u 32u 92% 12u "$(ReqLinkText)"
  Pop $ReqLink
  SetCtlColors $ReqLink 0066CC transparent
  ${NSD_OnClick} $ReqLink ReqLinkClick
  ${NSD_CreateLabel} 0 50u 100% 90u "$(ReqText2)"
  Pop $0
  nsDialogs::Show
FunctionEnd
Function ReqLinkClick
  ExecShell "open" "${PSAPP}"
FunctionEnd

; ---------------------------------------------------------------- finding the game
Function TryDir          ; $R9 = candidate folder; first hit wins ($R8 = 1)
  ${If} $R8 != 1
  ${AndIf} $R9 != ""
  ${AndIf} ${FileExists} "$R9\enshrouded.exe"
    StrCpy $INSTDIR $R9
    StrCpy $R8 1
  ${EndIf}
FunctionEnd

Function QuotedValue     ; $R4 = text after a key; returns the first "quoted" value in $R3 (VDF escapes undone)
  StrCpy $R3 ""
  StrCpy $R2 0
  StrCpy $R1 0
  ${Do}
    StrCpy $R0 $R4 1 $R2
    ${If} $R0 == ""
      ${ExitDo}
    ${EndIf}
    IntOp $R2 $R2 + 1
    ${If} $R0 == '"'
      ${If} $R1 == 0
        StrCpy $R1 1
        ${Continue}
      ${EndIf}
      ${ExitDo}
    ${EndIf}
    ${If} $R1 == 1
      StrCpy $R3 "$R3$R0"
    ${EndIf}
  ${Loop}
  ${StrRep} $R3 $R3 "\\" "\"
FunctionEnd

Function DetectGame
  StrCpy $R8 0
  ; 1. where this mod was installed before
  SetRegView 64
  ReadRegStr $R9 HKLM "${UKEY}" "InstallLocation"
  Call TryDir
  ; 2. Steam's own uninstall entry for Enshrouded (app 1203620)
  ReadRegStr $R9 HKLM "${STEAMKEY}" "InstallLocation"
  Call TryDir
  SetRegView 32
  ReadRegStr $R9 HKLM "${STEAMKEY}" "InstallLocation"
  Call TryDir
  ; 3. every Steam library listed in libraryfolders.vdf
  ReadRegStr $R7 HKCU "Software\Valve\Steam" "SteamPath"
  ${If} $R7 == ""
    ReadRegStr $R7 HKLM "SOFTWARE\Valve\Steam" "InstallPath"
  ${EndIf}
  SetRegView 64
  ${StrRep} $R7 $R7 "/" "\"
  ${If} $R7 != ""
    StrCpy $R9 "$R7\steamapps\common\Enshrouded"
    Call TryDir
    ClearErrors
    FileOpen $R6 "$R7\steamapps\libraryfolders.vdf" r
    ${IfNot} ${Errors}
      ${Do}
        ClearErrors
        FileRead $R6 $R5
        ${If} ${Errors}
          ${ExitDo}
        ${EndIf}
        ${StrStr} $R4 $R5 '"path"'
        ${If} $R4 != ""
          StrCpy $R4 $R4 "" 6
          Call QuotedValue
          StrCpy $R9 "$R3\steamapps\common\Enshrouded"
          Call TryDir
        ${EndIf}
      ${Loop}
      FileClose $R6
    ${EndIf}
  ${EndIf}
  ; 4. usual places on every drive (other launchers, copies)
  ${If} $R8 != 1
    System::Call 'kernel32::SetErrorMode(i 0x8001) i .r0'
    StrCpy $R2 0
    ${Do}
      StrCpy $R0 "CDEFGHIJKLMNOPQRSTUVWXYZ" 1 $R2
      ${If} $R0 == ""
      ${OrIf} $R8 == 1
        ${ExitDo}
      ${EndIf}
      IntOp $R2 $R2 + 1
      ${If} ${FileExists} "$R0:\*.*"
        StrCpy $R9 "$R0:\SteamLibrary\steamapps\common\Enshrouded"
        Call TryDir
        StrCpy $R9 "$R0:\Steam\steamapps\common\Enshrouded"
        Call TryDir
        StrCpy $R9 "$R0:\Program Files (x86)\Steam\steamapps\common\Enshrouded"
        Call TryDir
        StrCpy $R9 "$R0:\Program Files\Steam\steamapps\common\Enshrouded"
        Call TryDir
        StrCpy $R9 "$R0:\Games\Steam\steamapps\common\Enshrouded"
        Call TryDir
        StrCpy $R9 "$R0:\Games\Enshrouded"
        Call TryDir
        StrCpy $R9 "$R0:\Enshrouded"
        Call TryDir
      ${EndIf}
    ${Loop}
  ${EndIf}
  ${If} $R8 != 1
    StrCpy $INSTDIR "$PROGRAMFILES32\Steam\steamapps\common\Enshrouded"
  ${EndIf}
FunctionEnd

; the game must not be running (its DLLs would be in use)
!macro GAME_NOT_RUNNING UN
Function ${UN}WaitForGameClosed
  ${Do}
    ${IfNot} ${FileExists} "$INSTDIR\enshrouded.exe"
      ${ExitDo}
    ${EndIf}
    ClearErrors
    FileOpen $0 "$INSTDIR\enshrouded.exe" a
    ${IfNot} ${Errors}
      FileClose $0
      ${ExitDo}
    ${EndIf}
    MessageBox MB_RETRYCANCEL|MB_ICONEXCLAMATION "$(GameRunning)" /SD IDCANCEL IDRETRY +2
    Quit
  ${Loop}
FunctionEnd
!macroend
!insertmacro GAME_NOT_RUNNING ""
!insertmacro GAME_NOT_RUNNING "un."

Function .onInit
  !insertmacro EXTRACT_BITMAPS
  Call DetectGame
FunctionEnd

Function DirLeave
  ${IfNot} ${FileExists} "$INSTDIR\enshrouded.exe"
    MessageBox MB_YESNO|MB_ICONEXCLAMATION "$(NoExe)" /SD IDNO IDYES dir_ok
    Abort
  ${Else}
    ClearErrors
    FileOpen $0 "$INSTDIR\enshrouded.exe" r
    ${IfNot} ${Errors}
      FileSeek $0 0 END $1
      FileClose $0
      ${If} $1 <> ${GAMESIZE}
        MessageBox MB_OK|MB_ICONINFORMATION "$(OtherBuild)" /SD IDOK
      ${EndIf}
    ${EndIf}
  ${EndIf}
  dir_ok:
FunctionEnd

; ---------------------------------------------------------------- install
Section "EnshroudedSense" SecMain
  SectionIn RO
  Call WaitForGameClosed
  SetOutPath "$INSTDIR"
  ; DLLs of another mod / tool with the same names are kept and come back on uninstall.
  ; Files of an earlier EnshroudedSense (its .ini or .log is there) are simply replaced.
  ${IfNot} ${FileExists} "$INSTDIR\EnshroudedSense.ini"
  ${AndIfNot} ${FileExists} "$INSTDIR\EnshroudedSense.log"
  ${AndIfNot} ${FileExists} "$INSTDIR\${UNINST}"
    ${If} ${FileExists} "$INSTDIR\dinput8.dll"
    ${AndIfNot} ${FileExists} "$INSTDIR\EnshroudedSense_backup\dinput8.dll"
      CreateDirectory "$INSTDIR\EnshroudedSense_backup"
      CopyFiles /SILENT "$INSTDIR\dinput8.dll" "$INSTDIR\EnshroudedSense_backup"
      DetailPrint "$(Backup) dinput8.dll"
    ${EndIf}
    ${If} ${FileExists} "$INSTDIR\xinput1_4.dll"
    ${AndIfNot} ${FileExists} "$INSTDIR\EnshroudedSense_backup\xinput1_4.dll"
      CreateDirectory "$INSTDIR\EnshroudedSense_backup"
      CopyFiles /SILENT "$INSTDIR\xinput1_4.dll" "$INSTDIR\EnshroudedSense_backup"
      DetailPrint "$(Backup) xinput1_4.dll"
    ${EndIf}
  ${EndIf}
  SetOverwrite on
  File "files\dinput8.dll"
  File "files\xinput1_4.dll"
  ; EnshroudedSense.ini is written by the mod itself on the first game start (an existing one is kept)
  WriteUninstaller "$INSTDIR\${UNINST}"
  SetRegView 64
  WriteRegStr   HKLM "${UKEY}" "DisplayName" "${APP}"
  WriteRegStr   HKLM "${UKEY}" "DisplayVersion" "${VER}"
  WriteRegStr   HKLM "${UKEY}" "Publisher" "${PUB}"
  WriteRegStr   HKLM "${UKEY}" "DisplayIcon" "$INSTDIR\${UNINST}"
  WriteRegStr   HKLM "${UKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr   HKLM "${UKEY}" "UninstallString" '"$INSTDIR\${UNINST}"'
  WriteRegStr   HKLM "${UKEY}" "QuietUninstallString" '"$INSTDIR\${UNINST}" /S'
  WriteRegStr   HKLM "${UKEY}" "URLInfoAbout" "${PSAPP}"
  WriteRegDWORD HKLM "${UKEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UKEY}" "NoRepair" 1
  WriteRegDWORD HKLM "${UKEY}" "EstimatedSize" 700
SectionEnd

; ---------------------------------------------------------------- uninstall
Function un.onInit
  SetRegView 64
  !insertmacro EXTRACT_BITMAPS
FunctionEnd

Section "Uninstall"
  Call un.WaitForGameClosed
  Delete "$INSTDIR\dinput8.dll"
  Delete "$INSTDIR\xinput1_4.dll"
  ${If} ${FileExists} "$INSTDIR\EnshroudedSense_backup\dinput8.dll"
    Rename "$INSTDIR\EnshroudedSense_backup\dinput8.dll" "$INSTDIR\dinput8.dll"
  ${EndIf}
  ${If} ${FileExists} "$INSTDIR\EnshroudedSense_backup\xinput1_4.dll"
    Rename "$INSTDIR\EnshroudedSense_backup\xinput1_4.dll" "$INSTDIR\xinput1_4.dll"
  ${EndIf}
  RMDir /r "$INSTDIR\EnshroudedSense_backup"
  Delete "$INSTDIR\EnshroudedSense.ini"
  Delete "$INSTDIR\EnshroudedSense.log"
  Delete "$INSTDIR\EnshroudedSense_early.log"
  Delete "$INSTDIR\EnshroudedSense_load.txt"
  Delete "$INSTDIR\EnshroudedSense_Diag.txt"
  Delete "$INSTDIR\EnshroudedSense_*source.c"
  Delete "$INSTDIR\${UNINST}"
  SetRegView 64
  DeleteRegKey HKLM "${UKEY}"
SectionEnd
