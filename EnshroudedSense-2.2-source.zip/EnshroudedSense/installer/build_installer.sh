#!/bin/sh
# NSIS 3.09+ (makensis). Run ../build.sh first.
set -e
cd "$(dirname "$0")"
mkdir -p files out
cp ../build/dinput8.dll ../build/xinput1_4.dll files/
makensis EnshroudedSense.nsi
