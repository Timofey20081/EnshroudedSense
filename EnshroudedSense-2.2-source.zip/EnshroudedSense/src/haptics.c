// EnshroudedSense - DualSense HD haptics over USB audio.
// On USB the DualSense exposes a 4-channel audio endpoint: channels 1/2 = speaker/headset,
// channels 3/4 = the two voice-coil haptic actuators (left / right). PS5 drives its "HD haptics"
// through those channels. We open that endpoint with WASAPI and synthesize waveforms for the
// game's vibration events (and weapon recoil), so the controller gets real haptics instead of
// classic rumble emulation.
#define WIN32_LEAN_AND_MEAN
#define COBJMACROS
#define INITGUID
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <functiondiscoverykeys_devpkey.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include "haptics.h"

DEFINE_GUID(HS_CLSID_MMDeviceEnumerator, 0xBCDE0395, 0xE52F, 0x467C, 0x8E, 0x3D, 0xC4, 0x57, 0x92, 0x91, 0x69, 0x2E);
DEFINE_GUID(HS_IID_IMMDeviceEnumerator, 0xA95664D2, 0x9614, 0x4F35, 0xA7, 0x46, 0xDE, 0x8D, 0xB6, 0x36, 0x17, 0xE6);
DEFINE_GUID(HS_IID_IAudioClient, 0x1CB9AD4C, 0xDBFA, 0x4C32, 0xB1, 0x78, 0xC2, 0xF5, 0x68, 0xA7, 0x03, 0xB2);
DEFINE_GUID(HS_IID_IAudioRenderClient, 0xF294ACFC, 0x3146, 0x4483, 0xA7, 0xBF, 0xAD, 0xDC, 0xA7, 0xC2, 0x60, 0xE2);
DEFINE_GUID(HS_KSDATAFORMAT_SUBTYPE_IEEE_FLOAT, 0x00000003, 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71);

typedef struct { int kind; float amp; } HapEv;
static HapEv g_ev[64]; static volatile LONG g_evHead;
static volatile LONG g_active;           // 1 = haptics endpoint is running
static volatile LONG g_quitH;
static HapLogFn g_log;
static HapticsConfig g_cfg;
typedef int (*PFN_ReadAudio)(int which, float *outLR, int frames);
typedef int (*PFN_AudioStatus)(int *blocks, int *vibPeak, int *spkPeak);
typedef LONG (*PFN_UiEvents)(void);
static PFN_ReadAudio p_ReadAudio; static PFN_AudioStatus p_AudioStatus; static PFN_UiEvents p_UiEvents;
static volatile LONG g_gameSrc;       // 1 = real game vibration waveform is being received
int Haptics_GameSource(void) { return g_gameSrc; }
void Haptics_Status(int *blocks, int *vibPeak, int *spkPeak) {
    if (p_AudioStatus) p_AudioStatus(blocks, vibPeak, spkPeak); else { *blocks = 0; *vibPeak = 0; *spkPeak = 0; } }

void Haptics_Push(int kind, float amp) {
    LONG h = InterlockedIncrement(&g_evHead) - 1;
    g_ev[h & 63].kind = kind; g_ev[h & 63].amp = amp;
}
int Haptics_Active(void) { return g_active; }

static volatile LONG g_waterMilli;      // target water texture level * 1000
void Haptics_SetWater(float level) { if (level < 0) level = 0; if (level > 1.5f) level = 1.5f; InterlockedExchange(&g_waterMilli, (LONG)(level * 1000)); }

typedef struct { double t, dur, decay, f1, f2, amp, ph1, ph2; int on; } Voice;
static Voice V[24];

static void StartVoice(int kind, float amp, double sr) {
    double f1, f2, decay, dur;
    switch (kind) {
    case HAP_BOW:     f1 = g_cfg.bowF1;   f2 = g_cfg.bowF2;   decay = g_cfg.bowDecay;   break;   // string snap
    case HAP_SPELL:   f1 = g_cfg.spellF1; f2 = g_cfg.spellF2; decay = g_cfg.spellDecay; break;   // magical thrum
    case HAP_ABILITY: f1 = g_cfg.abilF1;  f2 = g_cfg.abilF2;  decay = g_cfg.abilDecay;  break;
    case HAP_TEST:    f1 = 90; f2 = 180; decay = 0.08; break;
    case HAP_UI:      f1 = g_cfg.tickF1;  f2 = g_cfg.tickF2;  decay = g_cfg.tickDecay;  break;   // menu click
    case HAP_SHIELD_UP:  f1 = 70;  f2 = 140; decay = 0.030; break;   // dull "thock" of the shield coming up
    case HAP_WARD_UP:    f1 = 175; f2 = 262; decay = 0.090; break;   // short magical hum of the ward
    case HAP_SHIELD_HIT: f1 = 55;  f2 = 165; decay = 0.060; break;   // heavy knock with a ring
    case HAP_WARD_HIT:   f1 = 120; f2 = 240; decay = 0.080; break;   // bright magical impact
    case HAP_BLOCK_BREAK: f1 = 40; f2 = 85;  decay = 0.140; break;   // guard broken
    default:          f1 = g_cfg.gameF1;  f2 = g_cfg.gameF2;  decay = g_cfg.gameDecay;  break;   // game vibration sound
    }
    dur = decay * 5;
    int slot = 0; double oldest = -1;
    for (int i = 0; i < 24; i++) { if (!V[i].on) { slot = i; break; } if (V[i].t > oldest) { oldest = V[i].t; slot = i; } }
    Voice *v = &V[slot];
    v->t = 0; v->dur = dur; v->decay = decay; v->f1 = f1; v->f2 = f2; v->amp = amp; v->ph1 = v->ph2 = 0; v->on = 1;
    (void)sr;
}

static double NextSample(double sr) {
    double s = 0;
    for (int i = 0; i < 24; i++) {
        Voice *v = &V[i]; if (!v->on) continue;
        double env = exp(-v->t / v->decay);
        double att = v->decay < 0.03 ? 0.0008 : 0.004;
        if (v->t < att) env *= v->t / att;                            // short attack, no click (sharper for ticks)
        s += v->amp * env * (0.65 * sin(v->ph1) + 0.35 * sin(v->ph2));
        v->ph1 += 2 * M_PI * v->f1 / sr; v->ph2 += 2 * M_PI * v->f2 / sr;
        v->t += 1.0 / sr;
        if (v->t > v->dur) v->on = 0;
    }
    // water: low rumbling noise (two low-passed noise bands) with a slow swell, level follows the game state
    {   static double lvl, lp1, lp2, ph; static uint32_t rnd = 0x1234567;
        double target = g_waterMilli / 1000.0 * g_cfg.waterGain;
        lvl += (target - lvl) * (target > lvl ? 0.0004 : 0.0002);              // ~50-100 ms fades
        if (lvl > 0.0005) {
            rnd = rnd * 1664525u + 1013904223u; double n = ((rnd >> 8) / 8388608.0) - 1.0;
            lp1 += (n - lp1) * 0.012;                                             // ~90 Hz band
            lp2 += (lp1 - lp2) * 0.05;
            ph += 2 * M_PI * 0.45 / sr; if (ph > 2 * M_PI) ph -= 2 * M_PI;
            double swell = 0.7 + 0.3 * sin(ph);
            s += lvl * swell * (lp1 * 6.0 + lp2 * 4.0);
        }
    }
    s *= g_cfg.gain;
    if (s > 1) s = 1; if (s < -1) s = -1;
    return s;
}

static int NameIsDualSense(const wchar_t *n) {
    return wcsstr(n, L"DualSense") || wcsstr(n, L"Wireless Controller");
}

static DWORD WINAPI HapticsThread(LPVOID _) {
    (void)_;
    CoInitializeEx(NULL, COINIT_MULTITHREADED);
    while (!g_quitH) {
        IMMDeviceEnumerator *en = NULL; IMMDeviceCollection *col = NULL; IMMDevice *dev = NULL;
        IAudioClient *ac = NULL; IAudioRenderClient *rc = NULL; WAVEFORMATEX *wf = NULL;
        HRESULT hr = CoCreateInstance(&HS_CLSID_MMDeviceEnumerator, NULL, CLSCTX_ALL, &HS_IID_IMMDeviceEnumerator, (void**)&en);
        if (FAILED(hr)) { g_log("haptics: no MMDeviceEnumerator (0x%08lX)", hr); break; }
        UINT n = 0;
        if (SUCCEEDED(IMMDeviceEnumerator_EnumAudioEndpoints(en, eRender, DEVICE_STATE_ACTIVE, &col)))
            IMMDeviceCollection_GetCount(col, &n);
        for (UINT i = 0; i < n && !dev; i++) {
            IMMDevice *d = NULL; IPropertyStore *ps = NULL; PROPVARIANT pv; PropVariantInit(&pv);
            if (FAILED(IMMDeviceCollection_Item(col, i, &d))) continue;
            if (SUCCEEDED(IMMDevice_OpenPropertyStore(d, STGM_READ, &ps)) &&
                SUCCEEDED(IPropertyStore_GetValue(ps, &PKEY_Device_FriendlyName, &pv)) && pv.vt == VT_LPWSTR) {
                if (NameIsDualSense(pv.pwszVal)) { dev = d; d = NULL; g_log("haptics: found audio endpoint '%ls'", pv.pwszVal); }
            }
            PropVariantClear(&pv);
            if (ps) IPropertyStore_Release(ps);
            if (d) IMMDevice_Release(d);
        }
        if (col) IMMDeviceCollection_Release(col);
        if (!dev) {
            static int warned; if (!warned++) g_log("haptics: DualSense audio endpoint not found (USB only) - using classic rumble");
            IMMDeviceEnumerator_Release(en); Sleep(3000); continue;
        }
        hr = IMMDevice_Activate(dev, &HS_IID_IAudioClient, CLSCTX_ALL, NULL, (void**)&ac);
        if (SUCCEEDED(hr)) hr = IAudioClient_GetMixFormat(ac, &wf);
        if (SUCCEEDED(hr) && wf->nChannels < 4) {
            g_log("haptics: endpoint has %u channels (needs 4: set the DualSense speaker to 4.0/quadraphonic in Windows sound settings)", wf->nChannels);
            hr = E_FAIL;
        }
        if (SUCCEEDED(hr)) hr = IAudioClient_Initialize(ac, AUDCLNT_SHAREMODE_SHARED, 0, 400000 /* 40 ms */, 0, wf, NULL);
        if (SUCCEEDED(hr)) hr = IAudioClient_GetService(ac, &HS_IID_IAudioRenderClient, (void**)&rc);
        UINT32 bufFrames = 0;
        if (SUCCEEDED(hr)) hr = IAudioClient_GetBufferSize(ac, &bufFrames);
        if (SUCCEEDED(hr)) hr = IAudioClient_Start(ac);
        if (FAILED(hr)) {
            g_log("haptics: could not open endpoint (0x%08lX) - using classic rumble", hr);
            if (rc) IAudioRenderClient_Release(rc); if (ac) IAudioClient_Release(ac); if (wf) CoTaskMemFree(wf);
            IMMDevice_Release(dev); IMMDeviceEnumerator_Release(en);
            Sleep(5000); continue;
        }
        int isFloat = wf->wFormatTag == WAVE_FORMAT_IEEE_FLOAT ||
            (wf->wFormatTag == WAVE_FORMAT_EXTENSIBLE && IsEqualGUID(&((WAVEFORMATEXTENSIBLE*)wf)->SubFormat, &HS_KSDATAFORMAT_SUBTYPE_IEEE_FLOAT));
        double sr = wf->nSamplesPerSec; int ch = wf->nChannels, bits = wf->wBitsPerSample;
        g_log("haptics: running %u Hz, %d ch, %d-bit %s, buffer %u frames", wf->nSamplesPerSec, ch, bits, isFloat ? "float" : "int", bufFrames);
        InterlockedExchange(&g_active, 1);
        Haptics_Push(HAP_TEST, 0.6f);                                   // short pulse so you can feel it works
        {   HMODULE di = GetModuleHandleW(L"dinput8.dll");
            p_ReadAudio = di ? (PFN_ReadAudio)GetProcAddress(di, "ES_ReadAudio") : NULL;
            p_AudioStatus = di ? (PFN_AudioStatus)GetProcAddress(di, "ES_AudioStatus") : NULL;
            p_UiEvents = di ? (PFN_UiEvents)GetProcAddress(di, "ES_UiEvents") : NULL;
            int st = p_AudioStatus ? p_AudioStatus(NULL, NULL, NULL) : 0;
            g_log("haptics: game audio capture %s (vibration group %s, speaker group %s)",
                  p_ReadAudio ? "available" : "NOT available", (st & 1) ? "ok" : "missing", (st & 2) ? "ok" : "missing");
        }
        static float vibLR[4096 * 2], spkLR[4096 * 2];
        LONG tail = g_evHead;
        LONG uiSeen = p_UiEvents ? p_UiEvents() : 0; DWORD lastTick = 0;
        while (!g_quitH) {
            while (tail != g_evHead) { HapEv e = g_ev[tail & 63]; tail++; StartVoice(e.kind, e.amp, sr); }
            if (p_UiEvents) {                                           // the game played a UI sound -> one crisp tick
                LONG ui = p_UiEvents();
                if (ui != uiSeen) {
                    DWORD now = GetTickCount();
                    if (g_cfg.tickAmp > 0 && now - lastTick > 35) { StartVoice(HAP_UI, (float)g_cfg.tickAmp, sr); lastTick = now; }
                    uiSeen = ui;
                }
            }
            UINT32 pad = 0;
            hr = IAudioClient_GetCurrentPadding(ac, &pad);
            if (FAILED(hr)) break;                                      // device unplugged
            UINT32 want = bufFrames - pad;
            if (want > 0) {
                BYTE *p = NULL;
                hr = IAudioRenderClient_GetBuffer(rc, want, &p);
                if (FAILED(hr)) break;
                if (want > 4096) want = 4096;
                int nv = 0, ns = 0;
                if (p_ReadAudio && sr == 48000) {
                    if (g_cfg.gameHaptics) nv = p_ReadAudio(0, vibLR, (int)want);
                    if (g_cfg.speakerVol > 0) ns = p_ReadAudio(1, spkLR, (int)want);
                    if (nv > 0) InterlockedExchange(&g_gameSrc, 1);
                }
                for (UINT32 f = 0; f < want; f++) {
                    double s = NextSample(sr);
                    double hl = s * g_cfg.left, hr2 = s * g_cfg.right;
                    if ((int)f < nv) { hl += vibLR[f * 2] * g_cfg.gameGain * g_cfg.left; hr2 += vibLR[f * 2 + 1] * g_cfg.gameGain * g_cfg.right; }
                    double sm = (int)f < ns ? (spkLR[f * 2] + spkLR[f * 2 + 1]) * 0.5 * g_cfg.speakerVol : 0;   // mono: the speaker plays channel 2
                    double sl = sm, sr2 = sm;
                    if (hl > 1) hl = 1; if (hl < -1) hl = -1; if (hr2 > 1) hr2 = 1; if (hr2 < -1) hr2 = -1;
                    if (sl > 1) sl = 1; if (sl < -1) sl = -1; if (sr2 > 1) sr2 = 1; if (sr2 < -1) sr2 = -1;
                    for (int c = 0; c < ch; c++) {
                        double v = c == 0 ? sl : c == 1 ? sr2 : c == 2 ? hl : c == 3 ? hr2 : 0.0;   // 1/2 speaker, 3/4 haptics
                        if (isFloat && bits == 32) ((float*)p)[f * ch + c] = (float)v;
                        else if (bits == 16) ((short*)p)[f * ch + c] = (short)(v * 32767);
                        else if (bits == 32) ((int*)p)[f * ch + c] = (int)(v * 2147483647.0);
                        else if (bits == 24) { int x = (int)(v * 8388607); BYTE *q = p + (f * ch + c) * 3; q[0] = x; q[1] = x >> 8; q[2] = x >> 16; }
                    }
                }
                IAudioRenderClient_ReleaseBuffer(rc, want, 0);
            }
            Sleep(4);
        }
        InterlockedExchange(&g_active, 0);
        g_log("haptics: endpoint stopped (0x%08lX), reopening", hr);
        IAudioClient_Stop(ac);
        IAudioRenderClient_Release(rc); IAudioClient_Release(ac); CoTaskMemFree(wf);
        IMMDevice_Release(dev); IMMDeviceEnumerator_Release(en);
        Sleep(1000);
    }
    CoUninitialize();
    return 0;
}

void Haptics_Start(const HapticsConfig *cfg, HapLogFn log) {
    g_cfg = *cfg; g_log = log;
    CreateThread(NULL, 0, HapticsThread, NULL, 0, NULL);
}
void Haptics_Stop(void) { g_quitH = 1; }
