#pragma once
enum { HAP_GAME = 0, HAP_BOW = 1, HAP_SPELL = 2, HAP_ABILITY = 3, HAP_UI = 4, HAP_SHIELD_UP = 5, HAP_WARD_UP = 6,
       HAP_SHIELD_HIT = 7, HAP_WARD_HIT = 8, HAP_TEST = 9, HAP_BLOCK_BREAK = 10 };
typedef void (*HapLogFn)(const char *fmt, ...);
typedef struct {
    double gain, left, right;
    double gameF1, gameF2, gameDecay;
    double bowF1, bowF2, bowDecay;
    double spellF1, spellF2, spellDecay;
    double abilF1, abilF2, abilDecay;
    int gameHaptics; double gameGain;     // real game vibration waveform (captured from the engine)
    double speakerVol;                    // game "gamepad speaker" sounds -> controller speaker (0 = off)
    double waterGain;                     // water texture while swimming / diving (0 = off)
    double tickAmp, tickF1, tickF2, tickDecay;   // haptic tick on every game UI sound (0 = off)
} HapticsConfig;
void Haptics_Start(const HapticsConfig *cfg, HapLogFn log);
void Haptics_Stop(void);
void Haptics_Push(int kind, float amp);
int  Haptics_Active(void);
int  Haptics_GameSource(void);
void Haptics_Status(int *blocks, int *vibPeak, int *spkPeak);
void Haptics_SetWater(float level);       // 0..1 water texture intensity (game state driven)
