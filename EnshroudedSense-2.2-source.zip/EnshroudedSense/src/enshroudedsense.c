// EnshroudedSense 2.0 - restores Enshrouded's own DualSense features on PC
// Drop-in xinput1_4.dll proxy placed next to enshrouded.exe.
//  * reads the DualSense / DualSense Edge directly over HID (USB or Bluetooth)
//  * presents it to the game as XInput pad 0 (no DSX / ViGEm / Steam Input needed)
//  * forwards the game's own rumble to the DualSense motors, unchanged
//  * hooks the game's own AdaptiveTriggerSystem output. The client system
//    "client_player_adaptive_triggers" computes the current AdaptiveTriggerEffect
//    every frame (bow / spell / special ability / fishing) and hands it to a
//    platform function that is an empty stub (ret) in the PC build. We replace
//    that stub and send the effect to the controller.
// When no DualSense is found, every call is passed to the real system xinput1_4.dll.

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <setupapi.h>
#include <hidsdi.h>
#include <hidpi.h>
#include <tlhelp32.h>
#include "haptics.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <wctype.h>

// ---------------------------------------------------------------- XInput types
typedef struct {
    WORD  wButtons;
    BYTE  bLeftTrigger, bRightTrigger;
    SHORT sThumbLX, sThumbLY, sThumbRX, sThumbRY;
} XGAMEPAD;
typedef struct { DWORD dwPacketNumber; XGAMEPAD Gamepad; } XSTATE;
typedef struct { WORD wLeftMotorSpeed, wRightMotorSpeed; } XVIBRATION;
typedef struct { BYTE Type, SubType; WORD Flags; XGAMEPAD Gamepad; XVIBRATION Vibration; } XCAPS;
typedef struct { BYTE BatteryType, BatteryLevel; } XBATTERY;

#define XB_UP 0x0001
#define XB_DOWN 0x0002
#define XB_LEFT 0x0004
#define XB_RIGHT 0x0008
#define XB_START 0x0010
#define XB_BACK 0x0020
#define XB_LTHUMB 0x0040
#define XB_RTHUMB 0x0080
#define XB_LSHOULDER 0x0100
#define XB_RSHOULDER 0x0200
#define XB_GUIDE 0x0400
#define XB_A 0x1000
#define XB_B 0x2000
#define XB_X 0x4000
#define XB_Y 0x8000

// ---------------------------------------------------------------- real xinput
typedef DWORD (WINAPI *PFN_GetState)(DWORD, XSTATE*);
typedef DWORD (WINAPI *PFN_SetState)(DWORD, XVIBRATION*);
typedef DWORD (WINAPI *PFN_GetCaps)(DWORD, DWORD, XCAPS*);
typedef void  (WINAPI *PFN_Enable)(BOOL);
typedef DWORD (WINAPI *PFN_GetBattery)(DWORD, BYTE, XBATTERY*);
typedef DWORD (WINAPI *PFN_GetKeystroke)(DWORD, DWORD, void*);
typedef DWORD (WINAPI *PFN_GetAudio)(DWORD, LPWSTR, UINT*, LPWSTR, UINT*);

static HMODULE g_real;
static PFN_GetState r_GetState, r_GetStateEx;
static PFN_SetState r_SetState;
static PFN_GetCaps r_GetCaps;
static PFN_Enable r_Enable;
static PFN_GetBattery r_GetBattery;
static PFN_GetKeystroke r_GetKeystroke;
static PFN_GetAudio r_GetAudio;

// ---------------------------------------------------------------- config
typedef struct { int trig; int mode; int p1, p2, p3; } Eff; // trig: 1=R2 2=L2 3=both
typedef struct {
    int enabled;
    int realPadsToo;          // also expose real Xbox pads as players 2..4
    int rumbleScale;          // percent
    int triggersEnabled;
    int triggerStrength;      // percent, scales all trigger forces
    int respectGameSetting;   // obey the game's AdaptiveTriggerStrength (Off/Normal)
    Eff eff[16];
    int lightbar;             // 0 = leave the controller's default lightbar alone
    int lightR, lightG, lightB, playerLed;
    int lbMode;               // 0 off, 1 game state (health / underwater / shroud), 2 static colour
    int lbLowHealth;          // percent: heartbeat below this
    int lbPlayerLeds;         // white player LEDs show your number in the session
    int blockFx, blockWard; double blockStrength;
    double lbShroudHz, lbBright;
    int touchpadAs;           // 0 = Back(View), 1 = Start, 2 = none
    int touchOn, touchOverride; BYTE touchCfg[0x1c];   // the game's own InputSettingsTouchPad (PS5 "Touch controls")
    int qwOpen, ewOpen;       // wheels "open on touch" (applied on top of the game's settings), -1 = leave as is
    int uiTouch, uiDragStep, uiDiag; double uiPinchStep, uiRotStep;   // [TouchpadMenus]
    double mapDrag;           // [Touchpad] MapDragSpeed: UI pixels the map moves per pad pixel
    int spkHw, spkHwVol, spkPath;                            // controller speaker: enable, volume (0..100), audio path byte
    int xinputInput;          // 0 = XInput pad is rumble-only (game reads buttons via its own path), 1 = full input
    int stickDeadzone;
    int log;
    // gyro aiming (DualSense IMU -> right stick)
    int gyroMode;             // 0 off, 1 while aiming (L2 held), 2 always
    double gyroSensX, gyroSensY, gyroAntiDeadzone;
    int gyroInvertX, gyroInvertY, gyroAimThreshold;
    // recoil pulse when the game fires a bow / spell / ability
    int recoilEnabled;
    struct { int ms, freq, force, heavy, light; } rc[4];   // 1 bow, 2 spell, 3 ability
    // game vibration sounds -> motor pulses
    int vibEnabled, vibDecayMs, vibHeavy, vibLight; double vibStrength;
    int hapticsMode;          // 0 = classic rumble only, 1 = HD haptics (audio) with rumble fallback, 2 = both
    HapticsConfig hap;
} Config;
static Config C;
static wchar_t g_dir[MAX_PATH];
static FILE *g_log;

static long g_logBytes;
static void LOG(const char *fmt, ...) {
    if (!g_log || g_logBytes > 4 * 1024 * 1024) return;   // a session log stays small
    g_logBytes += 160;
    SYSTEMTIME t; GetLocalTime(&t);
    fprintf(g_log, "[%02d:%02d:%02d.%03d] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    va_list a; va_start(a, fmt); vfprintf(g_log, fmt, a); va_end(a);
    fputc('\n', g_log); fflush(g_log);
}

static const char *EFF_NAMES[16] = {
    "None", "BowCharging", "BowChargingComplete", "BowFire",
    "SpellCharging", "SpellChargingComplete", "SpellFire", "SpellChannelling",
    "SpecialAbility_Idle", "SpecialAbility_Charging", "SpecialAbility_Fire",
    "Fishing_Idle", "Fishing_Charging", "Fishing_Casting", "Fishing_FishHooked", "Fishing_ReelIn" };

// Which effect fires and when is decided 100% by the game. How each one feels was
// defined in the PS5 platform layer, which does not exist in the PC build, so these
// are tuned per effect name. Format: Trigger,Mode,P1,P2,P3
//   Trigger: R2 | L2 | Both     Mode: off | resist(start,force) | section(start,end,force)
//   | vibrate(freq,force,start)  (positions 0..255 of travel, force 0..255, freq Hz)
static const char *EFF_DEFAULTS[16] = {
    "Both,off,0,0,0",            // None
    "Auto,resist,20,110,0",        // BowCharging        - pulling the string
    "Auto,vibrate,22,70,40",       // BowChargingComplete - fully drawn, string trembles
    "Auto,off,0,0,0",              // BowFire            - release
    "Auto,resist,30,90,0",         // SpellCharging
    "Auto,vibrate,45,90,30",       // SpellChargingComplete
    "Auto,off,0,0,0",              // SpellFire
    "R2,vibrate,30,110,10",        // SpellChannelling - beam: R2 trembles while held
    "Auto,resist,60,60,0",         // SpecialAbility_Idle
    "Auto,resist,20,170,0",        // SpecialAbility_Charging
    "Auto,off,0,0,0",              // SpecialAbility_Fire
    "Auto,resist,40,60,0",         // Fishing_Idle
    "Auto,resist,15,150,0",        // Fishing_Charging   - winding up the cast
    "Auto,off,0,0,0",              // Fishing_Casting
    "Auto,vibrate,12,200,0",       // Fishing_FishHooked - fish tugging the line
    "Auto,vibrate,25,140,0",       // Fishing_ReelIn
};

static const char *DEFAULT_INI_HEAD =
"; EnshroudedSense 2.2 - Enshrouded's own DualSense features on PC\r\n"
"; Edit and restart the game. Delete this file to restore defaults.\r\n"
"[General]\r\n"
"Enabled=1\r\n"
"; 1 = also pass real Xbox controllers through as player 2+\r\n"
"RealPadsToo=0\r\n"
"; 1 = the game gets the DualSense through EnshroudedSense (needed for rumble, gyro). 0 = rumble-only\r\n"
"XInputInput=1\r\n"
"; hide the DualSense from the game's DirectInput so it is not read twice\r\n"
"HideDualSenseFromDirectInput=1\r\n"
"Log=1\r\n"
"\r\n[Rumble]\r\n"
"; percent of the game's own rumble (100 = exactly what the game sends)\r\n"
"Scale=100\r\n"
"\r\n[Triggers]\r\n"
"; effects come from the game's AdaptiveTriggerSystem\r\n"
"Enabled=1\r\n"
"; percent, scales every force below\r\n"
"Strength=100\r\n"
"; 1 = obey the game's own 'adaptive trigger strength' option (Off/Normal)\r\n"
"RespectGameSetting=0\r\n"
"\r\n[Effects]\r\n"
"; Trigger,Mode,P1,P2,P3   Trigger: Auto (the trigger you are holding) | R2 | L2 | Both\r\n"
";   off | resist,start,force | section,start,end,force | vibrate,freq,force,start\r\n";

static const char *DEFAULT_INI_TAIL =
"\r\n[Lightbar]\r\n"
"; 1 = game state: health colour (green -> yellow -> red, heartbeat when low), blue under water\r\n"
";     (fades with oxygen, flashes red when you run out), violet blinking while in the Shroud\r\n"
"; 2 = static colour R/G/B below, 0 = leave the controller default\r\n"
"Mode=1\r\n"
"; white LEDs under the touchpad show your player number in the session (like on PS5)\r\n"
"PlayerNumberLeds=1\r\n"
"LowHealthPercent=25\r\n"
"ShroudBlinkHz=1.2\r\n"
"Brightness=1.0\r\n"
"Enabled=0\r\n"
"R=255\r\nG=90\r\nB=10\r\n"
"PlayerLed=4\r\n"
"\r\n[Touchpad]\r\n"
"; the PS5 version's touch controls (the game's own 'Touch' settings, which PC has no menu for)\r\n"
"Enabled=1\r\n"
"; 1 = use the game's own touch settings (the PS5 defaults it ships with); 0 = use the values below\r\n"
"UseGameSettings=1\r\n"
"; map: drag with one finger moves it, pinch with two zooms. MapDragSpeed: how far it moves per finger movement (0 = off)\r\n"
"MapDragSpeed=1.0\r\n"
"; values used only with UseGameSettings=0. map: move with a finger\r\n"
"Map=1\r\n"
"; wheels: drag = pick a segment by swiping towards it, absolute = by finger position, none\r\n"
"QuickItemWheel=drag\r\nEmoteWheel=drag\r\n"
"; wheels open as soon as a finger touches the pad (the game's 'open on touch' option; used with either setting above)\r\n"
"QuickItemWheelOpenOnTouch=1\r\nEmoteWheelOpenOnTouch=0\r\n"
"; lists: horizontal | horizontal-inverted | vertical | vertical-inverted | absolute-horizontal | absolute-vertical | none\r\n"
"Actionbar=horizontal\r\nAmmunition=vertical\r\nSongs=vertical\r\nLoot=horizontal\r\n"
"BuildingShapes=horizontal\r\nBuildingPages=vertical\r\nBuildingMaterials=vertical\r\n"
"NpcSelection=horizontal\r\nNpcPages=horizontal\r\nNpcRoamingRange=vertical\r\nLogicObjects=vertical-inverted\r\n"
"\r\n[TouchpadMenus]\r\n"
"; touch gestures in menus, added to the game's own menu action bindings (UiActionId names, empty = nothing)\r\n"
"Enabled=1\r\n"
"; Tap=Confirm is NOT safe: a screen asks every button for Confirm, a tap must not reach them all\r\n"
"Tap=\r\n"
"SwipeRight=NextTab\r\nSwipeLeft=PreviousTab\r\nSwipeUp=\r\nSwipeDown=\r\n"
"; the map zooms by pinch on its own (the game's PS5 code); these only add zoom steps elsewhere\r\n"
"PinchOut=\r\nPinchIn=\r\n"
"RotateRight=\r\nRotateLeft=\r\n"
"DragRight=\r\nDragLeft=\r\nDragUp=\r\nDragDown=\r\n"
"; pad pixels (of 1920) per drag step, pinch ratio per zoom step, degrees per rotate step\r\n"
"DragStep=180\r\nPinchStep=1.15\r\nRotateStep=20\r\n"
"; log which menu actions the game asks for (troubleshooting only)\r\n"
"Diagnostics=0\r\n"
"\r\n[Buttons]\r\n"
"; touchpad click = the PS5 touchpad button: 0 = Back/View, 1 = Start/Menu, 2 = nothing\r\n"
"TouchpadAs=0\r\n"
"StickDeadzone=0\r\n"
"\r\n[Gyro]\r\n"
"; 0 = off, 1 = only while aiming (L2 held), 2 = always\r\n"
"Mode=1\r\n"
"SensitivityX=1.8\r\n"
"SensitivityY=1.8\r\n"
"InvertX=0\r\n"
"InvertY=0\r\n"
"; added minimum stick deflection so small wrist movements get past the game's stick deadzone\r\n"
"AntiDeadzone=0.18\r\n"
"AimTriggerThreshold=60\r\n"
"\r\n[Haptics]\r\n"
"; DualSense HD haptics over USB audio (channels 3/4 of the controller's sound device), like on PS5\r\n"
"; 0 = classic rumble motors only, 1 = HD haptics (rumble only as fallback), 2 = both\r\n"
"Mode=1\r\n"
"Gain=1.0\r\nLeft=1.0\r\nRight=1.0\r\n"
"; waveform per event: two tones (Hz) and decay time (s)\r\n"
"GameFreq1=70\r\nGameFreq2=160\r\nGameDecay=0.07\r\n"
"BowFreq1=230\r\nBowFreq2=340\r\nBowDecay=0.018\r\n"
"SpellFreq1=45\r\nSpellFreq2=95\r\nSpellDecay=0.09\r\n"
"AbilityFreq1=60\r\nAbilityFreq2=140\r\nAbilityDecay=0.07\r\n"
"; 1 = play the game's own vibration waveforms (what PS5 sends to the actuators: steps, surfaces, hits)\r\n"
"GameWaveforms=1\r\n"
"GameGain=1.5\r\n"
"; menu / main menu / tab / action bar clicks: the game's own UI sound is also played on the actuators\r\n"
"MenuClicks=1\r\nMenuClickGain=0.8\r\n"
"; plus a short crisp tick on every UI sound the game plays (strength 0 = off, tone Hz, decay s)\r\n"
"MenuTick=0.55\r\nMenuTickFreq1=170\r\nMenuTickFreq2=300\r\nMenuTickDecay=0.010\r\n"
"; water texture while swimming / under water (0 = off)\r\n"
"WaterTexture=0.6\r\n"
"; game sounds meant for the controller speaker (0 = off)\r\n"
"SpeakerVolume=1.0\r\n"
"\r\n[Block]\r\n"
"; raising the shield / ward, blocked hits (stronger the more stamina the hit drains), broken block\r\n"
"Effects=1\r\n"
"; shield or ward (different raise / impact feel)\r\n"
"Offhand=shield\r\n"
"Strength=1.0\r\n"
"; the game's own block impact sound is also played on the actuators\r\n"
"ImpactSounds=1\r\nImpactSoundGain=2.5\r\n"
"\r\n[Speaker]\r\n"
"; switch the DualSense's built-in speaker on (it is off unless the host enables it)\r\n"
"Enabled=1\r\n"
"; hardware volume 0..100\r\n"
"Volume=100\r\n"
"\r\n[Vibration]\r\n"
"; the game's own vibration sounds (PS5 haptics) played as motor pulses: timing and volume come from the game\r\n"
"Enabled=1\r\n"
"Strength=1.0\r\n"
"DecayMs=160\r\n"
"HeavyMotor=220\r\n"
"LightMotor=160\r\n"
"\r\n[Recoil]\r\n"
"; kick on R2 + motor pulse when the game fires. Each weapon type has its own feel.\r\n"
"; Ms = length, TriggerFreq/Force = R2 tremble, HeavyMotor/LightMotor = rumble (fades out)\r\n"
"Enabled=1\r\n"
"; bow: short sharp string snap\r\n"
"BowMs=70\r\nBowTriggerFreq=90\r\nBowTriggerForce=200\r\nBowHeavyMotor=40\r\nBowLightMotor=150\r\n"
"; staff / spell: longer low magical thrum\r\n"
"SpellMs=200\r\nSpellTriggerFreq=35\r\nSpellTriggerForce=150\r\nSpellHeavyMotor=170\r\nSpellLightMotor=60\r\n"
"; special ability\r\n"
"AbilityMs=150\r\nAbilityTriggerFreq=50\r\nAbilityTriggerForce=190\r\nAbilityHeavyMotor=200\r\nAbilityLightMotor=130\r\n";

static void ParseEff(const char *v, Eff *e) {
    char t[16] = {0}, m[16] = {0}; int a = 0, b = 0, c = 0;
    memset(e, 0, sizeof *e);
    sscanf(v, " %15[^,] , %15[^,] , %d , %d , %d", t, m, &a, &b, &c);
    e->trig = !_stricmp(t, "L2") ? 2 : !_stricmp(t, "Both") ? 3 : !_stricmp(t, "R2") ? 1 : 4; // 4 = Auto
    e->mode = !_stricmp(m, "resist") ? 1 : !_stricmp(m, "section") ? 2 : !_stricmp(m, "vibrate") ? 6 : 0;
    e->p1 = a; e->p2 = b; e->p3 = c;
}

static int ini(const wchar_t *s, const wchar_t *k, int d, const wchar_t *path) {
    return (int)GetPrivateProfileIntW(s, k, d, path);
}
static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
// "B", "Tab", "F5", "0x42" -> virtual key
static WORD ParseKey(const wchar_t *k) {
    while (*k == L' ') k++;
    if (!k[0]) return 0;
    if (!k[1]) { wchar_t c = towupper(k[0]); if ((c >= L'A' && c <= L'Z') || (c >= L'0' && c <= L'9')) return (WORD)c; }
    if (!_wcsicmp(k, L"Tab")) return VK_TAB;
    if (!_wcsicmp(k, L"Esc") || !_wcsicmp(k, L"Escape")) return VK_ESCAPE;
    if (!_wcsicmp(k, L"Space")) return VK_SPACE;
    if (!_wcsicmp(k, L"Enter")) return VK_RETURN;
    if ((k[0] == L'F' || k[0] == L'f') && k[1] >= L'1' && k[1] <= L'9') { int n = _wtoi(k + 1); if (n >= 1 && n <= 24) return (WORD)(VK_F1 + n - 1); }
    return (WORD)wcstol(k, NULL, 0);
}

static void UiTouchConfig(const wchar_t *path);
static void LoadConfig(void) {
    wchar_t path[MAX_PATH];
    swprintf(path, MAX_PATH, L"%ls\\EnshroudedSense.ini", g_dir);
    if (GetFileAttributesW(path) == INVALID_FILE_ATTRIBUTES) {
        FILE *f = _wfopen(path, L"wb");
        if (f) {
            fputs(DEFAULT_INI_HEAD, f);
            for (int i = 0; i < 16; i++) fprintf(f, "%s=%s\r\n", EFF_NAMES[i], EFF_DEFAULTS[i]);
            fputs(DEFAULT_INI_TAIL, f);
            fclose(f);
        }
    }
    C.enabled = ini(L"General", L"Enabled", 1, path);
    C.realPadsToo = ini(L"General", L"RealPadsToo", 0, path);
    C.log = ini(L"General", L"Log", 1, path);
    C.rumbleScale = clampi(ini(L"Rumble", L"Scale", 100, path), 0, 400);
    C.triggersEnabled = ini(L"Triggers", L"Enabled", 1, path);
    C.triggerStrength = clampi(ini(L"Triggers", L"Strength", 100, path), 0, 200);
    C.respectGameSetting = ini(L"Triggers", L"RespectGameSetting", 0, path);
    char pa[MAX_PATH * 2]; WideCharToMultiByte(CP_ACP, 0, path, -1, pa, sizeof pa, NULL, NULL);
    for (int i = 0; i < 16; i++) {
        char v[128];
        GetPrivateProfileStringA("Effects", EFF_NAMES[i], EFF_DEFAULTS[i], v, sizeof v, pa);
        ParseEff(v, &C.eff[i]);
    }
    C.lightbar = ini(L"Lightbar", L"Enabled", 0, path);
    C.lightR = clampi(ini(L"Lightbar", L"R", 255, path), 0, 255);
    C.lightG = clampi(ini(L"Lightbar", L"G", 90, path), 0, 255);
    C.lightB = clampi(ini(L"Lightbar", L"B", 10, path), 0, 255);
    C.playerLed = clampi(ini(L"Lightbar", L"PlayerLed", 4, path), 0, 31);
    C.xinputInput = ini(L"General", L"XInputInput", 1, path);
    {   wchar_t b[64];
        GetPrivateProfileStringW(L"Gyro", L"SensitivityX", L"1.8", b, 64, path); C.gyroSensX = _wtof(b);
        GetPrivateProfileStringW(L"Gyro", L"SensitivityY", L"1.8", b, 64, path); C.gyroSensY = _wtof(b);
        GetPrivateProfileStringW(L"Gyro", L"AntiDeadzone", L"0.18", b, 64, path); C.gyroAntiDeadzone = _wtof(b); }
    C.gyroMode = clampi(ini(L"Gyro", L"Mode", 1, path), 0, 2);
    C.gyroInvertX = ini(L"Gyro", L"InvertX", 0, path);
    C.gyroInvertY = ini(L"Gyro", L"InvertY", 0, path);
    C.gyroAimThreshold = clampi(ini(L"Gyro", L"AimTriggerThreshold", 60, path), 1, 255);
    C.vibEnabled = ini(L"Vibration", L"Enabled", 1, path);
    C.vibDecayMs = clampi(ini(L"Vibration", L"DecayMs", 160, path), 20, 2000);
    C.vibHeavy = clampi(ini(L"Vibration", L"HeavyMotor", 220, path), 0, 255);
    C.vibLight = clampi(ini(L"Vibration", L"LightMotor", 160, path), 0, 255);
    {   wchar_t b[64]; GetPrivateProfileStringW(L"Vibration", L"Strength", L"1.0", b, 64, path); C.vibStrength = _wtof(b); }
    C.hapticsMode = clampi(ini(L"Haptics", L"Mode", 1, path), 0, 2);
    {   struct { const wchar_t *k; double *dst; const wchar_t *def; } hk[] = {
            { L"Gain", &C.hap.gain, L"1.0" }, { L"Left", &C.hap.left, L"1.0" }, { L"Right", &C.hap.right, L"1.0" },
            { L"GameFreq1", &C.hap.gameF1, L"70" }, { L"GameFreq2", &C.hap.gameF2, L"160" }, { L"GameDecay", &C.hap.gameDecay, L"0.07" },
            { L"BowFreq1", &C.hap.bowF1, L"230" }, { L"BowFreq2", &C.hap.bowF2, L"340" }, { L"BowDecay", &C.hap.bowDecay, L"0.018" },
            { L"SpellFreq1", &C.hap.spellF1, L"45" }, { L"SpellFreq2", &C.hap.spellF2, L"95" }, { L"SpellDecay", &C.hap.spellDecay, L"0.09" },
            { L"AbilityFreq1", &C.hap.abilF1, L"60" }, { L"AbilityFreq2", &C.hap.abilF2, L"140" }, { L"AbilityDecay", &C.hap.abilDecay, L"0.07" },
            { L"GameGain", &C.hap.gameGain, L"1.5" }, { L"SpeakerVolume", &C.hap.speakerVol, L"1.0" },
            { L"MenuTick", &C.hap.tickAmp, L"0.55" }, { L"MenuTickFreq1", &C.hap.tickF1, L"170" },
            { L"MenuTickFreq2", &C.hap.tickF2, L"300" }, { L"MenuTickDecay", &C.hap.tickDecay, L"0.010" } };
        for (size_t k = 0; k < sizeof hk / sizeof hk[0]; k++) {
            wchar_t b[64]; GetPrivateProfileStringW(L"Haptics", hk[k].k, hk[k].def, b, 64, path); *hk[k].dst = _wtof(b); } }
    C.hap.gameHaptics = ini(L"Haptics", L"GameWaveforms", 1, path);
    C.recoilEnabled = ini(L"Recoil", L"Enabled", 1, path);
    {   static const wchar_t *nm[4] = { L"", L"Bow", L"Spell", L"Ability" };
        static const int def[4][5] = { {0}, { 70, 90, 200, 40, 150 }, { 200, 35, 150, 170, 60 }, { 150, 50, 190, 200, 130 } };
        for (int k = 1; k < 4; k++) {
            wchar_t key[32];
            swprintf(key, 32, L"%lsMs", nm[k]);           C.rc[k].ms = clampi(ini(L"Recoil", key, def[k][0], path), 20, 800);
            swprintf(key, 32, L"%lsTriggerFreq", nm[k]);  C.rc[k].freq = clampi(ini(L"Recoil", key, def[k][1], path), 1, 255);
            swprintf(key, 32, L"%lsTriggerForce", nm[k]); C.rc[k].force = clampi(ini(L"Recoil", key, def[k][2], path), 0, 255);
            swprintf(key, 32, L"%lsHeavyMotor", nm[k]);   C.rc[k].heavy = clampi(ini(L"Recoil", key, def[k][3], path), 0, 255);
            swprintf(key, 32, L"%lsLightMotor", nm[k]);   C.rc[k].light = clampi(ini(L"Recoil", key, def[k][4], path), 0, 255);
        } }
    C.touchpadAs = clampi(ini(L"Buttons", L"TouchpadAs", 0, path), 0, 2);
    {   // [Touchpad] = the game's InputSettingsTouchPad: enable, viewport2D, emoteWheel{gesture,openOnTouch},
        // quickItemWheel{..}, then {gesture, axis} for 11 lists. gesture 0 none / 1 drag / 2 absolute position,
        // axis 1 +X / 2 -X / 3 +Y (finger up) / 4 -Y (finger down)
        BYTE *t = C.touchCfg; memset(t, 0, sizeof C.touchCfg);
        C.touchOn = ini(L"Touchpad", L"Enabled", 1, path);
        C.touchOverride = !ini(L"Touchpad", L"UseGameSettings", 1, path);
        t[0] = (BYTE)(C.touchOn ? 1 : 0);
        t[1] = (BYTE)(ini(L"Touchpad", L"Map", 1, path) ? 1 : 0);
        static const struct { const wchar_t *key; int off; const wchar_t *def; int wheel; } L[] = {
            { L"EmoteWheel", 2, L"drag", 1 }, { L"QuickItemWheel", 4, L"drag", 1 },
            { L"Actionbar", 6, L"horizontal", 0 }, { L"Ammunition", 8, L"vertical", 0 }, { L"Songs", 10, L"vertical", 0 },
            { L"Loot", 12, L"horizontal", 0 }, { L"BuildingShapes", 14, L"horizontal", 0 }, { L"BuildingPages", 16, L"vertical", 0 },
            { L"BuildingMaterials", 18, L"vertical", 0 }, { L"NpcSelection", 20, L"horizontal", 0 }, { L"NpcPages", 22, L"horizontal", 0 },
            { L"NpcRoamingRange", 24, L"vertical", 0 }, { L"LogicObjects", 26, L"vertical-inverted", 0 } };
        for (unsigned i = 0; i < sizeof L / sizeof L[0]; i++) {
            wchar_t b[48]; GetPrivateProfileStringW(L"Touchpad", L[i].key, L[i].def, b, 48, path);
            BYTE g = 0, a = 0;
            if (!_wcsicmp(b, L"drag")) g = 1;
            else if (!_wcsicmp(b, L"absolute")) { g = 2; a = 1; }
            else if (!_wcsicmp(b, L"horizontal")) { g = 1; a = 1; }
            else if (!_wcsicmp(b, L"horizontal-inverted")) { g = 1; a = 2; }
            else if (!_wcsicmp(b, L"vertical")) { g = 1; a = 4; }
            else if (!_wcsicmp(b, L"vertical-inverted")) { g = 1; a = 3; }
            else if (!_wcsicmp(b, L"absolute-horizontal")) { g = 2; a = 1; }
            else if (!_wcsicmp(b, L"absolute-vertical")) { g = 2; a = 4; }
            t[L[i].off] = g;
            if (L[i].wheel) { wchar_t k2[64]; swprintf(k2, 64, L"%lsOpenOnTouch", L[i].key);
                              int o = ini(L"Touchpad", k2, L[i].off == 4 ? 1 : 0, path) ? 1 : 0;   // quick item wheel: on by default
                              t[L[i].off + 1] = (BYTE)o; if (L[i].off == 4) C.qwOpen = o; else C.ewOpen = o; }
            else t[L[i].off + 1] = a;
        }
    }
    UiTouchConfig(path);
    C.lbMode = clampi(ini(L"Lightbar", L"Mode", C.lightbar ? 2 : 1, path), 0, 3);
    C.lbPlayerLeds = ini(L"Lightbar", L"PlayerNumberLeds", 1, path);
    C.blockFx = ini(L"Block", L"Effects", 1, path);
    {   wchar_t b[64]; GetPrivateProfileStringW(L"Block", L"Offhand", L"shield", b, 64, path);
        C.blockWard = !_wcsicmp(b, L"ward") || !_wcsicmp(b, L"оберег");
        GetPrivateProfileStringW(L"Block", L"Strength", L"1.0", b, 64, path); C.blockStrength = _wtof(b);
        if (!(C.blockStrength >= 0) || C.blockStrength > 3) C.blockStrength = 1.0; }
    C.lbLowHealth = clampi(ini(L"Lightbar", L"LowHealthPercent", 25, path), 0, 100);
    {   wchar_t b[64];
        GetPrivateProfileStringW(L"Lightbar", L"ShroudBlinkHz", L"1.2", b, 64, path); C.lbShroudHz = _wtof(b);
        if (C.lbShroudHz < 0.1 || C.lbShroudHz > 10) C.lbShroudHz = 1.2;
        GetPrivateProfileStringW(L"Lightbar", L"Brightness", L"1.0", b, 64, path); C.lbBright = _wtof(b);
        if (!(C.lbBright > 0) || C.lbBright > 1) C.lbBright = 1.0;
        GetPrivateProfileStringW(L"Haptics", L"WaterTexture", L"0.6", b, 64, path); C.hap.waterGain = _wtof(b); }
    C.spkHw = ini(L"Speaker", L"Enabled", 1, path);
    C.spkHwVol = clampi(ini(L"Speaker", L"Volume", 100, path), 0, 100);
    C.spkPath = clampi(ini(L"Speaker", L"AudioControl", 0x20, path), 0, 255);
    C.stickDeadzone = clampi(ini(L"Buttons", L"StickDeadzone", 0, path), 0, 32767);
}

// ---------------------------------------------------------------- game hook
// caller:  movss xmm3,[rdi+X]; movzx edx,bl; movzx r8d,byte[rdi+Y]; mov rcx,[rbp+Z]; call setEffect
static volatile BYTE g_rawL2, g_rawR2;
static volatile DWORD g_recoilUntil, g_recoilStart, g_motorTestUntil; static volatile LONG g_recoilKind;
typedef struct { DWORD t0; float vol; } VibEv;
static VibEv g_vib[16]; static volatile LONG g_vibHead;
static volatile LONG g_gyroFrames; static volatile LONG g_gyroMaxMilli;
static volatile LONG g_gameEffect;      // AdaptiveTriggerEffect from the game
static volatile LONG g_gameStrength = 1;
static volatile DWORD g_effectTick;
static BYTE *g_retAddr;
static int g_hooked;

static void __fastcall OnSetTriggerEffect(void *sys, unsigned effect, unsigned strength, float param) {
    (void)sys;
    if ((BYTE*)__builtin_return_address(0) != g_retAddr) return;   // only the trigger system's call
    effect &= 0xFF; strength &= 0xFF;
    static LONG lastE = -1, lastS = -1;
    if ((LONG)effect != lastE || (LONG)strength != lastS) {
        LOG("game effect: %s (%u)  strength=%u  param=%.3f  L2=%d R2=%d",
            effect < 16 ? EFF_NAMES[effect] : "?", effect, strength, param, g_rawL2, g_rawR2);
        lastE = effect; lastS = strength;
    }
    {   static unsigned prevE = 0;
        int isFire = effect == 3 || effect == 6 || effect == 10;
        int wasFire = prevE == 3 || prevE == 6 || prevE == 10;
        if (isFire && !wasFire) {
            int kind = effect == 3 ? 1 : effect == 6 ? 2 : 3;       // bow / spell / special ability
            g_recoilKind = kind; g_recoilStart = GetTickCount();
            g_recoilUntil = g_recoilStart + (DWORD)C.rc[kind].ms;
            if (C.recoilEnabled && C.hapticsMode) Haptics_Push(kind, 1.0f);
        }
        prevE = effect; }
    InterlockedExchange(&g_gameEffect, effect < 16 ? (LONG)effect : 0);
    InterlockedExchange(&g_gameStrength, (LONG)strength);
    g_effectTick = GetTickCount();
}

static void InstallHook(void) {
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL);
    IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS*)(mod + ((IMAGE_DOS_HEADER*)mod)->e_lfanew);
    IMAGE_SECTION_HEADER *sh = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++, sh++) {
        if (memcmp(sh->Name, ".text", 5)) continue;
        BYTE *p = mod + sh->VirtualAddress, *end = p + sh->Misc.VirtualSize - 32;
        for (; p < end; p++) {
            if (p[0] != 0xF3 || p[1] != 0x0F || p[2] != 0x10 || p[3] != 0x9F) continue;
            if (p[8] != 0x0F || p[9] != 0xB6 || p[10] != 0xD3) continue;
            if (p[11] != 0x44 || p[12] != 0x0F || p[13] != 0xB6 || p[14] != 0x87) continue;
            if (p[19] != 0x48 || p[20] != 0x8B || p[21] != 0x4D || p[23] != 0xE8) continue;
            BYTE *call = p + 23;
            BYTE *target = call + 5 + *(int32_t*)(call + 1);
            // the PC build's stub is "ret 0" followed by padding
            if (!(target[0] == 0xC2 && target[1] == 0 && target[2] == 0) && target[0] != 0xC3) {
                LOG("trigger stub at %p is not empty (%02X %02X %02X) - not hooking", target, target[0], target[1], target[2]);
                return;
            }
            int room = 0; for (int k = (target[0] == 0xC3 ? 1 : 3); k < 32 && target[k] == 0xCC; k++) room++;
            BYTE patch[14] = {0xFF, 0x25, 0, 0, 0, 0};
            void *dst = (void*)OnSetTriggerEffect; memcpy(patch + 6, &dst, 8);
            DWORD old;
            if (room + (target[0] == 0xC3 ? 1 : 3) >= 14) {
                VirtualProtect(target, 14, PAGE_EXECUTE_READWRITE, &old);
                memcpy(target, patch, 14);
                VirtualProtect(target, 14, old, &old);
            } else {
                // not enough padding: redirect the call itself through a small trampoline
                BYTE *tr = (BYTE*)VirtualAlloc(NULL, 64, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
                for (uintptr_t d = 0x10000; !tr && d < 0x70000000; d += 0x10000) {
                    tr = (BYTE*)VirtualAlloc((BYTE*)((uintptr_t)call & ~0xFFFFull) - d, 64, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
                }
                if (!tr) { LOG("no room for trigger hook"); return; }
                memcpy(tr, patch, 14);
                int64_t rel = tr - (call + 5);
                if (rel > INT32_MAX || rel < INT32_MIN) { LOG("trampoline too far"); return; }
                int32_t r32 = (int32_t)rel;
                VirtualProtect(call, 5, PAGE_EXECUTE_READWRITE, &old);
                memcpy(call + 1, &r32, 4);
                VirtualProtect(call, 5, old, &old);
            }
            FlushInstructionCache(GetCurrentProcess(), target, 14);
            g_retAddr = call + 5;
            g_hooked = 1;
            LOG("hooked game AdaptiveTriggerSystem: call at +0x%llX, stub at +0x%llX",
                (unsigned long long)(call - mod), (unsigned long long)(target - mod));
            return;
        }
    }
    LOG("AdaptiveTriggerSystem call not found (game update?) - adaptive triggers disabled, rumble still works");
}

// ---------------------------------------------------------------- DualSense
#define DS_VID 0x054C
static const USHORT DS_PIDS[] = { 0x0CE6 /* DualSense */, 0x0DF2 /* DualSense Edge */ };

typedef struct {
    HANDLE h;
    int bt;                 // 1 = bluetooth
    int inLen, outLen;
    volatile LONG connected;
    CRITICAL_SECTION cs;
    // latest input
    XGAMEPAD pad;
    BYTE rawL2, rawR2;
    DWORD packet;
    // requested output
    WORD motorL, motorR;    // from game (0..65535)
    DWORD lastRumbleTick;
    BYTE seq;
    BYTE lastOut[80];
    DWORD lastWrite;
    int hold;               // frames bow held drawn
    BYTE ledInit;           // lightbar setup sent
    int vibV2;              // firmware uses "vibration v2" rumble emulation
    int motorsWereOn;
} DS;
static DS D;
static HANDLE g_thread;
static volatile LONG g_started, g_quit;

static uint32_t crc32_tab[256];
static void crc_init(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        crc32_tab[i] = c;
    }
}
static uint32_t crc32_upd(uint32_t c, const BYTE *p, size_t n) {
    while (n--) c = crc32_tab[(c ^ *p++) & 0xFF] ^ (c >> 8);
    return c;
}

static HANDLE OpenDualSense(int *bt, int *inLen, int *outLen) {
    GUID g; HidD_GetHidGuid(&g);
    HDEVINFO di = SetupDiGetClassDevsW(&g, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if (di == INVALID_HANDLE_VALUE) return INVALID_HANDLE_VALUE;
    HANDLE found = INVALID_HANDLE_VALUE;
    SP_DEVICE_INTERFACE_DATA ifd; ifd.cbSize = sizeof(ifd);
    for (DWORD i = 0; SetupDiEnumDeviceInterfaces(di, NULL, &g, i, &ifd); i++) {
        DWORD need = 0;
        SetupDiGetDeviceInterfaceDetailW(di, &ifd, NULL, 0, &need, NULL);
        if (!need) continue;
        SP_DEVICE_INTERFACE_DETAIL_DATA_W *det = (SP_DEVICE_INTERFACE_DETAIL_DATA_W*)malloc(need);
        det->cbSize = sizeof(*det);
        if (SetupDiGetDeviceInterfaceDetailW(di, &ifd, det, need, NULL, NULL)) {
            HANDLE h = CreateFileW(det->DevicePath, GENERIC_READ | GENERIC_WRITE,
                                   FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING,
                                   FILE_FLAG_OVERLAPPED, NULL);
            if (h != INVALID_HANDLE_VALUE) {
                HIDD_ATTRIBUTES at; at.Size = sizeof(at);
                int ok = 0;
                if (HidD_GetAttributes(h, &at) && at.VendorID == DS_VID) {
                    for (size_t p = 0; p < sizeof(DS_PIDS) / sizeof(DS_PIDS[0]); p++)
                        if (at.ProductID == DS_PIDS[p]) ok = 1;
                }
                if (ok) {
                    PHIDP_PREPARSED_DATA pp; HIDP_CAPS caps;
                    if (HidD_GetPreparsedData(h, &pp)) {
                        HidP_GetCaps(pp, &caps);
                        HidD_FreePreparsedData(pp);
                        *inLen = caps.InputReportByteLength;
                        *outLen = caps.OutputReportByteLength;
                        *bt = caps.InputReportByteLength != 64;  // USB = 64, BT = 78
                        LOG("DualSense found pid=%04X %s in=%d out=%d", at.ProductID,
                            *bt ? "Bluetooth" : "USB", *inLen, *outLen);
                        found = h;
                    } else ok = 0;
                }
                if (!ok) CloseHandle(h);
            }
        }
        free(det);
        if (found != INVALID_HANDLE_VALUE) break;
    }
    SetupDiDestroyDeviceInfoList(di);
    return found;
}

static SHORT axis(BYTE v, int invert) {
    int x = ((int)v - 128) * 258;   // -33024..32766
    if (invert) x = -x - 1;
    if (x > 32767) x = 32767;
    if (x < -32768) x = -32768;
    return (SHORT)x;
}
static void deadzone(SHORT *x, SHORT *y) {
    if (!C.stickDeadzone) return;
    double fx = *x, fy = *y, m = sqrt(fx * fx + fy * fy);
    if (m < C.stickDeadzone) { *x = *y = 0; return; }
    double s = (m - C.stickDeadzone) / (32767.0 - C.stickDeadzone) / m * 32767.0;
    fx *= s; fy *= s;
    if (fx > 32767) fx = 32767; if (fx < -32768) fx = -32768;
    if (fy > 32767) fy = 32767; if (fy < -32768) fy = -32768;
    *x = (SHORT)fx; *y = (SHORT)fy;
}

// ---------------------------------------------------------------- touchpad -> the game's own touch input
// The DualSense touch point is handed to the game exactly like the PS5 platform layer did: as a drag gesture
// input event (type 0x2A: phase, delta, position in 1920x1080 pad space) pushed into the engine's input queue
// once per frame. The game's input runtime turns it into its touch state, the client input turns that into
// action bar / ammo / song / loot / building / NPC / logic selection and the wheels, using InputSettingsTouchPad.
static CRITICAL_SECTION g_touchCs; static int g_touchCsInit;
typedef struct { int active, x, y; } TouchPt;
static struct { TouchPt p[2]; float dx, dy; int clicked; } g_touch;   // dx/dy: finger 0 movement since the last game frame
static float g_mapDX, g_mapDY; static DWORD g_mapT;   // one-finger movement not yet used by the map (pad pixels)
static volatile DWORD g_mapUsedT;                      // last time the map moved by finger (a drag there is not a tab swipe)
static void TouchCapture(const BYTE *p, int click) {
    if (!g_touchCsInit) return;
    TouchPt n[2];
    for (int k = 0; k < 2; k++) {
        const BYTE *q = p + 32 + 4 * k;
        n[k].active = !(q[0] & 0x80); n[k].x = q[1] | ((q[2] & 0x0F) << 8); n[k].y = (q[2] >> 4) | (q[3] << 4);
    }
    EnterCriticalSection(&g_touchCs);
    if (n[0].active && g_touch.p[0].active) { g_touch.dx += (float)(n[0].x - g_touch.p[0].x); g_touch.dy += (float)(n[0].y - g_touch.p[0].y); }
    for (int k = 0; k < 2; k++) { if (n[k].active) g_touch.p[k] = n[k]; else g_touch.p[k].active = 0; }
    if (click) g_touch.clicked = 1;            // the pad was pressed down during this contact: a click, not a tap / swipe
    LeaveCriticalSection(&g_touchCs);
}
// ---- touch in menus: the game's UI actions evaluate their bindings in one place (UI binding evaluator). The PC
// build has the TouchPad control operation type there but it was compiled to "never matches". EnshroudedSense
// gives it a body (the touchpad op is evaluated against the gestures of this frame) and adds a touchpad op to
// the bindings of the UI actions chosen in [TouchpadMenus]. Each gesture is "pressed" for exactly one game frame.
enum { UIG_TAP, UIG_FLICK_R, UIG_FLICK_L, UIG_FLICK_U, UIG_FLICK_D, UIG_PINCH_OUT, UIG_PINCH_IN, UIG_ROT_R, UIG_ROT_L,
       UIG_DRAG_R, UIG_DRAG_L, UIG_DRAG_U, UIG_DRAG_D, UIG_COUNT };
static volatile LONG g_uiPend[UIG_COUNT];       // finished gestures not yet used by a menu (each = one press, max 3)
static volatile DWORD g_uiPendT[UIG_COUNT];     // when the last one was added (unused ones are dropped after 300 ms)
static volatile LONG g_uiHeld;                  // gestures in progress (for actions the game evaluates as "held")
static int UiAnyPending(void) { for (int k = 0; k < UIG_COUNT; k++) if (g_uiPend[k] > 0) return 1; return 0; }
static BYTE g_uiMap[96][2];                     // runtime UiActionId -> { GestureType, AxisDirection } (0 = none)
static volatile LONG cUiQuery, cUiTouchEval, cUiTouchHit;
static int UiGestureBit(BYTE g, BYTE a) {       // GestureType 1 Tap 2 Drag 3 Flick 4 Pinch 5 Rotate; axis 1 +X 2 -X 3 +Y(up) 4 -Y(down)
    switch (g) {
    case 1: return UIG_TAP;
    case 2: return a == 1 ? UIG_DRAG_R : a == 2 ? UIG_DRAG_L : a == 3 ? UIG_DRAG_U : a == 4 ? UIG_DRAG_D : -1;
    case 3: return a == 1 ? UIG_FLICK_R : a == 2 ? UIG_FLICK_L : a == 3 ? UIG_FLICK_U : a == 4 ? UIG_FLICK_D : -1;
    case 4: return a == 1 ? UIG_PINCH_OUT : a == 2 ? UIG_PINCH_IN : -1;
    case 5: return a == 1 ? UIG_ROT_R : a == 2 ? UIG_ROT_L : -1;
    }
    return -1;
}
// body of the evaluator's TouchPad case: op = ControlOperation (type 5, gesture +0xA, axis +0xB), mode = the
// action's InputModality (0 Press, 1 Tap, 2 Hold, 3 Release)
static BYTE TouchOpEval(const BYTE *op, BYTE mode) {
    int bit = UiGestureBit(op[0xa], op[0xb]);
    InterlockedIncrement(&cUiTouchEval);
    if (bit < 0 || mode == 3) return 0;
    if (mode == 2) { if (!((g_uiHeld >> bit) & 1) && g_uiPend[bit] <= 0) return 0; }
    else {   // one gesture = one press for ONE widget: the first one that takes it uses it up (the game asks every
             // widget of a screen every frame; without this one tap pressed all of them at once)
        for (;;) { LONG v = g_uiPend[bit]; if (v <= 0) return 0;
                   if (InterlockedCompareExchange(&g_uiPend[bit], v - 1, v) == v) break; }
    }
    InterlockedIncrement(&cUiTouchHit);
    return 1;
}
static const char *const kUiAction[91] = {
    "Confirm","Back","SecondaryAction","TertiaryAction","DeleteSaveData","NavigationDirections","Left","Right","Up","Down",
    "NextTab","PreviousTab","NextSubTab","PreviousSubTab","PageContentScrollBackward","PageContentScrollForward",
    "PageContentScrollTargetPrev","PageContentScrollTargetNext","ZoomIn","ZoomOut","ShowTutorial","ApplyChanges",
    "JumpToBindingIssue","ReloadData","BindingReset","BindingClear","ServerActionsMenu","CraftMultiple","ToggleMaterialSelection",
    "ToggleGridSize","SortBackpack","ItemActionsMenu","ItemDeleteInBackpack","SplitStackAdjustMin","SplitStackAdjustHalf",
    "SplitStackAdjustMax","GrabItemEntireStack","GrabItemPartialStackBegin","GrabItemPartialStackEnd","DropItemStackIntoSlot",
    "ItemQuickMoveBegin","ItemQuickMoveEnd","ItemQuickMoveOtherInventory","ItemQuickMoveActionbarBackpack","BackpackEquipmentView",
    "ItemViewerVisibilityToggle","ToggleLinkNavigation","ToggleContentViewerPage","ContentViewerPageNext","ContentViewerPagePrevious",
    "SortStorage","StorageDepositStacks","StorageDepositAll","StorageRefillStacks","StorageTakeAll","StorageToggleAreaDeposit",
    "MapMarkerLocatorSidebar","MapFilterSidebar","MapSnapToPlayer","TogglePersonalProgressionMode","JournalGoToReferencedJournalPage",
    "CreateOrSelectLogicNodesBegin","CreateOrSelectLogicNodesEnd","LogicNodesDuplicate","VoiceoverPause","VoiceoverToggleNavigation",
    "SalvageItem","ItemUseFromBackpack","EquipFromBackpack","EquipFromBackpackSecondary","EquipVanityFromBackpack","UnequipFromBackpack",
    "SplitStack","Gift","CreateCustomMarker","RemoveCustomMarker","FastTravel","GoToJournalEntry","MouseHintWaypointToggle",
    "ContextMenuWaypointToggle","Ping","TransferWater","KickPlayer","IgnorePlayer","MutePlayerVoice","EditVoiceVolume",
    "MutePlayerText","OpenServerFilter","OpenSearchIPv4","IgnoreServer","PregameHostSettingAdjust" };
static const char *UiName(unsigned a) { return a < 91 ? kUiAction[a] : "?"; }
static void UiTouchConfig(const wchar_t *path) {
    memset(g_uiMap, 0, sizeof g_uiMap);
    C.uiTouch = ini(L"TouchpadMenus", L"Enabled", 1, path);
    C.uiDiag = ini(L"TouchpadMenus", L"Diagnostics", 0, path);
    C.uiDragStep = clampi(ini(L"TouchpadMenus", L"DragStep", 180, path), 40, 1500);
    {   wchar_t m[32]; GetPrivateProfileStringW(L"Touchpad", L"MapDragSpeed", L"1.0", m, 32, path); C.mapDrag = _wtof(m);
        if (!(C.mapDrag >= 0 && C.mapDrag <= 10)) C.mapDrag = 1.0; }
    wchar_t b[64];
    GetPrivateProfileStringW(L"TouchpadMenus", L"PinchStep", L"1.15", b, 64, path); C.uiPinchStep = _wtof(b);
    if (!(C.uiPinchStep >= 1.03 && C.uiPinchStep <= 3.0)) C.uiPinchStep = 1.15;
    GetPrivateProfileStringW(L"TouchpadMenus", L"RotateStep", L"20", b, 64, path);
    double rs = _wtof(b); if (!(rs >= 5 && rs <= 120)) rs = 20; C.uiRotStep = rs * 3.14159265 / 180.0;
    static const struct { const wchar_t *key, *def; BYTE g, a; } G[] = {
        { L"Tap", L"", 1, 0 },
        { L"SwipeRight", L"NextTab", 3, 1 }, { L"SwipeLeft", L"PreviousTab", 3, 2 }, { L"SwipeUp", L"", 3, 3 }, { L"SwipeDown", L"", 3, 4 },
        { L"PinchOut", L"", 4, 1 }, { L"PinchIn", L"", 4, 2 },
        { L"RotateRight", L"", 5, 1 }, { L"RotateLeft", L"", 5, 2 },
        { L"DragRight", L"", 2, 1 }, { L"DragLeft", L"", 2, 2 }, { L"DragUp", L"", 2, 3 }, { L"DragDown", L"", 2, 4 } };
    for (unsigned i = 0; i < sizeof G / sizeof G[0]; i++) {
        GetPrivateProfileStringW(L"TouchpadMenus", G[i].key, G[i].def, b, 64, path);
        if (!b[0]) continue;
        int id = -1;
        if (b[0] >= L'0' && b[0] <= L'9') id = _wtoi(b);
        else for (int k = 0; k < 91; k++) { wchar_t w[64]; swprintf(w, 64, L"%hs", kUiAction[k]); if (!_wcsicmp(w, b)) { id = k; break; } }
        if (id < 0 || id >= 91) { LOG("[TouchpadMenus] %ls=%ls: unknown menu action", G[i].key, b); continue; }
        g_uiMap[id][0] = G[i].g; g_uiMap[id][1] = G[i].a;
    }
}
// the UI action query (one per widget and action, every frame): the original evaluation first; if it did not
// fire and the action has a touch gesture, the same evaluator runs on a touchpad combo (so focus / hover / layer
// checks the game does for the gamepad binding apply to touch too)
typedef uint64_t (*PFN_UiEval)(void *ctx, BYTE *binding, uint64_t flags, uint64_t id);
static PFN_UiEval o_uiAction, g_uiCombo; static int g_uiCaseOk;
static volatile LONG g_uiQ[96]; static BYTE g_uiQMode[96], g_uiQOp[96][6]; static uint32_t g_uiCaller[96][4]; static volatile LONG g_uiDiagNew;
static void UiDiag(BYTE a, const BYTE *b) {
    if (a >= 96) return;
    LONG n = InterlockedIncrement(&g_uiQ[a]);
    if (n == 1) { g_uiQMode[a] = b[0xc2]; memcpy(g_uiQOp[a], b + 0x62, 6); g_uiQOp[a][4] = b[0x62 + 8]; g_uiQOp[a][5] = b[0x62 + 0xb];
                  *(WORD*)&g_uiQOp[a][2] = *(const WORD*)(b + 0x62 + 6); g_uiQOp[a][1] = b[0x62 + 9]; InterlockedIncrement(&g_uiDiagNew); }
    if (n > 24 && (n & 1023)) return;
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL); void *fr[6] = { 0 };
    USHORT k = RtlCaptureStackBackTrace(0, 6, fr, NULL);
    for (USHORT j = 0; j + 1 < k; j++) {
        BYTE *f = (BYTE*)fr[j];
        if (f >= mod + 0xda6830 && f < mod + 0xda6cbb) {     // the frame inside the query function: the next one is who asked
            uint32_t c = (uint32_t)((BYTE*)fr[j + 1] - mod);
            for (int s = 0; s < 4; s++) { if (g_uiCaller[a][s] == c) break; if (!g_uiCaller[a][s]) { g_uiCaller[a][s] = c; InterlockedIncrement(&g_uiDiagNew); break; } }
            break;
        }
    }
}
static void UiDiagLog(void) {
    static LONG last;
    if (!C.uiDiag || g_uiDiagNew == last) return;
    last = g_uiDiagNew;
    char line[600]; int n = 0;
    for (int a = 0; a < 96; a++) {
        if (!g_uiQ[a]) continue;
        n = snprintf(line, sizeof line, "menu action asked: %d %s n=%ld mode=%u pad op type=%u btn=%u axis=%u stick=%u dir=%u by",
                     a, UiName(a), g_uiQ[a], g_uiQMode[a], g_uiQOp[a][0], *(WORD*)&g_uiQOp[a][2], g_uiQOp[a][4], g_uiQOp[a][1], g_uiQOp[a][5]);
        for (int s = 0; s < 4 && g_uiCaller[a][s] && n < (int)sizeof line - 12; s++) n += snprintf(line + n, sizeof line - n, " +%X", g_uiCaller[a][s]);
        LOG("%s", line);
    }
    LOG("menu touch: queries=%ld touch-evals=%ld hits=%ld", cUiQuery, cUiTouchEval, cUiTouchHit);
}
static uint64_t H_uiAction(void *ctx, BYTE *binding, uint64_t flags, uint64_t id) {
    uint64_t r = o_uiAction(ctx, binding, flags, id);
    BYTE a = (BYTE)id; WORD fl = (WORD)flags;
    InterlockedIncrement(&cUiQuery);
    if (C.uiDiag) UiDiag(a, binding);
    if ((BYTE)r || !g_uiCaseOk || !C.uiTouch || !C.touchOn || (fl & 1) || a >= 96 || !g_uiMap[a][0]) return r;
    if (!g_uiHeld && !UiAnyPending()) return r;              // no gesture waiting
    BYTE combo[0x30]; memset(combo, 0, sizeof combo);
    combo[0] = 5; combo[0xa] = g_uiMap[a][0]; combo[0xb] = g_uiMap[a][1];   // ControlOperation{ TouchPad, gesture, axis }
    BYTE r2 = (BYTE)g_uiCombo(ctx, combo, binding[0xc2], fl);
    if (r2) { static int nl; if (++nl <= 300) LOG("touchpad: menu action %s by touch (%s)", UiName(a), g_uiMap[a][0] == 1 ? "tap" : g_uiMap[a][0] == 3 ? "swipe" : g_uiMap[a][0] == 4 ? "pinch" : g_uiMap[a][0] == 5 ? "rotate" : "drag"); }
    return (r & ~0xFFull) | r2;
}
// the map's own input update (map object in rcx): a one-finger drag moves the map with the finger, through the
// map's own "move by a pointer offset" function (+0x18C/+0x190 = offset in UI pixels, divided by the zoom)
typedef uint64_t (*PFN_MapIn)(void *map);
static PFN_MapIn o_mapInput; static void (*g_mapApplyOffset)(void *map);
static volatile LONG cMapDrag;
static uint64_t H_mapInput(void *map) {
    if (map && C.touchOn && C.mapDrag > 0 && (C.touchOverride ? C.touchCfg[1] : 1)) {
        float dx, dy; DWORD t;
        EnterCriticalSection(&g_touchCs); dx = g_mapDX; dy = g_mapDY; t = g_mapT; g_mapDX = g_mapDY = 0; LeaveCriticalSection(&g_touchCs);
        float z = *(float*)((BYTE*)map + 0x10);
        if ((dx != 0 || dy != 0) && GetTickCount() - t < 250 && z > 0) {
            *(float*)((BYTE*)map + 0x18c) += (float)(dx * C.mapDrag);
            *(float*)((BYTE*)map + 0x190) += (float)(dy * C.mapDrag);
            g_mapApplyOffset(map); g_mapUsedT = GetTickCount();
            if (InterlockedIncrement(&cMapDrag) <= 20) LOG("touchpad: map moved by finger %.0f,%.0f (zoom %.3f)", dx, dy, z);
        }
    }
    return o_mapInput(map);
}
// gives the evaluator's TouchPad case (jump table entry 5, compiled to "no match") a body: TouchOpEval(op, mode)
static BYTE *NearAlloc(BYTE *near_);
static BYTE *g_tramp; static int g_trampUsed;
static int InstallUiTouchCase(BYTE *mod) {
    static const BYTE disp[] = { 0x0F,0xB6,0x06, 0xFF,0xC8, 0x83,0xF8,0x07, 0x0F,0x87 };              // movzx eax,[rsi]; dec eax; cmp eax,7; ja
    static const BYTE tab[] = { 0x48,0x8D,0x15,0x6D,0x9E,0x25,0xFF, 0x48,0x98, 0x8B,0x8C,0x82,0xB4,0x63,0xDA,0x00 };  // lea rdx,[image]; cdqe; mov ecx,[rdx+rax*4+table]
    static const BYTE combo[] = { 0x48,0x89,0x5C,0x24,0x08,0x48,0x89,0x74,0x24,0x18,0x48,0x89,0x7C,0x24,0x20,0x55 };
    uint32_t *jt = (uint32_t*)(mod + 0xda63b4 + 4 * 4);       // entry for type 5 (TouchPad)
    if (memcmp(mod + 0xda617e, disp, sizeof disp) || memcmp(mod + 0xda618c, tab, sizeof tab) || memcmp(mod + 0xda6060, combo, sizeof combo)
        || *jt != 0xda6390) { LOG("touchpad: menu binding evaluator not found (other game build) - touch in menus off"); return 0; }
    if (!g_tramp) g_tramp = NearAlloc(mod);
    if (!g_tramp || g_trampUsed + 48 > 4096) return 0;
    BYTE *s = g_tramp + g_trampUsed; g_trampUsed += 48;
    uint64_t rva = (uint64_t)(s - mod);
    if (s < mod || rva > 0xFFFFFFF0ull) { LOG("touchpad: no evaluator stub memory"); return 0; }
    void *fn = (void*)TouchOpEval; BYTE *back = mod + 0xda6392;        // the evaluator's common exit (result in al)
    int k = 0;
    s[k++] = 0x48; s[k++] = 0x89; s[k++] = 0xF1;                         // mov rcx, rsi        (the ControlOperation)
    s[k++] = 0x41; s[k++] = 0x0F; s[k++] = 0xB6; s[k++] = 0xD7;          // movzx edx, r15b     (the action's modality)
    s[k++] = 0x48; s[k++] = 0x83; s[k++] = 0xEC; s[k++] = 0x20;          // sub rsp, 0x20       (rsp is 16-aligned here)
    s[k++] = 0x48; s[k++] = 0xB8; memcpy(s + k, &fn, 8); k += 8;        // mov rax, TouchOpEval
    s[k++] = 0xFF; s[k++] = 0xD0;                                        // call rax
    s[k++] = 0x48; s[k++] = 0x83; s[k++] = 0xC4; s[k++] = 0x20;          // add rsp, 0x20
    s[k++] = 0xFF; s[k++] = 0x25; s[k++] = 0; s[k++] = 0; s[k++] = 0; s[k++] = 0; memcpy(s + k, &back, 8); k += 8;   // jmp exit
    FlushInstructionCache(GetCurrentProcess(), s, k);
    DWORD old; uint32_t v = (uint32_t)rva;
    if (!VirtualProtect(jt, 4, PAGE_EXECUTE_READWRITE, &old)) return 0;
    InterlockedExchange((volatile LONG*)jt, (LONG)v);
    VirtualProtect(jt, 4, old, &old);
    FlushInstructionCache(GetCurrentProcess(), jt, 4);
    g_uiCombo = (PFN_UiEval)(mod + 0xda6060);
    g_uiCaseOk = 1;
    LOG("touchpad: menu bindings accept touch (evaluator case at +%llX)", (unsigned long long)rva);
    return 1;
}
static volatile LONG cTouchEv;
typedef uint64_t (*PFN_PushEvent)(void *inputSystem, void *ev);
static PFN_PushEvent g_push; static uint32_t *g_stamp;
// DualSense touch gesture events as the input runtime / input bindings read them:
//   0x28 tap   (+0x20 float2)            0x2A drag  (+0x18 phase, +0x1C delta, +0x28 position)
//   0x2C pinch (+0x20 scale)             0x2D rotate (+0x20 angle)      0x2E flick (+0x28 end, +0x30 start)
static void PushGesture(BYTE *dev, BYTE type, BYTE phase, float a, float b, float c, float d, float e, float f) {
    BYTE ev[0x68]; memset(ev, 0, sizeof ev);
    *(uint32_t*)(ev + 0x00) = *(uint32_t*)(dev + 8);      // device
    *(uint32_t*)(ev + 0x04) = *g_stamp;
    ev[0x0c] = type; ev[0x18] = phase;
    if (type == 0x2C || type == 0x2D) ev[0x1c] = phase;   // pinch / rotate: phase at +0x1C, value at +0x20 (the map's pinch zoom reads it so)
    if (type == 0x2A) { *(float*)(ev + 0x1c) = a; *(float*)(ev + 0x20) = b; *(float*)(ev + 0x28) = c; *(float*)(ev + 0x2c) = d;
                        *(uint32_t*)(ev + 0x30) = 1920; *(uint32_t*)(ev + 0x34) = 1080; }   // pad size (wheels in 'absolute' mode)
    else if (type == 0x2E) { *(float*)(ev + 0x28) = a; *(float*)(ev + 0x2c) = b; *(float*)(ev + 0x30) = c; *(float*)(ev + 0x34) = d;
                             *(float*)(ev + 0x1c) = e; *(float*)(ev + 0x20) = f; }
    else { *(float*)(ev + 0x20) = a; *(float*)(ev + 0x24) = b; *(float*)(ev + 0x28) = c; *(float*)(ev + 0x2c) = d; }
    g_push(*(void**)dev, ev);
    InterlockedIncrement(&cTouchEv);
}
static void TouchPushFrame(BYTE *dev) {
    static int ok = -1, was1, was2; static DWORD t0; static int sx, sy, maxMove; static double d0, a0;
    if (!g_touchCsInit || !C.touchOn) return;
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL);
    if (ok < 0) {
        static const BYTE pro[11] = { 0x48, 0x89, 0x5C, 0x24, 0x18, 0x48, 0x89, 0x7C, 0x24, 0x20, 0x55 };
        ok = !memcmp(mod + 0xfae6d0, pro, sizeof pro);
        g_push = (PFN_PushEvent)(mod + 0xfae6d0); g_stamp = (uint32_t*)(mod + 0x28469f0);
        LOG("touchpad: game input event queue %s", ok ? "found - touch goes to the game's own touch controls" : "not found (other game build) - touch disabled");
    }
    if (!ok) return;
    TouchPt p0, p1; float dx, dy; int clicked;
    EnterCriticalSection(&g_touchCs);
    p0 = g_touch.p[0]; p1 = g_touch.p[1]; dx = g_touch.dx; dy = g_touch.dy; g_touch.dx = g_touch.dy = 0;
    clicked = g_touch.clicked; if (!p0.active && !p1.active) g_touch.clicked = 0;
    LeaveCriticalSection(&g_touchCs);
    DWORD now = GetTickCount();
    LONG pulse = 0, held = 0;
    static int hadTwo;                       // this contact had a second finger: no tap / swipe at the end of it
    static double stepD, stepA;              // pinch / rotate step reference for menu actions
    static float uiDragX, uiDragY;           // finger travel not yet turned into drag steps
    // one finger: drag every frame (begin / move / end) + tap / flick when it is lifted
    int one = p0.active;
    if (one || was1) {
        if (one && !was1) { t0 = now; sx = p0.x; sy = p0.y; maxMove = 0; hadTwo = 0; uiDragX = uiDragY = 0;
                            EnterCriticalSection(&g_touchCs); g_mapDX = g_mapDY = 0; LeaveCriticalSection(&g_touchCs); }
        if (one) { int m = abs(p0.x - sx) + abs(p0.y - sy); if (m > maxMove) maxMove = m; }
        PushGesture(dev, 0x2A, one ? (was1 ? 2 : 1) : 3, dx, dy, (float)(one ? p0.x : sx), (float)(one ? p0.y : sy), 0, 0);
        if (one && !p1.active && !hadTwo) {  // drag steps (menus): one step per DragStep pad pixels
            EnterCriticalSection(&g_touchCs); g_mapDX += dx; g_mapDY += dy; g_mapT = now; LeaveCriticalSection(&g_touchCs);
            uiDragX += dx; uiDragY += dy;
            float st = (float)C.uiDragStep;
            if (uiDragX >= st) { pulse |= 1 << UIG_DRAG_R; uiDragX -= st; } else if (uiDragX <= -st) { pulse |= 1 << UIG_DRAG_L; uiDragX += st; }
            if (uiDragY >= st) { pulse |= 1 << UIG_DRAG_D; uiDragY -= st; } else if (uiDragY <= -st) { pulse |= 1 << UIG_DRAG_U; uiDragY += st; }
            if (dx > 2) held |= 1 << UIG_DRAG_R; else if (dx < -2) held |= 1 << UIG_DRAG_L;
            if (dy > 2) held |= 1 << UIG_DRAG_D; else if (dy < -2) held |= 1 << UIG_DRAG_U;
        }
        if (!one) {
            DWORD dur = now - t0;
            int edge = sx < 40 || sx > 1880 || sy < 40 || sy > 1040;   // grip contact on the pad's rim, not a tap
            if (dur < 250 && maxMove < 60 && !was2 && !hadTwo && !clicked && !edge) {
                PushGesture(dev, 0x28, 0, sx / 1920.0f, sy / 1080.0f, (float)sx, (float)sy, 0, 0);
                pulse |= 1 << UIG_TAP;
                LOG("touchpad: tap at %d,%d", sx, sy);
            }
        }
        if (cTouchEv <= 8) LOG("touchpad: drag %s %d,%d d=%.0f,%.0f", one ? (was1 ? "move" : "begin") : "end", p0.x, p0.y, dx, dy);
    }
    // flick: fast swipe, sent when the finger is lifted
    {   static int lastX, lastY;
        if (one) { lastX = p0.x; lastY = p0.y; }
        else if (was1 && !was2 && !hadTwo && !clicked) {
            DWORD dur = now - t0; int ddx = lastX - sx, ddy = lastY - sy;
            if (dur < 400 && abs(ddx) + abs(ddy) > 250) {
                PushGesture(dev, 0x2E, 0, (float)lastX, (float)lastY, (float)sx, (float)sy, (float)ddx, (float)ddy);
                int onMap = g_mapUsedT && (LONG)(g_mapUsedT - t0) >= 0;   // this finger moved the map: not a tab swipe
                if (onMap) ;
                else if (abs(ddx) >= abs(ddy)) pulse |= 1 << (ddx > 0 ? UIG_FLICK_R : UIG_FLICK_L);
                else                      pulse |= 1 << (ddy > 0 ? UIG_FLICK_D : UIG_FLICK_U);
                LOG("touchpad: flick %+d,%+d in %lu ms", ddx, ddy, dur);
            }
        }
    }
    // two fingers: pinch (scale) and rotate (angle) every frame
    int two = p0.active && p1.active;
    if (two) hadTwo = 1;
    if (two || was2) {
        double vx = p1.x - p0.x, vy = p1.y - p0.y, d = sqrt(vx * vx + vy * vy), an = atan2(vy, vx);
        if (two && !was2) { d0 = d > 1 ? d : 1; a0 = an; stepD = d0; stepA = an; }
        float scale = two ? (float)(d / d0) : 1.0f, rot = two ? (float)(an - a0) : 0.0f;
        BYTE ph = two ? (was2 ? 2 : 1) : 3;
        PushGesture(dev, 0x2C, ph, scale, 0, 0, 0, 0, 0);
        PushGesture(dev, 0x2D, ph, rot, 0, 0, 0, 0, 0);
        if (two) {                           // menu steps: one zoom step per PinchStep ratio, one rotate step per RotateStep
            double ps = C.uiPinchStep;
            if (d > stepD * ps) { pulse |= 1 << UIG_PINCH_OUT; stepD = d; }
            else if (d * ps < stepD) { pulse |= 1 << UIG_PINCH_IN; stepD = d; }
            double da = an - stepA; while (da > 3.14159265) da -= 6.2831853; while (da < -3.14159265) da += 6.2831853;
            if (da > C.uiRotStep) { pulse |= 1 << UIG_ROT_R; stepA = an; } else if (da < -C.uiRotStep) { pulse |= 1 << UIG_ROT_L; stepA = an; }
            if (d > stepD * 1.02) held |= 1 << UIG_PINCH_OUT; else if (d * 1.02 < stepD) held |= 1 << UIG_PINCH_IN;
        }
        static float lastScale = 1.0f; if (two) lastScale = scale;
        if (two && !was2) LOG("touchpad: two fingers down (distance %.0f)", d);
        if (!two) LOG("touchpad: two fingers up (scale %.2f)", lastScale);
    }
    // hand finished gestures to the menus. They wait until a menu takes them (the game's input poll and its menu
    // update do not run in lockstep, a gesture that only lived until the next poll could be missed), but at most
    // 300 ms, and a gesture cancels the opposite one still waiting (pinch out then in = no backlog)
    static const signed char opp[UIG_COUNT] = { -1, UIG_FLICK_L, UIG_FLICK_R, UIG_FLICK_D, UIG_FLICK_U, UIG_PINCH_IN, UIG_PINCH_OUT,
                                                UIG_ROT_L, UIG_ROT_R, UIG_DRAG_L, UIG_DRAG_R, UIG_DRAG_D, UIG_DRAG_U };
    for (int k = 0; k < UIG_COUNT; k++) {
        if (C.uiTouch && ((pulse >> k) & 1)) {
            if (opp[k] >= 0) InterlockedExchange(&g_uiPend[opp[k]], 0);
            if (g_uiPend[k] < 3) InterlockedIncrement(&g_uiPend[k]);
            g_uiPendT[k] = now;
        } else if (g_uiPend[k] > 0 && (!C.uiTouch || now - g_uiPendT[k] > 300)) InterlockedExchange(&g_uiPend[k], 0);
    }
    g_uiHeld = C.uiTouch ? held : 0;
    if (pulse && C.uiTouch) { static int n; if (++n <= 200) LOG("touchpad: menu gesture bits %03lX", (unsigned long)pulse); }
    was1 = one; was2 = two;
}
// the game's touch bindings: which gameplay / UI actions the data binds to touchpad gestures (ControlOperation type 5)
static void DumpTouchBindings(BYTE *rt) {
    static const char *ga[] = { "MovementLeft","MovementRight","MovementUp","MovementDown","CameraLeft","CameraRight","CameraUp","CameraDown",
        "CameraZoomIn","CameraZoomOut","MainhandAction","MainhandAction_Tap","MainhandAction_Hold","MainhandAction_Release","SecondaryBuildingAction",
        "ContextualAction","ContextualAction_Tap","ContextualAction_Hold","AreaLoot","SpecialAbility","SpecialAbility_Tap","SpecialAbility_Hold","DropItem",
        "CancelAction","AmmunitionSelectPrevious","AmmunitionSelectNext" };
    int types[10] = { 0 }, touch = 0;
    for (int i = 0; i < 0x8d; i++) {
        BYTE *e = rt + 0x28 + i * 0x118;
        static const int offs[4] = { 0, 0x34, 0x88, 0xbc };
        for (int k = 0; k < 4; k++) {
            BYTE *op = e + offs[k]; if (op[0] < 10) types[op[0]]++;
            if (op[0] == 5) { touch++; LOG("touchpad binding: gameplay action %d%s%s slot %d gesture=%u axis=%u", i, i < 26 ? " " : "", i < 26 ? ga[i] : "", k, op[0xa], op[0xb]); }
        }
    }
    LOG("touchpad bindings: gameplay op types none=%d key=%d mouseBtn=%d wheel=%d mouseMove=%d touch=%d pad=%d axis=%d stick=%d",
        types[0], types[1], types[2], types[3], types[4], types[5], types[6], types[7], types[8]);
    static const int arr[2][2] = { { 0x9a40, 0x9a48 }, { 0x9f68, 0x9f70 } };
    for (int a = 0; a < 2; a++) {
        BYTE *base = *(BYTE**)(rt + arr[a][0]); uint64_t n = *(uint64_t*)(rt + arr[a][1]);
        int t5 = 0, tt[10] = { 0 };
        for (uint64_t j = 0; base && j < n && j < 4096; j++) {
            BYTE *op = base + j * 0x28; if (op[0] < 10) tt[op[0]]++;
            if (op[0] == 5) { t5++; char hx[0x28 * 3 + 1] = { 0 }; for (int q = 0; q < 0x28; q++) sprintf(hx + 3 * q, "%02X ", op[q]);
                              LOG("touchpad binding: ui list %d entry %llu: %s", a, (unsigned long long)j, hx); }
        }
        LOG("touchpad bindings: ui list %d has %llu entries (key=%d pad=%d touch=%d)", a, (unsigned long long)n, tt[1], tt[6], t5);
    }
    (void)touch;
}
// before the client input reads them: the game's InputSettingsTouchPad (options + 0xF9). The game ships the
// PS5 defaults there; only overwritten when [Touchpad] UseGameSettings=0
typedef uint64_t (*PFN9)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
static PFN9 o_clientSel;
static uint64_t H_clientSel(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e, uint64_t f, uint64_t g, uint64_t h, uint64_t i) {
    static int logged, dumped; static DWORD t0;
    if (g) {
        BYTE *t = (BYTE*)g + 0xF9;
        if (!logged) { logged = 1; t0 = GetTickCount(); char hx[3 * 0x1c + 1] = { 0 };
            for (int k = 0; k < 0x1c; k++) sprintf(hx + 3 * k, "%02X ", t[k]);
            LOG("touchpad: game's touch settings %s-> %s", hx, C.touchOverride ? "values from the ini" : "the game's own defaults"); }
        // the values the game itself ships (read from its options before EnshroudedSense touched them):
        // on, map on, both wheels drag (not opened by touch), action bar +X, ammo -Y, songs -Y, loot +X,
        // building shapes +X, pages -Y, materials -Y, NPC selection +X, NPC pages +X, roaming range -Y, logic +Y
        static const BYTE gameDefaults[0x1c] = { 1,1, 1,0, 1,0, 1,1, 1,4, 1,4, 1,1, 1,1, 1,4, 1,4, 1,1, 1,1, 1,4, 1,3 };
        if (C.touchOn) {
            memcpy(t, C.touchOverride ? C.touchCfg : gameDefaults, sizeof gameDefaults);
            t[3] = (BYTE)C.ewOpen; t[5] = (BYTE)C.qwOpen;   // the wheels' own "open on touch" option ([Touchpad] ...OpenOnTouch)
        }
    }
    if (e && !dumped && logged && GetTickCount() - t0 > 3000) { dumped = 1; DumpTouchBindings((BYTE*)e); }
    return o_clientSel(a, b, c, d, e, f, g, h, i);
}

static void ParseInput(const BYTE *r, int len) {
    const BYTE *p;
    if (!D.bt) { if (r[0] != 0x01 || len < 11) return; p = r + 1; }
    else {
        if (r[0] == 0x31 && len >= 12) p = r + 2;
        else if (r[0] == 0x01 && len >= 10) {  // reduced BT report before full mode is enabled
            XGAMEPAD g = {0};
            g.sThumbLX = axis(r[1], 0); g.sThumbLY = axis(r[2], 1);
            g.sThumbRX = axis(r[3], 0); g.sThumbRY = axis(r[4], 1);
            // buttons in r[5..7], triggers r[8], r[9]
            p = NULL;
            BYTE b0 = r[5], b1 = r[6], b2 = r[7];
            BYTE lt = r[8], rt = r[9];
            goto map_reduced;
        map_reduced:;
            {
                WORD w = 0; BYTE hat = b0 & 0x0F;
                if (hat == 0 || hat == 1 || hat == 7) w |= XB_UP;
                if (hat == 1 || hat == 2 || hat == 3) w |= XB_RIGHT;
                if (hat == 3 || hat == 4 || hat == 5) w |= XB_DOWN;
                if (hat == 5 || hat == 6 || hat == 7) w |= XB_LEFT;
                if (b0 & 0x10) w |= XB_X; if (b0 & 0x20) w |= XB_A;
                if (b0 & 0x40) w |= XB_B; if (b0 & 0x80) w |= XB_Y;
                if (b1 & 0x01) w |= XB_LSHOULDER; if (b1 & 0x02) w |= XB_RSHOULDER;
                if (b1 & 0x10) w |= XB_BACK; if (b1 & 0x20) w |= XB_START;
                if (b1 & 0x40) w |= XB_LTHUMB; if (b1 & 0x80) w |= XB_RTHUMB;
                if (b2 & 0x01) w |= XB_GUIDE;
                if (b2 & 0x02) { if (C.touchpadAs == 0) w |= XB_BACK; else if (C.touchpadAs == 1) w |= XB_START; }
                g.wButtons = w; g.bLeftTrigger = lt; g.bRightTrigger = rt;
                deadzone(&g.sThumbLX, &g.sThumbLY); deadzone(&g.sThumbRX, &g.sThumbRY);
                EnterCriticalSection(&D.cs);
                if (memcmp(&g, &D.pad, sizeof g)) D.packet++;
                D.pad = g; D.rawL2 = lt; D.rawR2 = rt; g_rawL2 = lt; g_rawR2 = rt;
                LeaveCriticalSection(&D.cs);
            }
            return;
        } else return;
    }
    // full report (common layout)
    XGAMEPAD g = {0};
    g.sThumbLX = axis(p[0], 0); g.sThumbLY = axis(p[1], 1);
    g.sThumbRX = axis(p[2], 0); g.sThumbRY = axis(p[3], 1);
    BYTE lt = p[4], rt = p[5];
    BYTE b0 = p[7], b1 = p[8], b2 = p[9];
    WORD w = 0; BYTE hat = b0 & 0x0F;
    if (hat == 0 || hat == 1 || hat == 7) w |= XB_UP;
    if (hat == 1 || hat == 2 || hat == 3) w |= XB_RIGHT;
    if (hat == 3 || hat == 4 || hat == 5) w |= XB_DOWN;
    if (hat == 5 || hat == 6 || hat == 7) w |= XB_LEFT;
    if (b0 & 0x10) w |= XB_X;      // square
    if (b0 & 0x20) w |= XB_A;      // cross
    if (b0 & 0x40) w |= XB_B;      // circle
    if (b0 & 0x80) w |= XB_Y;      // triangle
    if (b1 & 0x01) w |= XB_LSHOULDER;
    if (b1 & 0x02) w |= XB_RSHOULDER;
    if (b1 & 0x10) w |= XB_BACK;   // create
    if (b1 & 0x20) w |= XB_START;  // options
    if (b1 & 0x40) w |= XB_LTHUMB;
    if (b1 & 0x80) w |= XB_RTHUMB;
    if (b2 & 0x01) w |= XB_GUIDE;  // PS
    if (b2 & 0x02) { if (C.touchpadAs == 0) w |= XB_BACK; else if (C.touchpadAs == 1) w |= XB_START; }
    TouchCapture(p, b2 & 0x02);
    g.wButtons = w; g.bLeftTrigger = lt; g.bRightTrigger = rt;
    deadzone(&g.sThumbLX, &g.sThumbLY); deadzone(&g.sThumbRX, &g.sThumbRY);
    // --- gyro aiming: IMU at p[15..20] = pitch, yaw, roll (int16, ~16.4 LSB per deg/s)
    if (C.gyroMode) {
        static double biasP, biasY; static int still;
        double gp = (double)(int16_t)(p[15] | (p[16] << 8)) / 16.4;
        double gy = (double)(int16_t)(p[17] | (p[18] << 8)) / 16.4;
        if (fabs(gp - biasP) < 2.5 && fabs(gy - biasY) < 2.5) {            // controller at rest: track sensor drift
            if (still < 1000) still++;
            biasP += (gp - biasP) * 0.01; biasY += (gy - biasY) * 0.01;
        } else still = 0;
        gp -= biasP; gy -= biasY;
        int active = C.gyroMode == 2 || lt >= C.gyroAimThreshold;
        if (active) {
            double vx = -gy * C.gyroSensX / 150.0, vy = gp * C.gyroSensY / 150.0;   // 150 deg/s = full stick
            if (C.gyroInvertX) vx = -vx;
            if (C.gyroInvertY) vy = -vy;
            double m = sqrt(vx * vx + vy * vy);
            if (m > 0.004) {                                              // ~0.6 deg/s noise floor
                double nm = C.gyroAntiDeadzone + (1.0 - C.gyroAntiDeadzone) * (m > 1 ? 1 : m);
                vx = vx / m * nm; vy = vy / m * nm;
                double rx = g.sThumbRX / 32767.0 + vx, ry = g.sThumbRY / 32767.0 + vy;
                if (rx > 1) rx = 1; if (rx < -1) rx = -1; if (ry > 1) ry = 1; if (ry < -1) ry = -1;
                g.sThumbRX = (SHORT)(rx * 32767); g.sThumbRY = (SHORT)(ry * 32767);
                InterlockedIncrement(&g_gyroFrames);
                if ((LONG)(nm * 1000) > g_gyroMaxMilli) g_gyroMaxMilli = (LONG)(nm * 1000);
            }
        }
    }
    EnterCriticalSection(&D.cs);
    if (memcmp(&g, &D.pad, sizeof g)) D.packet++;
    D.pad = g; D.rawL2 = lt; D.rawR2 = rt; g_rawL2 = lt; g_rawR2 = rt;
    LeaveCriticalSection(&D.cs);
}

// ---------------------------------------------------------------- local player state (for lightbar / water)
// The HUD reads the local player's data through  S = [[[exe+0x283f4a8]+0xd0]]+0x38  (doPlayerHealthWidget,
// the oxygen widget and the low-health vignette all use it):
//   S+0xa8  64-bit state mask (keen player state enum: 7 Dead, 13 InFog, 43 FloatingOnWater, 44 UnderWater, 45 Suffocating)
//   S+0x578 health {current, max}     S+0x5cc oxygen {current, max}
#define ST_BLOCKING 2
#define ST_EXHAUSTED 6
#define ST_DEAD 7
#define ST_INFOG 13
#define ST_FLOATING 43
#define ST_UNDERWATER 44
#define ST_SUFFOCATING 45
typedef struct { int valid; uint64_t mask; int hp, hpMax, o2, o2Max; int bar[2][2]; int32_t raw[256]; int rawOk; } GameState;
static uint64_t g_S;                     // the player data the HUD shows (stable while you are in a world)
static GameState g_st; static int g_stOk = -1;
static int SafeRead(uint64_t addr, void *out, size_t n) {
    SIZE_T got = 0; return addr && ReadProcessMemory(GetCurrentProcess(), (void*)addr, out, n, &got) && got == n; }
static void ReadGameState(GameState *st) {
    memset(st, 0, sizeof *st);
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL);
    if (g_stOk < 0) {
        static const BYTE sig[7] = { 0x48, 0x8B, 0x05, 0x29, 0x68, 0xBD, 0x01 };   // mov rax,[rip+0x1bd6829] in doPlayerHealthWidget
        g_stOk = !memcmp(mod + 0xc68c78, sig, 7);
        LOG("player state reader: %s", g_stOk ? "game build matches" : "unknown game build - lightbar shows the static colour");
    }
    if (!g_stOk) return;
    // [[G+0xd0]] is the HUD's per-frame context and is usually empty between frames; the player data it points to
    // is stable, so remember it whenever the chain is complete and read it directly
    uint64_t G = 0, UI = 0, X = 0, S = 0; int v[2];
    if (SafeRead((uint64_t)(mod + 0x283f4a8), &G, 8) && SafeRead(G + 0xd0, &UI, 8) && SafeRead(UI, &X, 8) &&
        SafeRead(X + 0x38, &S, 8) && S && S != g_S) {
        int hm = 0; if (SafeRead(S + 0x57c, &hm, 4) && hm > 0 && hm < 10000000) { g_S = S; LOG("player data at %p", (void*)S); }
    }
    S = g_S; if (!S) return;
    if (!SafeRead(S + 0xa8, &st->mask, 8)) return;
    if (!SafeRead(S + 0x578, v, 8)) return; st->hp = v[0]; st->hpMax = v[1];
    if (!SafeRead(S + 0x5cc, v, 8)) return; st->o2 = v[0]; st->o2Max = v[1];
    if (SafeRead(S + 0x584, v, 8)) { st->bar[0][0] = v[0]; st->bar[0][1] = v[1]; }
    if (SafeRead(S + 0x59c, v, 8)) { st->bar[1][0] = v[0]; st->bar[1][1] = v[1]; }
    st->rawOk = SafeRead(S + 0x400, st->raw, sizeof st->raw);
    st->valid = st->hpMax > 0 && st->hpMax < 10000000 && st->hp >= 0 && st->hp <= st->hpMax * 4;
    if (!st->valid) g_S = 0;                         // world left / data moved: look it up again
}
static int StBit(const GameState *st, int b) { return st->valid && ((st->mask >> b) & 1); }

static void Mix(double *c, const double *o, double k) { for (int i = 0; i < 3; i++) c[i] = c[i] * (1 - k) + o[i] * k; }

// ---- Shroud timer: the game counts down the time you may stay in the Shroud. Its slot in the player data is
// found while you are in the Shroud: the value that falls by 1 per second (or 1000 per second / 1.0 per second)
static struct { int idx, kind, max; double frac; int32_t start[256]; DWORD t0; int active; float startF[256]; } g_fog = { -1 };
static void FogTimerUpdate(const GameState *st) {
    if (!st->valid || !st->rawOk) return;
    int in = StBit(st, ST_INFOG); DWORD now = GetTickCount();
    if (in && !g_fog.active) { g_fog.active = 1; g_fog.t0 = now; memcpy(g_fog.start, st->raw, sizeof g_fog.start);
        for (int i = 0; i < 256; i++) { float f; memcpy(&f, &st->raw[i], 4); g_fog.startF[i] = f; } }
    if (!in) { g_fog.active = 0; }
    if (g_fog.idx >= 0) {                                    // known slot: fraction left
        double cur, mx;
        if (g_fog.kind == 2) { float f; memcpy(&f, &st->raw[g_fog.idx], 4); cur = f; } else cur = st->raw[g_fog.idx];
        mx = g_fog.max > 0 ? g_fog.max : 1;
        if (cur > mx && in) { g_fog.max = (int)cur; mx = cur; }
        g_fog.frac = cur / mx; if (g_fog.frac < 0) g_fog.frac = 0; if (g_fog.frac > 1) g_fog.frac = 1;
        return;
    }
    if (!in) return;
    double e = (now - g_fog.t0) / 1000.0; if (e < 4.0) return;
    int best = -1, bestKind = 0; double bestErr = 1e9;
    for (int i = 0; i < 256; i++) {
        double d = (double)g_fog.start[i] - st->raw[i];
        static const double rates[2] = { 1.0, 1000.0 };
        for (int k = 0; k < 2; k++) {
            double err = fabs(d - e * rates[k]) / (e * rates[k]);
            if (d > 0 && err < 0.12 && err < bestErr && g_fog.start[i] < 100000 * rates[k]) { best = i; bestKind = k; bestErr = err; }
        }
        float f; memcpy(&f, &st->raw[i], 4);
        double fd = g_fog.startF[i] - f;
        if (isfinite(f) && isfinite(g_fog.startF[i]) && g_fog.startF[i] > 5 && g_fog.startF[i] < 100000 && fd > 0) {
            double err = fabs(fd - e) / e; if (err < 0.12 && err < bestErr) { best = i; bestKind = 2; bestErr = err; }
        }
    }
    if (best >= 0) {
        g_fog.idx = best; g_fog.kind = bestKind;
        int nb = best + 1 < 256 ? st->raw[best + 1] : 0;   // {current, max} pairs like health and oxygen
        g_fog.max = (bestKind != 2 && nb >= g_fog.start[best] && nb > 0) ? nb : (bestKind == 2 ? (int)g_fog.startF[best] : g_fog.start[best]);
        LOG("shroud timer found at player data +0x%X (%s), value %d -> %d over %.1f s, max %d",
            0x400 + best * 4, bestKind == 0 ? "seconds" : bestKind == 1 ? "milliseconds" : "float seconds",
            g_fog.start[best], st->raw[best], e, g_fog.max);
    }
}
static void LightbarColour(BYTE out[3]) {
    GameState st = g_st;
    double c[3] = { C.lightR, C.lightG, C.lightB };
    if (C.lbMode == 1 && st.valid) {                      // like the PS5 version: calm colour, red pulse when
        double t = GetTickCount() / 1000.0;                 // health is critical, Shroud colour showing the time left
        double h = (double)st.hp / (st.hpMax > st.hp ? st.hpMax : st.hp); if (h < 0) h = 0; if (h > 1) h = 1;
        double low = C.lbLowHealth / 100.0;
        if (h > 0 && h < low) {                               // critical health: red heartbeat, faster the lower
            double rate = 1.0 + (low - h) / low * 1.6, ph = fmod(t * rate, 1.0);
            double beat = exp(-ph * 9.0) + 0.6 * exp(-fabs(ph - 0.28) * 14.0); if (beat > 1) beat = 1;
            double r[3] = { 255, 0, 0 }; double b = 0.2 + 0.8 * beat;
            for (int i = 0; i < 3; i++) c[i] = r[i] * b;
        }
        if (StBit(&st, ST_DEAD) || st.hp <= 0) { c[0] = 50; c[1] = 0; c[2] = 0; }
        if (StBit(&st, ST_INFOG)) {                           // Shroud: violet -> red as the timer runs out, blinking faster
            double f = g_fog.idx >= 0 ? g_fog.frac : 1.0;
            double v[3] = { 150 + 105 * (1 - f), 0, 255 * f };
            double hz = C.lbShroudHz * (g_fog.idx >= 0 ? (1.0 + 3.0 * (1 - f)) : 1.0);
            double k = 0.55 + 0.45 * sin(2 * M_PI * hz * t);
            if (g_fog.idx >= 0 && f < 0.15) k = fmod(t * hz, 1.0) < 0.5 ? 1.0 : 0.15;
            for (int i = 0; i < 3; i++) c[i] = v[i] * k;
        }
        if (StBit(&st, ST_UNDERWATER)) {                      // under water: blue, dimmer as oxygen runs out
            double o = st.o2Max > 0 ? (double)st.o2 / st.o2Max : 1; if (o < 0) o = 0; if (o > 1) o = 1;
            double w[3] = { 0, 110 + 50 * o, 255 }; for (int i = 0; i < 3; i++) w[i] *= 0.35 + 0.65 * o;
            Mix(c, w, 0.85);
            if (o < 0.25 || StBit(&st, ST_SUFFOCATING)) { double r[3] = { 255, 0, 0 }; Mix(c, r, 0.5 + 0.5 * sin(2 * M_PI * 3.0 * t)); }
        }
    } else if (C.lbMode == 3 && st.valid) {                 // health gradient (EnshroudedSense 2.1 style)
        double t = GetTickCount() / 1000.0;
        double h = (double)st.hp / (st.hpMax > st.hp ? st.hpMax : st.hp); if (h < 0) h = 0; if (h > 1) h = 1;
        c[0] = h < 0.5 ? 255 : 255 * 2 * (1 - h);        // green (full) -> yellow (half) -> red (empty)
        c[1] = h > 0.5 ? 255 : 255 * 2 * h; c[2] = 0;
        double low = C.lbLowHealth / 100.0;
        if (h > 0 && h < low) {                           // heartbeat, faster the lower you are
            double rate = 1.0 + (low - h) / low * 1.6, ph = fmod(t * rate, 1.0);
            double beat = exp(-ph * 9.0) + 0.6 * exp(-fabs(ph - 0.28) * 14.0);
            double b = 0.25 + 0.75 * (beat > 1 ? 1 : beat); for (int i = 0; i < 3; i++) c[i] *= b;
        }
        if (StBit(&st, ST_DEAD) || st.hp <= 0) { c[0] = 50; c[1] = 0; c[2] = 0; }
        if (StBit(&st, ST_UNDERWATER)) {                  // under water: blue, dimmer as oxygen runs out
            double o = st.o2Max > 0 ? (double)st.o2 / st.o2Max : 1; if (o < 0) o = 0; if (o > 1) o = 1;
            double w[3] = { 0, 110 + 50 * o, 255 }; for (int i = 0; i < 3; i++) w[i] *= 0.35 + 0.65 * o;
            Mix(c, w, 0.85);
            if (o < 0.25 || StBit(&st, ST_SUFFOCATING)) {  // out of air: flash red
                double r[3] = { 255, 0, 0 }; double k = 0.5 + 0.5 * sin(2 * M_PI * 3.0 * t); Mix(c, r, k);
            }
        }
        if (StBit(&st, ST_INFOG)) {                       // Shroud: blink violet over the health colour
            double v[3] = { 150, 0, 255 }; double k = 0.5 + 0.5 * sin(2 * M_PI * C.lbShroudHz * t); Mix(c, v, k * 0.9);
        }
    }
    for (int i = 0; i < 3; i++) { double x = c[i] * C.lbBright; out[i] = (BYTE)(x < 0 ? 0 : x > 255 ? 255 : x); }
}

// trigger effect (11 bytes), raw DualSense modes
static void ApplyEff(BYTE *e, const Eff *x) {
    memset(e, 0, 11);
    int f;
    switch (x->mode) {
    case 1: e[0] = 0x01; e[1] = (BYTE)clampi(x->p1, 0, 255);
            f = clampi(x->p2 * C.triggerStrength / 100, 0, 255); e[2] = (BYTE)f; break;
    case 2: e[0] = 0x02; e[1] = (BYTE)clampi(x->p1, 0, 255); e[2] = (BYTE)clampi(x->p2, 0, 255);
            f = clampi(x->p3 * C.triggerStrength / 100, 0, 255); e[3] = (BYTE)f; break;
    case 6: e[0] = 0x06; e[1] = (BYTE)clampi(x->p1, 0, 255);
            f = clampi(x->p2 * C.triggerStrength / 100, 0, 255); e[2] = (BYTE)f; e[3] = (BYTE)clampi(x->p3, 0, 255); break;
    default: e[0] = 0x05; break;
    }
}
static void eff_off(BYTE *e) { memset(e, 0, 11); e[0] = 0x05; }

static int WriteReport(BYTE *buf, int len) {
    OVERLAPPED ov = {0}; ov.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    DWORD w = 0; BOOL ok = WriteFile(D.h, buf, len, &w, &ov);
    if (!ok && GetLastError() == ERROR_IO_PENDING) {
        if (WaitForSingleObject(ov.hEvent, 100) == WAIT_OBJECT_0) ok = GetOverlappedResult(D.h, &ov, &w, FALSE);
        else { CancelIoEx(D.h, &ov); GetOverlappedResult(D.h, &ov, &w, TRUE); ok = FALSE; }
    }
    CloseHandle(ov.hEvent);
    return ok;
}

static void BuildAndSend(int force) {
    BYTE c[47]; memset(c, 0, sizeof c);    // "common" output block
    WORD ml, mr; BYTE l2, r2; XGAMEPAD pad;
    EnterCriticalSection(&D.cs);
    ml = D.motorL; mr = D.motorR; l2 = D.rawL2; r2 = D.rawR2; pad = D.pad;
    LeaveCriticalSection(&D.cs);

    // --- rumble: exactly what the game sends (Xbox left = heavy motor, right = light motor)
    int L = clampi((int)ml * C.rumbleScale / 100 / 257, 0, 255);
    int R = clampi((int)mr * C.rumbleScale / 100 / 257, 0, 255);
    c[2] = (BYTE)R;                        // motor_right (small / high freq)
    c[3] = (BYTE)L;                        // motor_left  (big / low freq)
    int motorsAllowed = !(C.hapticsMode == 1 && Haptics_Active());   // HD haptics running -> leave the actuators to the audio stream

    // --- game vibration sounds (PS5 haptics) -> decaying motor pulses with the game's own timing and volume
    if (C.vibEnabled && motorsAllowed && !Haptics_GameSource()) {
        DWORD now = GetTickCount(); double amp = 0;
        for (int k = 0; k < 16; k++) {
            DWORD t0 = g_vib[k].t0; if (!t0) continue;
            DWORD dt = now - t0; if (dt > (DWORD)C.vibDecayMs * 4) continue;
            double a = g_vib[k].vol * exp(-(double)dt / C.vibDecayMs);
            if (a > amp) amp = a;
        }
        amp *= C.vibStrength; if (amp > 1) amp = 1;
        int H = (int)(amp * C.vibHeavy), Lt = (int)(amp * C.vibLight);
        if (c[3] < H) c[3] = (BYTE)H;
        if (c[2] < Lt) c[2] = (BYTE)Lt;
    }

    // --- adaptive triggers from the game's AdaptiveTriggerSystem
    c[0] |= 0x04 | 0x08;
    eff_off(c + 10); eff_off(c + 21);
    if (C.triggersEnabled && g_hooked) {
        int e = (int)g_gameEffect;
        if (GetTickCount() - g_effectTick > 300) e = 0;            // system stopped running (menu, loading)
        if (C.respectGameSetting && g_gameStrength == 0) e = 0;     // game option "Off"
        const Eff *x = &C.eff[e];
        int tr = x->trig;
        if (tr == 4) {                       // Auto: the trigger the player is actually holding for this action
            static int autoSide = 1;
            // follow the trigger that is pulling; switch only when the current one is released and the other is held
            BYTE cur = autoSide == 2 ? l2 : r2, oth = autoSide == 2 ? r2 : l2;
            if (cur < 25 && oth > 60) autoSide = autoSide == 2 ? 1 : 2;
            tr = autoSide;
        }
        if (tr & 1) ApplyEff(c + 10, x);
        if (tr & 2) ApplyEff(c + 21, x);
    }

    // --- recoil: the game just fired (bow / spell / ability) -> short kick on R2 + small motor pulse
    if (C.recoilEnabled && g_recoilKind && GetTickCount() < g_recoilUntil) {
        int kd = g_recoilKind;
        double f = 1.0 - (double)(GetTickCount() - g_recoilStart) / C.rc[kd].ms;   // fades out over the pulse
        if (f < 0) f = 0;
        Eff k = { 1, 6, C.rc[kd].freq, (int)(C.rc[kd].force * (0.4 + 0.6 * f)), 0 };
        ApplyEff(c + 10, &k);                                  // R2: the finger that fired
        int H = (int)(C.rc[kd].heavy * f), Lt = (int)(C.rc[kd].light * f);
        if (motorsAllowed) { if (c[3] < H) c[3] = (BYTE)H; if (c[2] < Lt) c[2] = (BYTE)Lt; }
    }
    if (GetTickCount() < g_motorTestUntil && !Haptics_Active()) { c[2] = 120; c[3] = 120; }

    // --- rumble flags (as the Linux hid-playstation driver does): only while motors run, plus one stop frame
    {   int on = c[2] || c[3];
        if (on || D.motorsWereOn) {
            c[0] |= 0x02;                                   // haptics select: classic rumble
            if (D.vibV2) c[38] |= 0x04; else c[0] |= 0x01;  // vibration v2 (fw >= 2.21) or compatible vibration
        }
        D.motorsWereOn = on;
    }

    // --- lightbar: game state (health / under water / Shroud) or a static colour
    if (C.lbMode) {
        BYTE rgb[3]; LightbarColour(rgb);
        c[1] |= 0x04 | 0x10;
        c[44] = rgb[0]; c[45] = rgb[1]; c[46] = rgb[2];
        c[43] = (BYTE)(C.playerLed | 0x20);
        if (C.lbPlayerLeds) {                   // PS5: 1 LED = player 1, 2 LEDs = player 2 ... (same patterns as the console)
            static const BYTE pat[6] = { 0x00, 0x04, 0x0A, 0x15, 0x1B, 0x1F };
            static LONG (*idFn)(void); static DWORD tried;
            if (!idFn && GetTickCount() - tried > 3000) { tried = GetTickCount(); HMODULE di = GetModuleHandleW(L"dinput8.dll");
                if (di) idFn = (LONG (*)(void))GetProcAddress(di, "ES_LocalPlayerId"); }
            LONG id = idFn ? idFn() : 0;
            if (id >= 1 && g_st.valid) c[43] = (BYTE)(pat[id > 5 ? 5 : id] | 0x20);
        }
        if (!D.ledInit) { c[38] |= 0x02; c[41] = 0x02; D.ledInit = 1; }
    }
    // --- built-in speaker: off by default on the controller; the game's speaker sounds are on audio channels 1/2
    if (C.spkHw && C.hapticsMode && C.hap.speakerVol > 0) {
        c[0] |= 0x20 | 0x80;                    // speaker volume + audio control valid
        c[5] = (BYTE)C.spkHwVol;                // 0..100 (PS5 uses 0x3D..0x64)
        c[7] = (BYTE)C.spkPath;                 // output path: 0x20 = headphones L + speaker R, 0x30 = speaker only
    }
    (void)pad; (void)l2; (void)r2;

    BYTE buf[80]; int len;
    memset(buf, 0, sizeof buf);
    if (!D.bt) { buf[0] = 0x02; memcpy(buf + 1, c, 47); len = D.outLen > 0 ? D.outLen : 48; if (len > 80) len = 48; }
    else {
        buf[0] = 0x31; buf[1] = (BYTE)(D.seq << 4); buf[2] = 0x10;
        memcpy(buf + 3, c, 47);
        len = 78;
        BYTE hdr = 0xA2;
        uint32_t crc = crc32_upd(0xFFFFFFFFu, &hdr, 1);
        crc = ~crc32_upd(crc, buf, 74);
        buf[74] = crc & 0xFF; buf[75] = (crc >> 8) & 0xFF; buf[76] = (crc >> 16) & 0xFF; buf[77] = crc >> 24;
    }
    DWORD now = GetTickCount();
    int same = !memcmp(buf + (D.bt ? 2 : 0), D.lastOut + (D.bt ? 2 : 0), D.bt ? 72 : len);
    if (!force && same && now - D.lastWrite < 1000) return;
    if (D.bt) {
        D.seq = (D.seq + 1) & 0x0F;
        buf[1] = (BYTE)(D.seq << 4);
        BYTE hdr = 0xA2;
        uint32_t crc = crc32_upd(0xFFFFFFFFu, &hdr, 1);
        crc = ~crc32_upd(crc, buf, 74);
        buf[74] = crc & 0xFF; buf[75] = (crc >> 8) & 0xFF; buf[76] = (crc >> 16) & 0xFF; buf[77] = crc >> 24;
    }
    if (WriteReport(buf, len)) { memcpy(D.lastOut, buf, len); D.lastWrite = now; }
}

static void SendReset(void) {
    if (!D.h) return;
    BYTE c[47]; memset(c, 0, sizeof c);
    c[0] = 0x01 | 0x02 | 0x04 | 0x08; eff_off(c + 10); eff_off(c + 21);
    BYTE buf[80]; memset(buf, 0, sizeof buf); int len;
    if (!D.bt) { buf[0] = 0x02; memcpy(buf + 1, c, 47); len = 48; }
    else {
        buf[0] = 0x31; buf[1] = (BYTE)(((D.seq + 1) & 0x0F) << 4); buf[2] = 0x10; memcpy(buf + 3, c, 47); len = 78;
        BYTE hdr = 0xA2; uint32_t crc = crc32_upd(0xFFFFFFFFu, &hdr, 1); crc = ~crc32_upd(crc, buf, 74);
        buf[74] = crc & 0xFF; buf[75] = (crc >> 8) & 0xFF; buf[76] = (crc >> 16) & 0xFF; buf[77] = crc >> 24;
    }
    WriteReport(buf, len);
}

static void EnableBtFullReports(void) {
    // reading feature report 0x05 (calibration) switches a BT DualSense to the full 0x31 report
    BYTE f[41] = {0x05};
    HidD_GetFeature(D.h, f, sizeof f);
}

// ---- shield / ward: the game's Blocking state, the stamina a blocked hit drains and the Exhausted state
// (block broken) - the same moments the game plays its OnBlockFeedback / OnBrokenBlockFeedback effects
static volatile LONG g_blockState;      // bit0 blocking, bit1 just stopped blocking (300 ms), read by dinput8.dll
__declspec(dllexport) int ES_BlockState(void) { return g_blockState; }
static void BlockUpdate(const GameState *st, const GameState *pv, DWORD now) {
    static DWORD endT, lastHit, lastBreak; static int was;
    int on = StBit(st, ST_BLOCKING);
    if (!on && was) endT = now;
    g_blockState = (on ? 1 : 0) | (!on && now - endT < 300 ? 2 : 0);
    if (!C.blockFx || !st->valid || !pv->valid) { was = on; return; }
    double k = C.blockStrength;
    if (on && !was) { Haptics_Push(C.blockWard ? HAP_WARD_UP : HAP_SHIELD_UP, (float)(0.45 * k)); LOG("block: raised (%s)", C.blockWard ? "ward" : "shield"); }
    if (on || now - endT < 250) {
        double drop = 0;                                   // biggest relative drain of the two energy bars this sample
        for (int b = 0; b < 2; b++) if (st->bar[b][1] > 0 && pv->bar[b][1] == st->bar[b][1] && st->bar[b][0] < pv->bar[b][0])
            { double d = (double)(pv->bar[b][0] - st->bar[b][0]) / st->bar[b][1]; if (d > drop) drop = d; }
        double hpd = st->hp < pv->hp ? (double)(pv->hp - st->hp) / st->hpMax : 0;
        if ((drop >= 0.004 || hpd > 0.002) && now - lastHit > 90) {
            double a = 0.4 + drop * 4.0 + hpd * 6.0; if (a > 1) a = 1;
            Haptics_Push(C.blockWard ? HAP_WARD_HIT : HAP_SHIELD_HIT, (float)(a * k)); lastHit = now;
            LOG("block: hit (stamina -%.1f%%, health -%.1f%%)", drop * 100, hpd * 100);
        }
    }
    if (StBit(st, ST_EXHAUSTED) && !StBit(pv, ST_EXHAUSTED) && (on || now - endT < 400) && now - lastBreak > 500) {
        Haptics_Push(HAP_BLOCK_BREAK, (float)(1.0 * k)); lastBreak = now; LOG("block: broken");
    }
    was = on;
}

// every 16 ms: local player state -> lightbar colour, block effects, water haptics; log state changes
static void UpdateGameState(void) {
    GameState st; ReadGameState(&st);
    static GameState prev; static DWORD lastLog;
    DWORD now = GetTickCount();
    uint64_t watch = (1ull << ST_DEAD) | (1ull << ST_INFOG) | (1ull << ST_FLOATING) | (1ull << ST_UNDERWATER) | (1ull << ST_SUFFOCATING) |
                     (1ull << ST_BLOCKING) | (1ull << ST_EXHAUSTED);
    if (st.valid != prev.valid || ((st.mask ^ prev.mask) & watch) || (now - lastLog > 10000 && st.valid)) {
        LOG("player: valid=%d hp=%d/%d o2=%d/%d bars=%d/%d %d/%d mask=%016llX%s%s%s%s%s%s%s fog=%s%.2f", st.valid, st.hp, st.hpMax,
            st.o2, st.o2Max, st.bar[0][0], st.bar[0][1], st.bar[1][0], st.bar[1][1],
            (unsigned long long)st.mask, StBit(&st, ST_INFOG) ? " InFog" : "", StBit(&st, ST_UNDERWATER) ? " UnderWater" : "",
            StBit(&st, ST_FLOATING) ? " Swimming" : "", StBit(&st, ST_SUFFOCATING) ? " Suffocating" : "", StBit(&st, ST_DEAD) ? " Dead" : "",
            StBit(&st, ST_BLOCKING) ? " Blocking" : "", StBit(&st, ST_EXHAUSTED) ? " Exhausted" : "",
            g_fog.idx >= 0 ? "" : "?", g_fog.frac);
        lastLog = now;
    }
    FogTimerUpdate(&st);
    BlockUpdate(&st, &prev, now);
    prev = st; g_st = st;
    float water = 0;
    if (StBit(&st, ST_UNDERWATER) || StBit(&st, ST_FLOATING)) {
        XGAMEPAD pad; EnterCriticalSection(&D.cs); pad = D.pad; LeaveCriticalSection(&D.cs);
        double m = sqrt((double)pad.sThumbLX * pad.sThumbLX + (double)pad.sThumbLY * pad.sThumbLY) / 32767.0; if (m > 1) m = 1;
        water = (float)((StBit(&st, ST_UNDERWATER) ? 0.35 : 0.15) + 0.65 * m);
    }
    Haptics_SetWater(water);
}

static DWORD WINAPI Worker(LPVOID _) {
    (void)_;
    BYTE in[128];
    while (!g_quit) {
        int bt, il, ol;
        HANDLE h = OpenDualSense(&bt, &il, &ol);
        if (h == INVALID_HANDLE_VALUE) { Sleep(1500); continue; }
        D.h = h; D.bt = bt; D.inLen = il; D.outLen = ol; D.ledInit = 0; memset(D.lastOut, 0, sizeof D.lastOut);
        if (bt) EnableBtFullReports();
        {   BYTE f[64] = { 0x20 };
            if (HidD_GetFeature(h, f, sizeof f)) {
                unsigned upd = f[44] | (f[45] << 8), fw = f[28] | (f[29] << 8) | (f[30] << 16) | ((unsigned)f[31] << 24);
                D.vibV2 = upd >= 0x0215;
                LOG("DualSense firmware 0x%08X update 0x%04X -> %s rumble", fw, upd, D.vibV2 ? "v2" : "classic");
            } else { D.vibV2 = 0; LOG("could not read DualSense firmware info"); }
        }
        g_motorTestUntil = GetTickCount() + 250;                          // short motor pulse on connect
        InterlockedExchange(&D.connected, 1);
        LOG("connected");
        OVERLAPPED ov = {0}; ov.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
        BuildAndSend(1);
        DWORD lastOut = GetTickCount(), lastState = 0;
        while (!g_quit) {
            DWORD got = 0; ResetEvent(ov.hEvent);
            BOOL ok = ReadFile(h, in, il > 0 && il <= (int)sizeof in ? il : 64, &got, &ov);
            if (!ok && GetLastError() != ERROR_IO_PENDING) break;
            DWORD wr = WaitForSingleObject(ov.hEvent, 8);
            if (wr == WAIT_OBJECT_0) {
                if (!GetOverlappedResult(h, &ov, &got, FALSE)) break;
                ParseInput(in, (int)got);
            } else {
                CancelIoEx(h, &ov); GetOverlappedResult(h, &ov, &got, TRUE);
            }
            DWORD now = GetTickCount();
            if (now - lastState >= 16) { UpdateGameState(); lastState = now; }
            if (now - lastOut >= 8) { BuildAndSend(0); lastOut = now; }
        }
        CloseHandle(ov.hEvent);
        if (g_quit) { SendReset(); InterlockedExchange(&D.connected, 0); return 0; }
        InterlockedExchange(&D.connected, 0);
        EnterCriticalSection(&D.cs); memset(&D.pad, 0, sizeof D.pad); LeaveCriticalSection(&D.cs);
        CloseHandle(h); D.h = NULL;
        LOG("disconnected, waiting for controller");
        Sleep(500);
    }
    return 0;
}

// ---------------------------------------------------------------- init
static void LoadReal(void) {
    if (g_real) return;
    wchar_t p[MAX_PATH]; GetSystemDirectoryW(p, MAX_PATH); wcscat(p, L"\\xinput1_4.dll");
    g_real = LoadLibraryW(p);
    if (!g_real) { GetSystemDirectoryW(p, MAX_PATH); wcscat(p, L"\\xinput1_3.dll"); g_real = LoadLibraryW(p); }
    if (!g_real) return;
    r_GetState = (PFN_GetState)GetProcAddress(g_real, "XInputGetState");
    r_GetStateEx = (PFN_GetState)GetProcAddress(g_real, (LPCSTR)100);
    r_SetState = (PFN_SetState)GetProcAddress(g_real, "XInputSetState");
    r_GetCaps = (PFN_GetCaps)GetProcAddress(g_real, "XInputGetCapabilities");
    r_Enable = (PFN_Enable)GetProcAddress(g_real, "XInputEnable");
    r_GetBattery = (PFN_GetBattery)GetProcAddress(g_real, "XInputGetBatteryInformation");
    r_GetKeystroke = (PFN_GetKeystroke)GetProcAddress(g_real, "XInputGetKeystroke");
    r_GetAudio = (PFN_GetAudio)GetProcAddress(g_real, "XInputGetAudioDeviceIds");
}

static void Start(void) {
    if (InterlockedCompareExchange(&g_started, 1, 0)) return;
    LoadReal();
    LoadConfig();
    if (C.log) {
        wchar_t lp[MAX_PATH]; swprintf(lp, MAX_PATH, L"%ls\\EnshroudedSense.log", g_dir);
        g_log = _wfopen(lp, L"w");
    }
    LOG("EnshroudedSense 2.2 loaded (enabled=%d triggers=%d rumble=%d%% lightbar=%d speaker=%d/%d water=%.2f)",
        C.enabled, C.triggersEnabled, C.rumbleScale, C.lbMode, C.spkHw, C.spkHwVol, C.hap.waterGain);
    {   // programs that also grab the DualSense and would fight over triggers / rumble
        HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (sn != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32W pe; pe.dwSize = sizeof pe; int n = 0;
            for (BOOL ok = Process32FirstW(sn, &pe); ok; ok = Process32NextW(sn, &pe)) {
                const wchar_t *x = pe.szExeFile;
                if (_wcsnicmp(x, L"DSX", 3) == 0 || _wcsnicmp(x, L"DualSenseX", 10) == 0 || _wcsnicmp(x, L"DS4Windows", 10) == 0 ||
                    _wcsnicmp(x, L"reWASD", 6) == 0 || _wcsnicmp(x, L"x360ce", 6) == 0 || _wcsnicmp(x, L"InputMapper", 11) == 0) {
                    LOG("WARNING: %ls is running - it also controls the DualSense", x); n++; }
            }
            CloseHandle(sn);
            if (!n) LOG("no other DualSense tools running");
        }
    }
    if (!C.enabled) return;
    if (C.hapticsMode) Haptics_Start(&C.hap, LOG);
    if (C.triggersEnabled) InstallHook();
    crc_init();
    g_thread = CreateThread(NULL, 0, Worker, NULL, 0, NULL);
}

// map a game pad index to a real xinput index (player 2.. -> real pads 0..)
static int RealIndex(DWORD i, int *isDs) {
    *isDs = 0;
    if (C.enabled && D.connected) {
        if (i == 0) { *isDs = 1; return -1; }
        return C.realPadsToo ? (int)i - 1 : -2;
    }
    return (int)i;
}

#define NOT_CONNECTED 1167 /* ERROR_DEVICE_NOT_CONNECTED */


// ---------------------------------------------------------------- diagnostics
static volatile LONG cGet, cGetEx, cSet, cCaps, cScan, cPoll, cFocus, cOther;
static volatile LONG lastFocusOk = -1, lastFocusByte = -1, lastScanFlag = -1;
static volatile LONG lastSetL, lastSetR, nonZeroSet;
typedef uint64_t (*PFN4)(uint64_t, uint64_t, uint64_t, uint64_t);
static PFN4 o_scan, o_poll, o_focus;
static uint64_t H_scan(uint64_t a, uint64_t b, uint64_t c, uint64_t d) {
    InterlockedIncrement(&cScan); lastScanFlag = ((BYTE*)a)[0x28]; return o_scan(a, b, c, d); }
__declspec(dllexport) DWORD WINAPI XInputGetStateEx(DWORD i, XSTATE *s);
__declspec(dllexport) DWORD WINAPI XInputSetState(DWORD i, XVIBRATION *v);
__declspec(dllexport) DWORD WINAPI XInputGetCapabilities(DWORD i, DWORD flags, XCAPS *c);
static volatile LONG g_tableFixed;
static void ModName(void *p, char *out, int n) {
    HMODULE m = NULL; out[0] = 0;
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)p, &m) && m) {
        char f[MAX_PATH]; GetModuleFileNameA(m, f, MAX_PATH); char *b = strrchr(f, '\\'); snprintf(out, n, "%s+0x%llX", b ? b + 1 : f, (unsigned long long)((BYTE*)p - (BYTE*)m));
    } else snprintf(out, n, "%p", p);
}
static DWORD WINAPI I_GetStateEx(DWORD i, XSTATE *st);
static DWORD WINAPI I_SetState(DWORD i, XVIBRATION *v);
static DWORD WINAPI I_GetCaps(DWORD i, DWORD f, XCAPS *c);
static uint64_t H_poll(uint64_t a, uint64_t b, uint64_t c, uint64_t d) {
    InterlockedIncrement(&cPoll);
    void **table = *(void***)(a + 0x18);          // slot -> game's XInput function table (module, GetStateEx, SetState, GetCaps)
    if (table && C.enabled && !InterlockedCompareExchange(&g_tableFixed, 1, 0)) {
        char n1[160], n2[160], n3[160];
        ModName(table[1], n1, sizeof n1); ModName(table[2], n2, sizeof n2); ModName(table[3], n3, sizeof n3);
        LOG("game XInput table: GetStateEx=%s SetState=%s GetCaps=%s", n1, n2, n3);
        {   BYTE *e1 = (BYTE*)XInputGetStateEx, *e2 = (BYTE*)XInputSetState;
            LOG("export prologues: GetStateEx %02X %02X %02X %02X %02X | SetState %02X %02X %02X %02X %02X (E9/FF25 = hooked by another module)",
                e1[0], e1[1], e1[2], e1[3], e1[4], e2[0], e2[1], e2[2], e2[3], e2[4]); }
        // point the game straight at internal functions: nothing else (e.g. Steam overlay) has hooked those
        table[1] = (void*)I_GetStateEx; table[2] = (void*)I_SetState; table[3] = (void*)I_GetCaps;
        LOG("game XInput table redirected to EnshroudedSense internal functions");
    }
    // slot index 0 not connected yet -> run the game's own connect check (r8 = 0) for it
    if (table && C.enabled && D.connected && *(int*)(a + 0x10) == 0 && *(BYTE*)(a + 0x20) == 0) {
        static DWORD lastTry; DWORD now = GetTickCount();
        if (now - lastTry > 1000) {
            lastTry = now;
            uint64_t r = o_poll(a, b, 0, d);
            LOG("connect check slot0: getEx=%ld connected=%d", cGetEx, *(BYTE*)(a + 0x20));
            return r;
        }
    }
    uint64_t r = o_poll(a, b, c, d);
    if (C.enabled && D.connected && *(int*)(a + 0x10) == 0 && *(BYTE*)(a + 0x20)) TouchPushFrame((BYTE*)a);
    return r; }
typedef uint64_t (*PFN5)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
static volatile LONG cVibStart, cVibOk, cSpkStart, cSpkOk;
static PFN5 o_vib, o_spk;
static uint64_t H_vib(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e) {
    uint64_t r = o_vib(a, b, c, d, e); InterlockedIncrement(&cVibStart);
    if ((DWORD)r) {
        InterlockedIncrement(&cVibOk);
        float vol = 1.0f;
        if (e) { float v = *(float*)((BYTE*)e + 0x20); if (v >= 0.0f && v <= 4.0f) vol = v; }   // game's volume for this vibration sound
        LONG k = InterlockedIncrement(&g_vibHead) & 15;
        g_vib[k].vol = vol; g_vib[k].t0 = GetTickCount();
        if (C.vibEnabled && C.hapticsMode && !Haptics_GameSource()) { float a = (float)(vol * 0.55 * C.vibStrength); Haptics_Push(HAP_GAME, a > 1.2f ? 1.2f : a); }
        if (cVibOk <= 60) LOG("game vibration sound #%ld: type=%u volume=%.2f", cVibOk, (unsigned)(b & 0xFF), vol);
    }
    return r; }
static uint64_t H_spk(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e) {
    uint64_t r = o_spk(a, b, c, d, e); InterlockedIncrement(&cSpkStart); if ((DWORD)r) InterlockedIncrement(&cSpkOk); return r; }
static uint64_t H_focus(uint64_t a, uint64_t b, uint64_t c, uint64_t d) {
    uint64_t r = o_focus(a, b, c, d); InterlockedIncrement(&cFocus);
    lastFocusOk = (LONG)(r & 0xFF); lastFocusByte = ((BYTE*)a)[0x1b]; return r; }

static BYTE *NearAlloc(BYTE *near_) {
    for (uintptr_t d = 0x10000; d < 0x70000000; d += 0x10000) {
        BYTE *p = (BYTE*)VirtualAlloc((BYTE*)(((uintptr_t)near_ & ~0xFFFFull) + 0x80000000ull - d), 4096,
                                      MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
        if (p) { int64_t r = p - near_; if (r < INT32_MAX && r > INT32_MIN) return p; VirtualFree(p, 0, MEM_RELEASE); }
    }
    return NULL;
}
static BYTE *g_tramp; static int g_trampUsed;
static int HookCall(DWORD siteRva, DWORD targetRva, void *fn, PFN4 *orig) {
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL), *site = mod + siteRva;
    if (site[0] != 0xE8) { LOG("diag: site +%X is not a call", siteRva); return 0; }
    BYTE *tgt = site + 5 + *(int32_t*)(site + 1);
    if (tgt != mod + targetRva) { LOG("diag: site +%X calls +%llX, expected +%X (other game build)", siteRva, (unsigned long long)(tgt - mod), targetRva); return 0; }
    if (!g_tramp) g_tramp = NearAlloc(mod);
    if (!g_tramp) { LOG("diag: no trampoline memory"); return 0; }
    BYTE *t = g_tramp + g_trampUsed; g_trampUsed += 16;
    t[0] = 0xFF; t[1] = 0x25; *(int32_t*)(t + 2) = 0; memcpy(t + 6, &fn, 8);
    *orig = (PFN4)tgt;
    int32_t rel = (int32_t)(t - (site + 5)); DWORD old;
    VirtualProtect(site, 5, PAGE_EXECUTE_READWRITE, &old); memcpy(site + 1, &rel, 4); VirtualProtect(site, 5, old, &old);
    FlushInstructionCache(GetCurrentProcess(), site, 5);
    return 1;
}
static void Start(void);
static DWORD WINAPI DiagThread(LPVOID _) {
    (void)_;
    Sleep(1500);
    Start();
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL);
    IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS*)(mod + ((IMAGE_DOS_HEADER*)mod)->e_lfanew);
    LOG("diag: exe timestamp %08lX size %08lX", nt->FileHeader.TimeDateStamp, nt->OptionalHeader.SizeOfImage);
    int ok = 0;
    ok += HookCall(0xfbbd21, 0xfb0690, (void*)H_scan, &o_scan);
    PFN4 tmp; ok += HookCall(0xfbbf94, 0xfb0690, (void*)H_scan, &tmp);
    ok += HookCall(0xfb4fbc, 0xfbc190, (void*)H_poll, &o_poll);
    ok += HookCall(0x3b229f, 0x247270, (void*)H_clientSel, (PFN4*)&o_clientSel);
    if (C.touchOn) {   // map: move with a finger (the PS5 'Touch > Map' option)
        static const BYTE apply[] = { 0xF3,0x0F,0x10,0x49,0x10, 0x0F,0x57,0xC0, 0x0F,0x2F,0xC8 };   // movss xmm1,[rcx+0x10]; xorps; comiss
        if (!memcmp(mod + 0xb377b0, apply, sizeof apply)) {
            g_mapApplyOffset = (void (*)(void*))(mod + 0xb377b0);
            int mh = HookCall(0xd4ea95, 0xd51ff0, (void*)H_mapInput, (PFN4*)&o_mapInput);
            LOG("touchpad: map finger drag %s", mh ? "on" : "off (game build differs)");
        } else LOG("touchpad: map finger drag off (game build differs)");
    }
    ok += HookCall(0xfbbd0f, 0xfa3360, (void*)H_focus, &o_focus);
    ok += HookCall(0xfbbf72, 0xfa3360, (void*)H_focus, &tmp);
    ok += HookCall(0x1073fdb, 0x106f470, (void*)H_vib, (PFN4*)&o_vib);
    ok += HookCall(0x1073ed1, 0x106f470, (void*)H_spk, (PFN4*)&o_spk);
    if (C.touchOn && C.uiTouch) {   // touch in menus: evaluator case first, then the query hook that uses it
        int uc = InstallUiTouchCase(mod);
        int uq = HookCall(0xda6c6b, 0xda5e50, (void*)H_uiAction, (PFN4*)&o_uiAction);
        ok += uc + uq;
        LOG("touchpad: menus %s", uc && uq ? "on" : "off (game build differs)");
    }
    { BYTE *ss = mod + 0x90af8b; LOG("diag: sound flags in code now: speaker=%d vibration=%d", ss[5], ss[6]); }
    LOG("diag: %d/10 probes installed", ok);
    for (int i = 0; !g_quit; i++) {
        Sleep(2000);
        UiDiagLog();
        if (i >= 300) continue;
        int ab = 0, vp = 0, sp = 0; Haptics_Status(&ab, &vp, &sp);
        LOG("diag: audioBlocks=%d vibPeak=%.3f spkPeak=%.3f gameSrc=%d | gyro=%ld frames max=%.2f | vibSnd=%ld/%ld spkSnd=%ld/%ld | scan=%ld poll=%ld focusChk=%ld(ok=%ld byte=%ld) scanFlag=%ld | XInput get=%ld getEx=%ld set=%ld(nonzero=%ld last=%ld/%ld) caps=%ld other=%ld | DS=%ld effect=%ld",
            ab, vp / 1000.0, sp / 1000.0, Haptics_GameSource(), g_gyroFrames, g_gyroMaxMilli / 1000.0, cVibOk, cVibStart, cSpkOk, cSpkStart, cScan, cPoll, cFocus, lastFocusOk, lastFocusByte, lastScanFlag, cGet, cGetEx, cSet, nonZeroSet, lastSetL, lastSetR, cCaps, cOther,
            D.connected, g_gameEffect);
    }
    return 0;
}

static DWORD GetStateImpl(DWORD i, XSTATE *s, int ex) {
    Start();
    if (!s) return ERROR_BAD_ARGUMENTS;
    int ds; int ri = RealIndex(i, &ds);
    if (ds) {
        EnterCriticalSection(&D.cs);
        s->dwPacketNumber = D.packet; s->Gamepad = D.pad;
        LeaveCriticalSection(&D.cs);
        if (!C.xinputInput) { memset(&s->Gamepad, 0, sizeof s->Gamepad); s->dwPacketNumber = 1; }
        if (!ex) s->Gamepad.wButtons &= ~XB_GUIDE;
        return ERROR_SUCCESS;
    }
    if (ri < 0) return NOT_CONNECTED;
    PFN_GetState f = ex && r_GetStateEx ? r_GetStateEx : r_GetState;
    return f ? f((DWORD)ri, s) : NOT_CONNECTED;
}

__declspec(dllexport) DWORD WINAPI XInputGetState(DWORD i, XSTATE *s) { InterlockedIncrement(&cGet); return GetStateImpl(i, s, 0); }
__declspec(dllexport) DWORD WINAPI XInputGetStateEx(DWORD i, XSTATE *s) { InterlockedIncrement(&cGetEx); return GetStateImpl(i, s, 1); }

static DWORD SetStateImpl(DWORD i, XVIBRATION *v) {
    InterlockedIncrement(&cSet);
    if (v) { lastSetL = v->wLeftMotorSpeed; lastSetR = v->wRightMotorSpeed; if (lastSetL || lastSetR) InterlockedIncrement(&nonZeroSet); }
    Start();
    if (!v) return ERROR_BAD_ARGUMENTS;
    int ds; int ri = RealIndex(i, &ds);
    if (ds) {
        EnterCriticalSection(&D.cs);
        D.motorL = v->wLeftMotorSpeed; D.motorR = v->wRightMotorSpeed;
        LeaveCriticalSection(&D.cs);
        return ERROR_SUCCESS;
    }
    if (ri < 0) return NOT_CONNECTED;
    return r_SetState ? r_SetState((DWORD)ri, v) : NOT_CONNECTED;
}
__declspec(dllexport) DWORD WINAPI XInputSetState(DWORD i, XVIBRATION *v) { return SetStateImpl(i, v); }

static DWORD GetCapsImpl(DWORD i, DWORD flags, XCAPS *c) {
    InterlockedIncrement(&cCaps);
    Start();
    if (!c) return ERROR_BAD_ARGUMENTS;
    int ds; int ri = RealIndex(i, &ds);
    if (ds) {
        memset(c, 0, sizeof *c);
        c->Type = 1; c->SubType = 1;  // gamepad
        c->Flags = 0x0004;            // XINPUT_CAPS_FFB_SUPPORTED
        c->Gamepad.wButtons = 0xF7FF; c->Gamepad.bLeftTrigger = c->Gamepad.bRightTrigger = 0xFF;
        c->Gamepad.sThumbLX = c->Gamepad.sThumbLY = c->Gamepad.sThumbRX = c->Gamepad.sThumbRY = (SHORT)0xFFC0;
        c->Vibration.wLeftMotorSpeed = c->Vibration.wRightMotorSpeed = 0xFFFF;
        return ERROR_SUCCESS;
    }
    if (ri < 0) return NOT_CONNECTED;
    return r_GetCaps ? r_GetCaps((DWORD)ri, flags, c) : NOT_CONNECTED;
}
__declspec(dllexport) DWORD WINAPI XInputGetCapabilities(DWORD i, DWORD flags, XCAPS *c) { return GetCapsImpl(i, flags, c); }

// internal entry points handed directly to the game's XInput table (not exported, so nobody hooks them)
static DWORD WINAPI I_GetStateEx(DWORD i, XSTATE *st) { InterlockedIncrement(&cGetEx); return GetStateImpl(i, st, 1); }
static DWORD WINAPI I_SetState(DWORD i, XVIBRATION *v) { return SetStateImpl(i, v); }
static DWORD WINAPI I_GetCaps(DWORD i, DWORD f, XCAPS *c) { return GetCapsImpl(i, f, c); }

__declspec(dllexport) void WINAPI XInputEnable(BOOL e) {
    InterlockedIncrement(&cOther);
    Start();
    if (!e) { EnterCriticalSection(&D.cs); D.motorL = D.motorR = 0; LeaveCriticalSection(&D.cs); }
    if (r_Enable) r_Enable(e);
}

__declspec(dllexport) DWORD WINAPI XInputGetBatteryInformation(DWORD i, BYTE type, XBATTERY *b) {
    InterlockedIncrement(&cOther);
    Start();
    int ds; int ri = RealIndex(i, &ds);
    if (ds) { if (b) { b->BatteryType = D.bt ? 2 : 1; b->BatteryLevel = 3; } return ERROR_SUCCESS; }
    if (ri < 0) return NOT_CONNECTED;
    return r_GetBattery ? r_GetBattery((DWORD)ri, type, b) : NOT_CONNECTED;
}

__declspec(dllexport) DWORD WINAPI XInputGetKeystroke(DWORD i, DWORD res, void *k) {
    InterlockedIncrement(&cOther);
    Start();
    int ds; int ri = RealIndex(i, &ds);
    if (ds || ri < 0) return ERROR_EMPTY;
    return r_GetKeystroke ? r_GetKeystroke((DWORD)ri, res, k) : NOT_CONNECTED;
}

__declspec(dllexport) DWORD WINAPI XInputGetAudioDeviceIds(DWORD i, LPWSTR a, UINT *ac, LPWSTR b, UINT *bc) {
    InterlockedIncrement(&cOther);
    Start();
    int ds; int ri = RealIndex(i, &ds);
    if (ds || ri < 0) return NOT_CONNECTED;
    return r_GetAudio ? r_GetAudio((DWORD)ri, a, ac, b, bc) : NOT_CONNECTED;
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID res) {
    (void)res;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        InitializeCriticalSection(&D.cs);
        InitializeCriticalSection(&g_touchCs); g_touchCsInit = 1;
        GetModuleFileNameW(inst, g_dir, MAX_PATH);
        wchar_t *s = wcsrchr(g_dir, L'\\'); if (s) *s = 0;
        {   // write a marker immediately so we know the game loaded us
            wchar_t lp[MAX_PATH], exe[MAX_PATH]; swprintf(lp, MAX_PATH, L"%ls\\EnshroudedSense_load.txt", g_dir);
            GetModuleFileNameW(NULL, exe, MAX_PATH);
            WIN32_FILE_ATTRIBUTE_DATA fa; int big = GetFileAttributesExW(lp, GetFileExInfoStandard, &fa) && fa.nFileSizeLow > 32768;
            FILE *f = _wfopen(lp, big ? L"w" : L"a");
            if (f) { SYSTEMTIME t; GetLocalTime(&t);
                fwprintf(f, L"%02d:%02d:%02d loaded into %ls pid=%lu\n", t.wHour, t.wMinute, t.wSecond, exe, GetCurrentProcessId());
                fclose(f); }
        }
        CreateThread(NULL, 0, DiagThread, NULL, 0, NULL);
    } else if (reason == DLL_PROCESS_DETACH) {
        g_quit = 1;
        if (!res && g_thread) WaitForSingleObject(g_thread, 300);
        else if (D.connected) SendReset();   // process exit: release triggers so they don't stay stiff
    }
    return TRUE;
}
