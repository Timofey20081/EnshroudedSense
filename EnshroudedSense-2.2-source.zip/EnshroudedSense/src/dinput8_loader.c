// EnshroudedSense early loader (dinput8.dll proxy) - v13 (surface haptics + menu clicks)
// Enshrouded's PC build creates its sound system with the "gamepad speaker" and
// "gamepad vibration" output flags hard-coded to 0:
//     mov word ptr [rsp+0x69], 0   ; call SoundSystem::create
// so every controller-speaker and vibration sound is dropped. This loader is
// imported by the game at process start (before the sound system exists) and
// flips both flags to 1. All DirectInput calls are forwarded to the system DLL.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdint.h>

static HMODULE g_real;
static void LOGW(const char *fmt, ...);
static wchar_t g_dir[MAX_PATH];

static volatile LONG g_logOpened, g_logLines;
static void LOGW(const char *fmt, ...) {
    if (g_logLines > 20000) return;                       // keep the file small (one game session)
    InterlockedIncrement(&g_logLines);
    wchar_t p[MAX_PATH]; swprintf(p, MAX_PATH, L"%ls\\EnshroudedSense_early.log", g_dir);
    FILE *f = _wfopen(p, InterlockedExchange(&g_logOpened, 1) ? L"a" : L"w"); if (!f) return;   // new file each game start
    SYSTEMTIME t; GetLocalTime(&t);
    fprintf(f, "[%02d:%02d:%02d.%03d] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a); fputc('\n', f); fclose(f);
}

static int g_speaker = 1, g_vibration = 1;

static int PatchSoundFlags(void) {
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL);
    IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS*)(mod + ((IMAGE_DOS_HEADER*)mod)->e_lfanew);
    IMAGE_SECTION_HEADER *sh = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++, sh++) {
        if (memcmp(sh->Name, ".text", 5)) continue;
        BYTE *p = mod + sh->VirtualAddress, *end = p + sh->Misc.VirtualSize - 16;
        for (; p < end; p++) {
            // 66 C7 44 24 69 00 00 E8  -> mov word ptr [rsp+0x69], 0 ; call
            if (p[0] == 0x66 && p[1] == 0xC7 && p[2] == 0x44 && p[3] == 0x24 && p[4] == 0x69 &&
                p[5] == 0x00 && p[6] == 0x00 && p[7] == 0xE8) {
                DWORD old;
                VirtualProtect(p + 5, 2, PAGE_EXECUTE_READWRITE, &old);
                p[5] = (BYTE)g_speaker; p[6] = (BYTE)g_vibration;
                VirtualProtect(p + 5, 2, old, &old);
                FlushInstructionCache(GetCurrentProcess(), p, 8);
                LOGW("sound flags patched at +0x%llX: gamepadSpeaker=%d gamepadVibration=%d",
                     (unsigned long long)(p - mod), g_speaker, g_vibration);
                return 1;
            }
        }
    }
    return 0;
}

static DWORD WINAPI Retry(LPVOID _) {
    (void)_;
    for (int i = 0; i < 3000; i++) { if (PatchSoundFlags()) return 0; Sleep(2); }
    LOGW("sound flag pattern not found (game updated?) - nothing patched");
    return 0;
}

static FARPROC Real(const char *name) {
    if (!g_real) {
        wchar_t p[MAX_PATH]; GetSystemDirectoryW(p, MAX_PATH); wcscat(p, L"\\dinput8.dll");
        g_real = LoadLibraryW(p);
    }
    return g_real ? GetProcAddress(g_real, name) : NULL;
}


// ============================================================================================
// Game audio capture: render the "gamepad vibration" and "gamepad speaker" groups that the PC
// build creates (after our flag patch) but never renders, and hand the PCM to EnshroudedSense.
// ============================================================================================
typedef uint64_t (*PFN5)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
static BYTE *g_tramp; static int g_trampUsed;
static BYTE *NearAlloc(BYTE *near_) {
    for (uintptr_t d = 0x10000; d < 0x70000000; d += 0x10000) {
        BYTE *p = (BYTE*)VirtualAlloc((BYTE*)(((uintptr_t)near_ & ~0xFFFFull) + 0x80000000ull - d), 4096,
                                      MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
        if (p) { int64_t r = p - near_; if (r < INT32_MAX && r > INT32_MIN) return p; VirtualFree(p, 0, MEM_RELEASE); }
    }
    return NULL;
}
static int HookCall(DWORD siteRva, DWORD targetRva, void *fn, PFN5 *orig) {
    BYTE *mod = (BYTE*)GetModuleHandleW(NULL), *site = mod + siteRva;
    if (site[0] != 0xE8) { LOGW("audio: site +%X is not a call (other game build?)", siteRva); return 0; }
    BYTE *tgt = site + 5 + *(int32_t*)(site + 1);
    if (tgt != mod + targetRva) { LOGW("audio: site +%X calls +%llX, expected +%X (other game build?)", siteRva, (unsigned long long)(tgt - mod), targetRva); return 0; }
    if (!g_tramp) g_tramp = NearAlloc(mod);
    if (!g_tramp) return 0;
    BYTE *t = g_tramp + g_trampUsed; g_trampUsed += 16;
    t[0] = 0xFF; t[1] = 0x25; *(int32_t*)(t + 2) = 0; memcpy(t + 6, &fn, 8);
    if (orig) *orig = (PFN5)tgt;
    int32_t rel = (int32_t)(t - (site + 5)); DWORD old;
    VirtualProtect(site, 5, PAGE_EXECUTE_READWRITE, &old); memcpy(site + 1, &rel, 4); VirtualProtect(site, 5, old, &old);
    FlushInstructionCache(GetCurrentProcess(), site, 5);
    return 1;
}

static void *volatile g_lastGroup, *volatile g_vibGroup, *volatile g_spkGroup;
static PFN5 o_alloc, o_catSpk, o_catVib, o_render, o_cleanup;
static volatile LONG g_cleanups;
// 0x1057810(engine, group): frees voices flagged "finished" and removes them from the group.
// The engine only runs it for groups attached to an output; our two groups are not, so their 8 voice
// slots filled up with finished voices and they went silent. Run it for them in the same place.
static uint64_t H_cleanup(uint64_t eng, uint64_t grp, uint64_t c, uint64_t d, uint64_t e) {
    uint64_t r = o_cleanup(eng, grp, c, d, e);
    void *v = g_vibGroup, *sp = g_spkGroup;
    if (v && (uint64_t)v != grp) o_cleanup(eng, (uint64_t)v, 0, 0, 0);
    if (sp && (uint64_t)sp != grp) o_cleanup(eng, (uint64_t)sp, 0, 0, 0);
    InterlockedIncrement(&g_cleanups);
    return r;
}

// 104c720 -> 104c7d0 allocates the mixing group object (returns its pointer)
static uint64_t H_alloc(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e) {
    uint64_t r = o_alloc(a, b, c, d, e); g_lastGroup = (void*)r; return r; }
static uint64_t H_catSpk(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e) {
    g_lastGroup = NULL; uint64_t r = o_catSpk(a, b, c, d, e); g_spkGroup = g_lastGroup;
    LOGW("audio: gamepad speaker group %p (id %u)", g_spkGroup, (unsigned)r); return r; }
static uint64_t H_catVib(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e) {
    g_lastGroup = NULL; uint64_t r = o_catVib(a, b, c, d, e); g_vibGroup = g_lastGroup;
    LOGW("audio: gamepad vibration group %p (id %u)", g_vibGroup, (unsigned)r); return r; }

// lock-free single producer / single consumer stereo rings
#define RING (48000)                       /* 1 s of stereo frames */
typedef struct { float lr[RING][2]; volatile LONG w, r; } Ring;
static Ring g_ring[2];                     /* 0 = vibration, 1 = speaker */
static volatile LONG g_blocks; static volatile LONG g_peakMilli[2];
static float g_buf[8][512]; static float *g_ptrs[8];

static void PushBlock(int which, int nch) {
    Ring *R = &g_ring[which]; LONG w = R->w; float pk = 0;
    for (int i = 0; i < 512; i++) {
        float l = g_buf[0][i], r = nch > 1 ? g_buf[1][i] : l;
        if (nch > 2) { float m = 0; for (int c = 2; c < nch; c++) m += g_buf[c][i]; m /= (nch - 2); l += m * 0.5f; r += m * 0.5f; }
        R->lr[w % RING][0] = l; R->lr[w % RING][1] = r; w++;
        float a = l < 0 ? -l : l; if (a > pk) pk = a;
    }
    R->w = w;
    LONG pm = (LONG)(pk * 1000); if (pm > g_peakMilli[which]) g_peakMilli[which] = pm;
}

static void DumpSurfaceStats(void);
static uint64_t H_render(uint64_t desc, uint64_t plat, uint64_t ctx, uint64_t group, uint64_t vol) {
    uint64_t r = o_render(desc, plat, ctx, group, vol);           // the game's normal output
    void *groups[2] = { g_vibGroup, g_spkGroup };
    uint64_t nch = ((uint64_t*)desc)[1]; if (nch < 1) nch = 1; if (nch > 8) nch = 8;
    for (int k = 0; k < 2; k++) {
        if (!groups[k] || (uint64_t)groups[k] == group) continue;
        for (uint64_t c = 0; c < nch; c++) { memset(g_buf[c], 0, sizeof g_buf[c]); g_ptrs[c] = g_buf[c]; }
        uint64_t d2[2] = { (uint64_t)g_ptrs, nch };
        o_render((uint64_t)d2, plat, ctx, (uint64_t)groups[k], vol);
        PushBlock(k, (int)nch);
    }
    LONG nb = InterlockedIncrement(&g_blocks);
    if (nb % 1710 == 0) DumpSurfaceStats();                       // ~every 18 s
    if (nb % 570 == 0) {                                         // ~every 6 s: dump voice state of both groups
        for (int k = 0; k < 2; k++) {
            BYTE *g = (BYTE*)groups[k]; if (!g) continue;
            unsigned n = *(unsigned*)(g + 0x20); void **arr = *(void***)(g + 0x18);
            char line[600]; int L = snprintf(line, sizeof line, "audio: %s group voices=%u cleanups=%ld |",
                k ? "speaker" : "vibration", n, g_cleanups);
            for (unsigned i = 0; i < n && i < 12 && arr; i++) {
                BYTE *v = (BYTE*)arr[i];
                if (!v) { L += snprintf(line + L, sizeof line - L, " null"); continue; }
                L += snprintf(line + L, sizeof line - L, " [%04X %08X %08X %08X]", *(unsigned short*)(v + 4),
                              *(unsigned*)(v + 0), *(unsigned*)(v + 8), *(unsigned*)(v + 0xc));
            }
            LOGW("%s", line);
        }
    }
    return r;
}

// ============================================================================================
// Surface haptics ("eyes"): every environment effect of an entity - footsteps (footdown_effects
// system: ground ray-cast -> material -> sound), landings, dodge rolls, slides, water wading
// (environment_effects / handle_notifier_events / water_fx) - is played through one helper,
// 0x2a05d0(world, &soundGuid, ?, &pos, &attribution, &time). The sound the game picks there is
// already the one for the surface under the feet. Whether a sound is ALSO played on the
// "gamepad vibration" output is decided per sound resource (byte +0x48 in the resource); the
// footstep/surface sounds don't have it set, so they never reach the actuators.
// We mark the sounds that 0x2a05d0 starts for the LOCAL player and let the engine's own
// vibration path (gate at 0x1073ddc in the sound start function 0x10738b0) play them on the
// vibration group too - with the same waveform, i.e. the real surface sound.
// ============================================================================================
typedef uint64_t (*PFN6)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
static int g_surf = 1, g_surfOnlyMine = 1; static float g_surfGain = 2.0f;
static int g_ui = 1, g_uiSkipLoop = 0; static float g_uiGain = 0.8f;
#define TAG_UI 0x40000000
#define TAG_BLOCK 0x20000000
#define TAG_MASK (TAG_UI | TAG_BLOCK)
static int g_blockSnd = 1; static float g_blockGain = 2.5f;
static DWORD g_tls = TLS_OUT_OF_INDEXES;
static PFN6 o_fx; static PFN5 o_start;
static BYTE *g_mod;

#define NGUID 256
typedef struct { uint64_t a, b; DWORD site; LONG calls, mine, forced, timeLogged; BYTE f40, f41, f48, instFlags, loop; float resVib, instVol; int32_t rumble; DWORD caller; } GuidStat;
static GuidStat g_gs[NGUID]; static volatile LONG g_gsN;
static volatile LONG g_fxCalls, g_fxMine, g_fxLogged, g_tagged, g_forced, g_origVib, g_decides, g_noLocal;

static int GuidSlot(uint64_t a, uint64_t b, DWORD site) {
    LONG n = g_gsN;
    for (int i = 0; i < n && i < NGUID; i++) if (g_gs[i].a == a && g_gs[i].b == b) return i;
    LONG k = InterlockedIncrement(&g_gsN) - 1;
    if (k >= NGUID) return -1;
    g_gs[k].a = a; g_gs[k].b = b; g_gs[k].site = site;
    return (int)k;
}

// recently started instances that came from a local-player environment effect
typedef struct { void *inst; uint32_t id; DWORD tick; int slot; int kind; } Forced;   // kind 0 surface, 1 ui, 2 block
static Forced g_fq[64]; static volatile LONG g_fqHead;

// local player's block state, published by EnshroudedSense (xinput1_4.dll) from the game's player state flags
typedef int (*PFN_BlockState)(void);
static PFN_BlockState BlockStateFn(void) {
    static PFN_BlockState fn; static DWORD tried;
    if (!fn && GetTickCount() - tried > 2000) {
        tried = GetTickCount();
        HMODULE x = GetModuleHandleW(L"xinput1_4.dll");
        if (x) fn = (PFN_BlockState)GetProcAddress(x, "ES_BlockState");
    }
    return fn;
}

static volatile LONG g_sndLogged;
// local player's id in the session (1 = host / first player, 2 = second ...) - same id the sound system uses
static volatile LONG g_localId;
__declspec(dllexport) LONG ES_LocalPlayerId(void) { return g_localId; }
static uint64_t H_fx(uint64_t world, uint64_t guidp, uint64_t c, uint64_t pos, uint64_t attr, uint64_t tm) {
    DWORD site = (DWORD)((BYTE*)__builtin_return_address(0) - 5 - g_mod);
    uint32_t ent = attr ? *(uint32_t*)attr : 0, local = world ? *(uint32_t*)(world + 0x74) : 0;
    int mine = ent != 0 && ent == local;
    if (!local) InterlockedIncrement(&g_noLocal); else g_localId = (LONG)local;
    InterlockedIncrement(&g_fxCalls); if (mine) InterlockedIncrement(&g_fxMine);
    uint64_t ga = guidp ? ((uint64_t*)guidp)[0] : 0, gb = guidp ? ((uint64_t*)guidp)[1] : 0;
    int slot = GuidSlot(ga, gb, site);
    if (slot >= 0) { InterlockedIncrement(&g_gs[slot].calls); if (mine) InterlockedIncrement(&g_gs[slot].mine); }
    if (InterlockedIncrement(&g_fxLogged) <= 60)
        LOGW("fx: site +%X entity=%u local=%u mine=%d sound=%016llX%016llX", site, ent, local, mine,
             (unsigned long long)ga, (unsigned long long)gb);
    else if (mine && slot >= 0 && InterlockedIncrement(&g_gs[slot].timeLogged) <= 2 && InterlockedIncrement(&g_sndLogged) <= 500) {
        PFN_BlockState bs = BlockStateFn();
        LOGW("own sound: site +%X block=%d sound=%016llX%016llX", site, bs ? bs() : 0, (unsigned long long)ga, (unsigned long long)gb);
    }
    int tag = g_surf && (mine || !g_surfOnlyMine);
    if (tag && g_tls != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls, (void*)(uintptr_t)(slot + 2));
    uint64_t r = o_fx(world, guidp, c, pos, attr, tm);
    if (tag && g_tls != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls, NULL);
    return r;
}

// 0x106f04b: SoundSystem::play -> startInstance(engine, instance). Remember tagged instances so the
// decision also works when the start is deferred (resource still loading) and retried later.
static uint64_t H_start(uint64_t eng, uint64_t inst, uint64_t c, uint64_t d, uint64_t e) {
    uintptr_t tag = g_tls != TLS_OUT_OF_INDEXES ? (uintptr_t)TlsGetValue(g_tls) : 0;
    if (tag && inst) {
        LONG k = InterlockedIncrement(&g_fqHead) & 63;
        g_fq[k].inst = (void*)inst; g_fq[k].id = *(uint32_t*)(inst + 0x30);
        g_fq[k].tick = GetTickCount(); g_fq[k].slot = (int)(tag & ~TAG_MASK) - 2;
        g_fq[k].kind = (tag & TAG_UI) ? 1 : (tag & TAG_BLOCK) ? 2 : 0;
        InterlockedIncrement(&g_tagged);
    }
    return o_start(eng, inst, c, d, e);
}

static int TakeForced(BYTE *inst, int *slot, int *kind) {
    DWORD now = GetTickCount(); uint32_t id = *(uint32_t*)(inst + 0x30);
    for (int i = 0; i < 64; i++) {
        Forced *f = &g_fq[i];
        if (f->inst == inst && f->id == id && now - f->tick < 4000) { *slot = f->slot; *kind = f->kind; f->inst = NULL; return 1; }
    }
    return 0;
}

// 0x2a0650 / 0x2a1e30: sound requests of FX systems (volatile FX = collision feedback: hits, block impacts,
// notifier sounds, voice, building sparks ...): (world, attributedPlayerId, &soundGuid, ...).
// While the local player is blocking, its own FX sounds (the shield / ward impact the game plays for the
// OnBlockFeedback / OnBrokenBlockFeedback collision feedback) are also played on the vibration group.
typedef uint64_t (*PFN8)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
static PFN8 o_snd0650, o_snd1e30; static volatile LONG g_blockForced;
static int SiteMayBlock(DWORD site) {   // FX systems whose sounds can be a block impact
    return site == 0x312ed6 || site == 0x312a9a || site == 0x2fe1c8 || site == 0x30d9c0 || site == 0x30dd3a;
}
static uint64_t SndCommon(PFN8 o, DWORD site, uint64_t world, uint64_t id, uint64_t guidp, uint64_t d,
                          uint64_t e, uint64_t f, uint64_t g, uint64_t h) {
    uint32_t local = world ? *(uint32_t*)(world + 0x74) : 0;
    int mine = (uint32_t)id != 0 && (uint32_t)id == local;
    uint64_t ga = guidp ? ((uint64_t*)guidp)[0] : 0, gb = guidp ? ((uint64_t*)guidp)[1] : 0;
    PFN_BlockState bs = BlockStateFn(); int block = bs ? bs() : 0;
    int slot = GuidSlot(ga, gb, site);
    if (slot >= 0) { InterlockedIncrement(&g_gs[slot].calls); if (mine) InterlockedIncrement(&g_gs[slot].mine); }
    if ((mine || block) && slot >= 0 && InterlockedIncrement(&g_gs[slot].timeLogged) <= 3 && InterlockedIncrement(&g_sndLogged) <= 500)
        LOGW("fx sound: site +%X mine=%d block=%d sound=%016llX%016llX", site, mine, block, (unsigned long long)ga, (unsigned long long)gb);
    int tag = g_blockSnd && mine && (block & 3) && SiteMayBlock(site);
    if (tag) InterlockedIncrement(&g_blockForced);
    if (tag && g_tls != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls, (void*)(uintptr_t)((slot + 2) | TAG_BLOCK));
    uint64_t r = o(world, id, guidp, d, e, f, g, h);
    if (tag && g_tls != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls, NULL);
    return r;
}
static uint64_t H_snd0650(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e, uint64_t f, uint64_t g, uint64_t h) {
    return SndCommon(o_snd0650, (DWORD)((BYTE*)__builtin_return_address(0) - 5 - g_mod), a, b, c, d, e, f, g, h); }
static uint64_t H_snd1e30(uint64_t a, uint64_t b, uint64_t c, uint64_t d, uint64_t e, uint64_t f, uint64_t g, uint64_t h) {
    return SndCommon(o_snd1e30, (DWORD)((BYTE*)__builtin_return_address(0) - 5 - g_mod), a, b, c, d, e, f, g, h); }

// 0xa4f48b: the game UI sound player (0xa4f310, "play game ui sound", 694 callers: menus, tabs, main menu,
// action bar...) starting its sound. Tag it so the engine also plays that click on the vibration group.
static PFN5 o_uiPlay; static volatile LONG g_uiCalls, g_uiLogged;
// every game UI sound = one UI event; EnshroudedSense (xinput1_4.dll) adds a crisp haptic tick for each,
// because most menu clicks are quiet high-pitched sounds that barely move the actuators on their own
__declspec(dllexport) LONG ES_UiEvents(void) { return g_uiCalls; }
static uint64_t H_ui(uint64_t eng, uint64_t b, uint64_t c, uint64_t guidp, uint64_t params) {
    void *fr[3] = { 0 }; RtlCaptureStackBackTrace(1, 2, fr, NULL);   // fr[0] = in 0xa4f310, fr[1] = its caller
    DWORD caller = fr[1] ? (DWORD)((BYTE*)fr[1] - g_mod) : 0;
    uint64_t ga = guidp ? ((uint64_t*)guidp)[0] : 0, gb = guidp ? ((uint64_t*)guidp)[1] : 0;
    int slot = GuidSlot(ga, gb, 0xa4f48b);
    if (slot >= 0) { InterlockedIncrement(&g_gs[slot].calls); g_gs[slot].caller = caller; }
    InterlockedIncrement(&g_uiCalls);
    if (InterlockedIncrement(&g_uiLogged) <= 150)
        LOGW("ui sound: caller +%X sound=%016llX%016llX", caller, (unsigned long long)ga, (unsigned long long)gb);
    int tag = g_ui;
    if (tag && g_tls != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls, (void*)(uintptr_t)((slot + 2) | TAG_UI));
    uint64_t r = o_uiPlay(eng, b, c, guidp, params);
    if (tag && g_tls != TLS_OUT_OF_INDEXES) TlsSetValue(g_tls, NULL);
    return r;
}

// Replaces the engine's test  "resource->vibration (+0x48) && (instance flags & 8 = gamepad allowed)"
// Writes exactly what the original code wrote: [rbp+0x70] play-on-vibration, word [rbp-0x44];
// plus the vibration volume into the free slot [rbp+0x74] (the volume load is patched to read it).
__attribute__((used)) void ES_Decide(BYTE *res, BYTE *inst, BYTE *frame, unsigned flags) {
    InterlockedIncrement(&g_decides);
    int orig = res[0x48] && (flags & 8);
    int slot = -1, forced = 0, kind = 0;
    if (!orig && TakeForced(inst, &slot, &kind)) forced = 1;
    if (forced && kind == 1 && g_uiSkipLoop && res[0x28]) forced = 0;    // looping UI sounds (menu ambience) stay off the actuators
    if (orig) {
        frame[0x70] = 1; *(uint16_t*)(frame - 0x44) = 0; *(float*)(frame + 0x74) = *(float*)(res + 0x4c);
        InterlockedIncrement(&g_origVib);
    } else if (forced) {
        float gain = kind == 1 ? g_uiGain : kind == 2 ? g_blockGain : g_surfGain;
        float v = *(float*)(inst + 0x4c) * gain; if (!(v > 0.0f)) v = gain; if (v > 4.0f) v = 4.0f;
        frame[0x70] = 1; *(uint16_t*)(frame - 0x44) = *(uint16_t*)(res + 0x5a); *(float*)(frame + 0x74) = v;
        InterlockedIncrement(&g_forced);
    } else {
        frame[0x70] = 0; *(uint16_t*)(frame - 0x44) = *(uint16_t*)(res + 0x5a);
    }
    if (slot >= 0 && slot < NGUID) {
        GuidStat *g = &g_gs[slot];
        g->f40 = res[0x40]; g->f41 = res[0x41]; g->f48 = res[0x48]; g->instFlags = (BYTE)flags;
        g->resVib = *(float*)(res + 0x4c); g->instVol = *(float*)(inst + 0x4c); g->rumble = *(int32_t*)(res + 0x68);
        g->loop = res[0x28];
        if (forced) InterlockedIncrement(&g->forced);
    }
}

void ES_GateStub(void);
__asm__(
    ".text\n"
    ".globl ES_GateStub\n"
    "ES_GateStub:\n"
    ".intel_syntax noprefix\n"
    "  push rcx\n  push rdx\n  push r8\n  push r9\n  push r10\n  push r11\n  push rax\n"
    "  sub rsp, 0x80\n"
    "  movdqu [rsp+0x20], xmm0\n  movdqu [rsp+0x30], xmm1\n  movdqu [rsp+0x40], xmm2\n"
    "  movdqu [rsp+0x50], xmm3\n  movdqu [rsp+0x60], xmm4\n  movdqu [rsp+0x70], xmm5\n"
    "  mov rcx, rsi\n  mov rdx, rdi\n  mov r8, rbp\n"
    "  movzx r9d, byte ptr [rsp+0xB0]\n"
    "  call ES_Decide\n"
    "  movdqu xmm0, [rsp+0x20]\n  movdqu xmm1, [rsp+0x30]\n  movdqu xmm2, [rsp+0x40]\n"
    "  movdqu xmm3, [rsp+0x50]\n  movdqu xmm4, [rsp+0x60]\n  movdqu xmm5, [rsp+0x70]\n"
    "  add rsp, 0x80\n"
    "  pop rax\n  pop r11\n  pop r10\n  pop r9\n  pop r8\n  pop rdx\n  pop rcx\n"
    "  ret\n"
    ".att_syntax prefix\n"
);

static int PatchBytes(DWORD rva, const BYTE *expect, const BYTE *repl, int n, const char *what) {
    BYTE *p = g_mod + rva; DWORD old;
    if (memcmp(p, expect, n)) { LOGW("surface: %s at +%X has unexpected bytes (other game build?) - skipped", what, rva); return 0; }
    VirtualProtect(p, n, PAGE_EXECUTE_READWRITE, &old); memcpy(p, repl, n); VirtualProtect(p, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, n);
    return 1;
}

static void InstallSurfaceHaptics(void) {
    static const DWORD fxSites[] = { 0x2f61d1, 0x2fa405, 0x2faa66, 0x2fe08d, 0x3042b4, 0x308404, 0x30cbf8,
                                     0x30cff2, 0x30d3a5, 0x30d676, 0x30da99, 0x398380, 0x39b137, 0x484215 };
    g_tls = TlsAlloc();
    // 1) vibration gate + volume load inside the sound start function
    static const BYTE gateOrig[34] = { 0x44,0x38,0x76,0x48, 0x74,0x10, 0xf6,0xc1,0x08, 0x74,0x0b, 0xc6,0x45,0x70,0x01,
        0x66,0x44,0x89,0x75,0xbc, 0xeb,0x0c, 0x0f,0xb7,0x46,0x5a, 0x66,0x89,0x45,0xbc, 0x44,0x88,0x75,0x70 };
    static const BYTE volOrig[5] = { 0xf3,0x0f,0x10,0x46,0x4c }, volNew[5] = { 0xf3,0x0f,0x10,0x45,0x74 };
    BYTE *gate = g_mod + 0x1073ddc;
    if (memcmp(gate, gateOrig, 34) || memcmp(g_mod + 0x1073f9a, volOrig, 5)) {
        LOGW("surface: sound start code differs (other game build?) - surface haptics disabled"); return; }
    if (!g_tramp) g_tramp = NearAlloc(g_mod);
    if (!g_tramp) { LOGW("surface: no trampoline memory"); return; }
    BYTE *t = g_tramp + g_trampUsed; g_trampUsed += 16;
    void *stub = (void*)ES_GateStub;
    t[0] = 0xFF; t[1] = 0x25; *(int32_t*)(t + 2) = 0; memcpy(t + 6, &stub, 8);
    BYTE gateNew[34]; memset(gateNew, 0xCC, sizeof gateNew);
    gateNew[0] = 0xE8; *(int32_t*)(gateNew + 1) = (int32_t)(t - (gate + 5));
    gateNew[5] = 0xEB; gateNew[6] = (BYTE)(0x1073dfe - (0x1073ddc + 7));   // jmp to the instruction after the original block
    int ok = PatchBytes(0x1073f9a, volOrig, volNew, 5, "vibration volume load");
    if (ok) ok = PatchBytes(0x1073ddc, gateOrig, gateNew, 34, "vibration gate");
    if (!ok) { LOGW("surface: patch failed - surface haptics disabled"); return; }
    // 2) instance start (tag) + every environment-effect sound call
    int n = HookCall(0x106f04b, 0x10738b0, (void*)H_start, &o_start);
    int u = HookCall(0xa4f48b, 0x106ee50, (void*)H_ui, &o_uiPlay);
    static const DWORD s0650[] = { 0x276997, 0x2fe1c8, 0x30d9c0, 0x30dd3a, 0x319a9e };
    static const DWORD s1e30[] = { 0x30b450, 0x310050, 0x3100ed, 0x311a55, 0x312a9a, 0x312ed6, 0x3135e4, 0x313764,
                                   0x3138e2, 0x313f44, 0x319882, 0x319a1f, 0x3984ef, 0x399ffa, 0x39a215 };
    int sv = 0;
    for (unsigned i = 0; i < sizeof s0650 / 4; i++) { PFN5 o = NULL; if (HookCall(s0650[i], 0x2a0650, (void*)H_snd0650, &o)) { sv++; o_snd0650 = (PFN8)o; } }
    for (unsigned i = 0; i < sizeof s1e30 / 4; i++) { PFN5 o = NULL; if (HookCall(s1e30[i], 0x2a1e30, (void*)H_snd1e30, &o)) { sv++; o_snd1e30 = (PFN8)o; } }
    LOGW("fx sound hooks (block impacts): %d/20, block sounds on=%d gain %.2f", sv, g_blockSnd, g_blockGain);
    int m = 0;
    for (unsigned i = 0; i < sizeof fxSites / sizeof fxSites[0]; i++) {
        PFN5 o = NULL; if (HookCall(fxSites[i], 0x2a05d0, (void*)H_fx, &o)) { m++; o_fx = (PFN6)o; }
    }
    LOGW("surface haptics: gate patched, start hook %d/1, effect-sound hooks %d/%u, gain %.2f, only own character %d | ui clicks hook %d/1 on=%d gain %.2f",
         n, m, (unsigned)(sizeof fxSites / sizeof fxSites[0]), g_surfGain, g_surfOnlyMine, u, g_ui, g_uiGain);
}

static void DumpSurfaceStats(void) {
    LOGW("surface: fxCalls=%ld mine=%ld noLocalId=%ld tagged=%ld decides=%ld forcedVib=%ld originalVib=%ld uiSounds=%ld blockSounds=%ld",
         g_fxCalls, g_fxMine, g_noLocal, g_tagged, g_decides, g_forced, g_origVib, g_uiCalls, g_blockForced);
    LONG n = g_gsN; if (n > NGUID) n = NGUID;
    for (int i = 0; i < n; i++) {
        GuidStat *g = &g_gs[i];
        if (!g->mine && !g->forced && g->site != 0xa4f48b && !g->timeLogged) continue;
        LOGW("  sound %016llX%016llX site +%X caller +%X calls=%ld mine=%ld forced=%ld | res main=%u spk=%u vib=%u loop=%u vibVol=%.2f rumbleEntry=%d | inst flags=%02X vol=%.2f",
             (unsigned long long)g->a, (unsigned long long)g->b, g->site, g->caller, g->calls, g->mine, g->forced,
             g->f40, g->f41, g->f48, g->loop, g->resVib, g->rumble, g->instFlags, g->instVol);
    }
}

static void InstallAudioHooks(void) {
    int ok = 0;
    ok += HookCall(0x104c734, 0x104c7d0, (void*)H_alloc, &o_alloc);
    ok += HookCall(0x105433a, 0x104c4c0, (void*)H_catSpk, &o_catSpk);
    ok += HookCall(0x10543b0, 0x104c4c0, (void*)H_catVib, &o_catVib);
    ok += HookCall(0x107555b, 0x105f570, (void*)H_render, &o_render);
    ok += HookCall(0x106961e, 0x1057810, (void*)H_cleanup, &o_cleanup);
    LOGW("audio: %d/5 capture hooks installed", ok);
    if (g_vibration && (g_surf || g_ui)) InstallSurfaceHaptics();
}

// ---- API for EnshroudedSense (xinput1_4.dll): read captured stereo frames
__declspec(dllexport) int ES_ReadAudio(int which, float *outLR, int frames) {
    if (which < 0 || which > 1) return 0;
    Ring *R = &g_ring[which];
    LONG w = R->w, r = R->r;
    if (w - r > 4800) r = w - 2400;               // consumer fell behind: keep ~50 ms latency
    int n = 0;
    for (; n < frames && r < w; n++, r++) { outLR[n * 2] = R->lr[r % RING][0]; outLR[n * 2 + 1] = R->lr[r % RING][1]; }
    R->r = r;
    return n;
}
__declspec(dllexport) int ES_AudioStatus(int *blocks, int *vibPeakMilli, int *spkPeakMilli) {
    if (blocks) *blocks = g_blocks;
    if (vibPeakMilli) { *vibPeakMilli = g_peakMilli[0]; g_peakMilli[0] = 0; }
    if (spkPeakMilli) { *spkPeakMilli = g_peakMilli[1]; g_peakMilli[1] = 0; }
    return (g_vibGroup ? 1 : 0) | (g_spkGroup ? 2 : 0);
}

// ---- hide the DualSense from the game's DirectInput (EnshroudedSense feeds it through XInput instead)
static int g_hideDS = 1;
typedef BOOL (CALLBACK *PFN_ENUMCB)(const void *inst, void *ref);
typedef HRESULT (WINAPI *PFN_ENUM)(void *self, DWORD type, PFN_ENUMCB cb, void *ref, DWORD flags);
static PFN_ENUM o_EnumDevices;
typedef struct { PFN_ENUMCB cb; void *ref; } EnumCtx;
static BOOL CALLBACK FilterCb(const void *inst, void *ref) {
    EnumCtx *ctx = (EnumCtx*)ref;
    const GUID *prod = (const GUID*)((const BYTE*)inst + 4 + 16);   // DIDEVICEINSTANCE: dwSize, guidInstance, guidProduct
    WORD vid = LOWORD(prod->Data1), pid = HIWORD(prod->Data1);
    if (vid == 0x054C && (pid == 0x0CE6 || pid == 0x0DF2)) {
        static int logged; if (!logged++) LOGW("DirectInput: hiding DualSense (pid %04X) from the game", pid);
        return TRUE;                                                   // DIENUM_CONTINUE: skip it
    }
    return ctx->cb(inst, ctx->ref);
}
static HRESULT WINAPI H_EnumDevices(void *self, DWORD type, PFN_ENUMCB cb, void *ref, DWORD flags) {
    if (!cb) return o_EnumDevices(self, type, cb, ref, flags);
    EnumCtx ctx = { cb, ref };
    return o_EnumDevices(self, type, FilterCb, &ctx, flags);
}
static void HookDI8(void *obj) {
    if (!obj || o_EnumDevices) return;
    void **vt = *(void***)obj;                 // IDirectInput8: 0 QI,1 AddRef,2 Release,3 CreateDevice,4 EnumDevices
    DWORD old;
    if (VirtualProtect(&vt[4], sizeof(void*), PAGE_EXECUTE_READWRITE, &old)) {
        o_EnumDevices = (PFN_ENUM)vt[4];
        vt[4] = (void*)H_EnumDevices;
        VirtualProtect(&vt[4], sizeof(void*), old, &old);
        LOGW("DirectInput8 EnumDevices hooked");
    }
}

typedef HRESULT (WINAPI *PFN_DI8C)(HINSTANCE, DWORD, REFIID, LPVOID*, void*);
__declspec(dllexport) HRESULT WINAPI DirectInput8Create(HINSTANCE h, DWORD v, REFIID r, LPVOID *o, void* u) {
    PFN_DI8C f = (PFN_DI8C)Real("DirectInput8Create");
    HRESULT hr = f ? f(h, v, r, o, u) : E_FAIL;
    if (SUCCEEDED(hr) && o && g_hideDS) HookDI8(*o);
    return hr;
}
__declspec(dllexport) HRESULT WINAPI DllCanUnloadNow(void) {
    typedef HRESULT (WINAPI *F)(void); F f = (F)Real("DllCanUnloadNow"); return f ? f() : S_FALSE; }
__declspec(dllexport) HRESULT WINAPI DllGetClassObject(REFCLSID a, REFIID b, LPVOID *c) {
    typedef HRESULT (WINAPI *F)(REFCLSID, REFIID, LPVOID*); F f = (F)Real("DllGetClassObject"); return f ? f(a, b, c) : E_FAIL; }
__declspec(dllexport) HRESULT WINAPI DllRegisterServer(void) {
    typedef HRESULT (WINAPI *F)(void); F f = (F)Real("DllRegisterServer"); return f ? f() : E_FAIL; }
__declspec(dllexport) HRESULT WINAPI DllUnregisterServer(void) {
    typedef HRESULT (WINAPI *F)(void); F f = (F)Real("DllUnregisterServer"); return f ? f() : E_FAIL; }

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID res) {
    (void)res;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        GetModuleFileNameW(inst, g_dir, MAX_PATH);
        wchar_t *s = wcsrchr(g_dir, L'\\'); if (s) *s = 0;
        wchar_t ini[MAX_PATH]; swprintf(ini, MAX_PATH, L"%ls\\EnshroudedSense.ini", g_dir);
        g_speaker = GetPrivateProfileIntW(L"Sound", L"GamepadSpeaker", 1, ini) ? 1 : 0;
        g_vibration = GetPrivateProfileIntW(L"Sound", L"GamepadVibration", 1, ini) ? 1 : 0;
        g_surf = GetPrivateProfileIntW(L"Haptics", L"SurfaceHaptics", 1, ini) ? 1 : 0;
        g_surfOnlyMine = GetPrivateProfileIntW(L"Haptics", L"SurfaceOnlyOwnCharacter", 1, ini) ? 1 : 0;
        g_ui = GetPrivateProfileIntW(L"Haptics", L"MenuClicks", 1, ini) ? 1 : 0;
        g_uiSkipLoop = GetPrivateProfileIntW(L"Haptics", L"MenuClicksSkipLoops", 0, ini) ? 1 : 0;
        g_blockSnd = GetPrivateProfileIntW(L"Block", L"ImpactSounds", 1, ini) ? 1 : 0;
        { wchar_t b[32]; GetPrivateProfileStringW(L"Block", L"ImpactSoundGain", L"2.5", b, 32, ini);
          g_blockGain = (float)_wtof(b); if (!(g_blockGain >= 0.0f)) g_blockGain = 2.5f; if (g_blockGain > 4.0f) g_blockGain = 4.0f; }
        { wchar_t b[32]; GetPrivateProfileStringW(L"Haptics", L"MenuClickGain", L"0.8", b, 32, ini);
          g_uiGain = (float)_wtof(b); if (!(g_uiGain >= 0.0f)) g_uiGain = 0.8f; if (g_uiGain > 4.0f) g_uiGain = 4.0f; }
        { wchar_t b[32]; GetPrivateProfileStringW(L"Haptics", L"SurfaceGain", L"2.0", b, 32, ini);
          g_surfGain = (float)_wtof(b); if (!(g_surfGain >= 0.0f)) g_surfGain = 2.0f; if (g_surfGain > 4.0f) g_surfGain = 4.0f; }
        g_mod = (BYTE*)GetModuleHandleW(NULL);
        g_hideDS = GetPrivateProfileIntW(L"General", L"XInputInput", 1, ini) &&
                   GetPrivateProfileIntW(L"General", L"HideDualSenseFromDirectInput", 1, ini);
        LOGW("EnshroudedSense early loader in pid %lu", GetCurrentProcessId());
        if (!PatchSoundFlags()) CreateThread(NULL, 0, Retry, NULL, 0, NULL);
        if (g_vibration || g_speaker) InstallAudioHooks();
    }
    return TRUE;
}
