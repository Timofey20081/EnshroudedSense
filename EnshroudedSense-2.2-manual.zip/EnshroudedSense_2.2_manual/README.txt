﻿EnshroudedSense 2.2 — DualSense features of the PS5 version for Enshrouded on PC
by MeT1oR and Tianku

[ English ]                                         [ Русский — ниже ]

======================================================================
 BEFORE YOU INSTALL
======================================================================

1. Update the DualSense firmware.
   Install Sony's free PlayStation Accessories app for Windows:
   https://controller.dl.playstation.net/controller/lang/gb/2100004.html
   Connect the controller with a USB cable and install the update if the
   app offers one.

2. Turn Steam Input off for Enshrouded.
   Steam Library > right-click Enshrouded > Properties > Controller >
   "Disable Steam Input".

3. Close DSX, DS4Windows and any other program that controls the DualSense.

4. Use a USB cable. HD haptics and the controller speaker only work over USB.

5. Windows 10 or 11, 64-bit.

======================================================================
 INSTALLATION (manual)
======================================================================

1. Close the game.
2. Copy dinput8.dll and xinput1_4.dll into the Enshrouded game folder,
   next to enshrouded.exe. Steam: Library > right-click Enshrouded >
   Manage > Browse local files.
   If the folder already has files with these names (another mod),
   back them up first: they get replaced.
3. Start the game with the DualSense connected.

======================================================================
 IS IT WORKING?
======================================================================

- In game the lightbar shows your health (green at full health).
- Draw a bow: the right trigger pushes back.
- The game folder now has EnshroudedSense.ini and EnshroudedSense.log.

======================================================================
 SETTINGS
======================================================================

Everything is in EnshroudedSense.ini in the game folder (it appears after
the first start). Change a value, save, restart the game. Delete the file
to get the default settings back.

  Trigger strength ............ [Triggers] Strength (percent)
  Vibration strength .......... [Rumble] Scale, [Haptics] Gain
  Gyro ........................ [Gyro] SensitivityX / SensitivityY
                                Mode: 0 off, 1 while aiming, 2 always
  Lightbar .................... [Lightbar] Mode, Brightness
  Map speed under the finger .. [Touchpad] MapDragSpeed
  Quick item wheel on touch ... [Touchpad] QuickItemWheelOpenOnTouch
  Shield or ward (block feel) . [Block] Offhand = shield / ward
  Touchpad click .............. [Buttons] TouchpadAs: 0 Back, 1 Menu, 2 nothing
  Controller speaker .......... [Speaker] Enabled, Volume

======================================================================
 TROUBLESHOOTING
======================================================================

- Nothing works: check that Steam Input is off for the game and that
  DSX / DS4Windows are closed. If there is no EnshroudedSense.log in the
  game folder, the mod was not loaded: reinstall it into the folder that
  contains enshrouded.exe.
- No HD haptics or speaker sound: connect the controller with a cable and
  do not disable its sound device in Windows ("Wireless Controller").
- Something stopped working after a game update: the mod switches off
  whatever no longer matches the new game version, and the game keeps
  running normally. Wait for a mod update.
- Gyro too weak or too strong: [Gyro] SensitivityX / SensitivityY.

======================================================================
 UNINSTALL
======================================================================

Delete dinput8.dll, xinput1_4.dll and the EnshroudedSense.* files from
the game folder.


######################################################################


[ Русский ]

======================================================================
 ПЕРЕД УСТАНОВКОЙ
======================================================================

1. Обновите прошивку DualSense.
   Установите бесплатное приложение Sony PlayStation Accessories для Windows:
   https://controller.dl.playstation.net/controller/lang/gb/2100004.html
   Подключите геймпад USB-кабелем и установите обновление, если приложение
   его предложит.

2. Выключите Steam Input для Enshrouded.
   Библиотека Steam > правой кнопкой по Enshrouded > Свойства > Контроллер >
   «Отключить Steam Input».

3. Закройте DSX, DS4Windows и другие программы, которые управляют DualSense.

4. Подключайте геймпад кабелем. HD-вибрация и динамик геймпада работают
   только по USB.

5. Windows 10 или 11, 64-бит.

======================================================================
 УСТАНОВКА (вручную)
======================================================================

1. Закройте игру.
2. Скопируйте dinput8.dll и xinput1_4.dll в папку игры Enshrouded,
   рядом с enshrouded.exe. Steam: Библиотека > правой кнопкой по
   Enshrouded > Управление > Просмотреть локальные файлы.
   Если в папке уже есть файлы с такими именами (другой мод),
   сохраните их копию: они будут заменены.
3. Запустите игру с подключённым DualSense.

======================================================================
 КАК ПРОВЕРИТЬ, ЧТО МОД РАБОТАЕТ
======================================================================

- В игре подсветка геймпада показывает здоровье (при полном — зелёная).
- Натяните лук: правый курок начнёт сопротивляться.
- В папке игры появились EnshroudedSense.ini и EnshroudedSense.log.

======================================================================
 НАСТРОЙКИ
======================================================================

Все настройки — в файле EnshroudedSense.ini в папке игры (появляется после
первого запуска). Измените значение, сохраните файл и перезапустите игру.
Чтобы вернуть всё по умолчанию, удалите файл.

  Сила курков ................. [Triggers] Strength (в процентах)
  Сила вибрации ............... [Rumble] Scale, [Haptics] Gain
  Гироскоп .................... [Gyro] SensitivityX / SensitivityY
                                Mode: 0 выкл, 1 при прицеливании, 2 всегда
  Подсветка ................... [Lightbar] Mode, Brightness
  Скорость карты под пальцем .. [Touchpad] MapDragSpeed
  Колесо предметов по касанию . [Touchpad] QuickItemWheelOpenOnTouch
  Щит или оберег (блок) ....... [Block] Offhand = shield / ward
  Нажатие на тачпад ........... [Buttons] TouchpadAs: 0 «Назад», 1 меню, 2 ничего
  Динамик геймпада ............ [Speaker] Enabled, Volume

======================================================================
 ЕСЛИ ЧТО-ТО НЕ РАБОТАЕТ
======================================================================

- Не работает ничего: проверьте, что Steam Input для игры выключен,
  а DSX и DS4Windows закрыты. Если в папке игры нет EnshroudedSense.log,
  мод не загрузился: переустановите его в папку, где лежит enshrouded.exe.
- Нет HD-вибрации или звука из динамика: подключите геймпад кабелем и не
  отключайте его звуковое устройство в Windows («Wireless Controller»).
- После обновления игры что-то пропало: мод сам отключает то, что
  не совпало с новой версией игры, а игра работает как обычно.
  Дождитесь обновления мода.
- Гироскоп слишком слабый или сильный: [Gyro] SensitivityX / SensitivityY.

======================================================================
 УДАЛЕНИЕ
======================================================================

Удалите из папки игры dinput8.dll, xinput1_4.dll и файлы EnshroudedSense.*
